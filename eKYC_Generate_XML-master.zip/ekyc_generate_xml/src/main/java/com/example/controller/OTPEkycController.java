package com.example.controller;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.enums.DataType;
import com.example.enums.Lang;
import com.example.enums.Type;
import com.example.enums.ra;
import com.example.models.KUAData;
import com.example.models.Pid;
import com.example.utils.AppConstants;
import com.example.utils.DateTimeUtil;
import com.example.utils.ExceptionLogger;
import com.example.utils.PropertiesUtil;
import com.example.utils.SHA256Encrypt;
import com.example.utils.Validator;
import com.example.utils.XMLBuilder;
import com.example.utils.kuadataParse;
import com.example.utils.kuadataValidation;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
@RestController
@RequestMapping("/ekyc/rest")
public class OTPEkycController {

	// *********************************** Checking Status Of Service
	// ***********************************
	@GetMapping(value = "/checkstatus25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String checkAUAStatus() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><status>eKYC Generate XML of GOG Up &amp; Runing</status>";
	}

	@PostMapping(value = "/genOtp25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String acceptRequest25_OTP(HttpServletRequest httpRequest) {
		// *********************************** 1. Validation of input
		// ***********************************
		String error = kuadataValidation.parseInputValidation(httpRequest);
		if (!error.equals("")) {
			return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><parseError>" + error + "</parseError>";
		}

		// *********************************** 2. store data in model
		// ***********************************
		KUAData request = kuadataParse.parseInput(httpRequest);

		Pid pid = XMLBuilder.parsePIDInput(httpRequest);

		//System.out.println("request.toString() data=>" + request.toString());
		if (request == null || pid == null) {
			return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><error>Error in Fetching input values from Request</error>";
		}
		// *********************************** 2. Validate Request Parameter
		// ***********************************
	
		return XMLBuilder.buildRequestOTP(request, pid);
	}
	

	

}
