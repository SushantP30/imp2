/**
 * 
 */
package com.example.utils;

import java.time.LocalDateTime;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class DateTimeUtil {
	/**
	 * 
	 * @return returns Date Time stamp in format YYYY-MM-DDThh:mm:sss+5:30
	 */
	public static String getCurrentDate() {
		return LocalDateTime.now().toString().substring(0, 23) + "+5:30";
	}

	/**
	 * 
	 * @return returns Date Time stamp in format YYYY-MM-DD hh:mm:sss . Used for
	 *         saving in database
	 */
	public static String getCurrentDateSQLFormat() {
		return LocalDateTime.now().toString().substring(0, 23).replace("T", " ");
	}
}
