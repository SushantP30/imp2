package com.example.utils;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import com.example.enums.DataType;
import com.example.enums.Type;
import com.example.enums.ra;
import com.example.models.KUAData;

public class kuadataParse {

	public static KUAData parseInput(HttpServletRequest httpRequest) {
		KUAData request = new KUAData();
		try {
			// Below commented values are set internally so no need to set them,
			// default values will be used
			request.uid = httpRequest.getParameter("uid");
			// System.out.println("here is working");
			request.saTxn = httpRequest.getParameter("saTxn");
			request.sa = httpRequest.getParameter("sa");
			// request.deviceId = httpRequest.getParameter("deviceId");
			// request.ver=httpRequest.getParameter("ver");
			/*
			 * if (httpRequest.getParameter("ra").equalsIgnoreCase("F") ||
			 * httpRequest.getParameter("ra").equalsIgnoreCase("I") ||
			 * httpRequest.getParameter("ra").equalsIgnoreCase("O") ||
			 * httpRequest.getParameter("ra").equalsIgnoreCase("P")) { //O is for OTP
			 */ if (!httpRequest.getParameter("ra").equals("O")) {
				return null;
			} else {
				request.ra = ra.fromValue(httpRequest.getParameter("ra"));
			}
			request.rc = httpRequest.getParameter("rc");
			request.lr = httpRequest.getParameter("lr");
			request.pfr = httpRequest.getParameter("pfr");
			if (httpRequest.getParameter("type").equalsIgnoreCase("A")
					|| httpRequest.getParameter("type").equalsIgnoreCase("V")
					|| httpRequest.getParameter("type").equalsIgnoreCase("T")
					|| httpRequest.getParameter("type").equalsIgnoreCase("E")) {
				request.type = Type.fromValue(httpRequest.getParameter("type"));
			} else {
				return null;
			}
			if (httpRequest.getParameter("rdsrno") != null && httpRequest.getParameter("rdsrno").equals("")) {
				request.info.rdsrno = httpRequest.getParameter("rdsrno");
			}
			// request.info.txnType=httpRequest.getParameter("txnType");
			request.info.schemeName = httpRequest.getParameter("schemeName");
			request.info.buildingNo = Optional.ofNullable(httpRequest.getParameter("buildingNo"));

			request.info.buildingName = httpRequest.getParameter("buildingName");
			request.info.street = Optional.ofNullable(httpRequest.getParameter("street"));
			request.info.city = httpRequest.getParameter("city");
			request.info.pinCode = httpRequest.getParameter("pinCode");
			// request.ReqType=httpRequest.getParameter("ReqType");
			// request.uses.pi=httpRequest.getParameter("pi");
			// request.uses.pa=httpRequest.getParameter("pa");
			// request.uses.pfa=httpRequest.getParameter("pfa");
			// request.uses.bio=httpRequest.getParameter("bio");
			// request.uses.bt=httpRequest.getParameter("bt");
			// request.uses.pin=httpRequest.getParameter("pin");
			request.uses.otp = httpRequest.getParameter("otp");
			// request.meta.rdsId=httpRequest.getParameter("rdsId");
			// request.meta.rdsVer=httpRequest.getParameter("rdsVer");
			// request.meta.dc=httpRequest.getParameter("dc");
			// request.meta.mi=httpRequest.getParameter("mi");
			// request.meta.mc=httpRequest.getParameter("mc");
			// request.skey.ci = httpRequest.getParameter("ci");
			// request.skey.Data = httpRequest.getParameter("sKey");

			// request.hmac =
			// httpRequest.getParameter("hmac").getBytes(StandardCharsets.UTF_8);

			/*
			 * if (httpRequest.getParameter("dataType").equalsIgnoreCase("X") ||
			 * httpRequest.getParameter("dataType").equalsIgnoreCase("P")) {
			 * request.data.type =
			 * DataType.fromValue(httpRequest.getParameter("dataType").toString()); } else {
			 * return null; }
			 */
			request.data.data = httpRequest.getParameter("data");

			request.ts = DateTimeUtil.getCurrentDate();

//			System.out.println("request.toString() =>"+request.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ExceptionLogger.logAsyncKua(
					"Error fetching request values from Request:" + "Transaction ID:" + request.saTxn + ":", e);
			return null;
		}
		return request;
	}
}
