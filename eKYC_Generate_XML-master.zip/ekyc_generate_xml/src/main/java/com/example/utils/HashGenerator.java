package com.example.utils;

public class HashGenerator {

}
