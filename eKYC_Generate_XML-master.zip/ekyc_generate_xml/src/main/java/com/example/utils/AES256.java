package com.example.utils;

import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class AES256 {

	// private static final String key = ;

	// private static final String initVector = ;
	public static final int AES_KEY_SIZE = 256;
	public static final int GCM_IV_LENGTH = 12;
	public static final int GCM_TAG_LENGTH = 16;
	private static Cipher cipher;
	

	public static String encryptGCMNOPADDING(byte[] plaintext, SecretKey key, byte[] IV) throws Exception {
		try {
			// Get Cipher Instance
			cipher = Cipher.getInstance("AES/GCM/NoPadding");

			// Create SecretKeySpec
			SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
			//SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");

			// Create GCMParameterSpec
			GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);

			// Initialize Cipher for ENCRYPT_MODE
			cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmParameterSpec);

			// Perform Encryption
			byte[] cipherText = cipher.doFinal(plaintext);

			System.out.println("cipherText :" + new String(cipherText));

			return new String(cipherText, StandardCharsets.UTF_8);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public static String decryptGCMNOPADDING(byte[] cipherText, SecretKey key, byte[] IV) throws Exception {
		try {
			// Get Cipher Instance
			cipher = Cipher.getInstance("AES/GCM/NoPadding");

			// Create SecretKeySpec
			SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");

			// Create GCMParameterSpec
			GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);

			// Initialize Cipher for ENCRYPT_MODE
			cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmParameterSpec);
			cipher.update(cipherText);
			// Perform Encryption
			byte[] plainText = cipher.doFinal(cipherText);

			return new String(plainText);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
}
