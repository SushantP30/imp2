
package com.example.utils;

import java.math.BigInteger;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.example.enums.DataType;
import com.example.enums.Type;
import com.example.models.*;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class Validator {
	public static String Validate(KUAData request,String otp) {
		// following validations applicable to only SubAUA Request XML

		if (request.uid == null || request.uid.trim().equals("")) {
			return AppConstants.ERROR_REQ_UID;
		}
		if (!isValidUID(request.uid, request.type.toString())) {
			return AppConstants.ERROR1007;
		}

		if (request.saTxn == null || !request.saTxn.startsWith("AuthOtp")) {
			return AppConstants.ERROR_VAL_SATXN;
		}

		if (!(request.type.equals(Type.A) || request.type.equals(Type.V) || request.type.equals(Type.T)
				|| request.type.equals(Type.E))) {
			return AppConstants.ERROR1015;
		}
		if (request.sa == null || request.sa.trim().equals("")) {
			return AppConstants.ERROR_REQ_SA;
		}
		/*
		 * if (request.deviceId == null || request.deviceId.trim().equals("")) { return
		 * AppConstants.ERROR_REQ_DEVID; }
		 */
		if (request.ver == null || request.ver.trim().equals("") || !request.ver.equalsIgnoreCase("2.5")) {
			return AppConstants.ERROR_REQ_VER;
		}

		if (request.ra == null) {
			return AppConstants.ERROR_REQ_RA;
		}

		if (request.rc == null || (request.rc.toString().trim().equals(""))) {
			return AppConstants.ERROR_REQ_RC;
		}

		if (!request.rc.equalsIgnoreCase("Y")) {
			return AppConstants.ERROR_VAL_RC;
		}

		if (request.lr == null || (request.lr.toString().trim().equals(""))
				|| !(request.lr.toString().equalsIgnoreCase("Y") || request.lr.toString().equalsIgnoreCase("N"))) {
			return AppConstants.ERROR_REQ_LR;
		}

		if (request.pfr == null || request.pfr.toString().trim().equals("")) {
			return AppConstants.ERROR_REQ_PFR;
		}
		if (!(request.pfr.equalsIgnoreCase("Y") || request.pfr.equalsIgnoreCase("N"))) {
			return AppConstants.ERRORK_546;
		}

		// info
		if (request.info == null) {
			return AppConstants.ERROR_REQ_INFO;
		}
		if (!request.info.rdsrno.equalsIgnoreCase("NA")) {
			return AppConstants.ERROR_VAL_RDSRNO;
		}
		if (request.info.txnType == null || request.info.txnType.trim().equals("")
				|| !request.info.txnType.equalsIgnoreCase("OTP")) {
			return AppConstants.ERROR_VAL_TXNTYPE;
		}

		if (request.info.schemeName == null || request.info.schemeName.trim().equals("")) {
			return AppConstants.ERROR_REQ_SCHEME;
		}

		if (request.info.buildingName == null || request.info.buildingName.trim().equals("")) {
			return AppConstants.ERROR_REQ_BUILDING;
		}

		if (request.info.city == null || request.info.city.equals("")) {
			return AppConstants.ERROR_REQ_CITY;
		}
		if (request.info.pinCode == null || request.info.pinCode.equals("")) {
			return AppConstants.ERROR_REQ_PINCODE;
		}

		if (request.info.pinCode.length() != 6) {
			return AppConstants.ERROR_VAL_PINCODE;
		}

		if (request.ReqType == null || request.ReqType.trim().equals("") || !request.ReqType.equalsIgnoreCase("OTP")) {
			return AppConstants.ERROR1008;
		}

		if (request.uses == null) {
			return AppConstants.ERROR_REQ_USES;
		}

		// uses
		if (!request.uses.pi.equalsIgnoreCase("n")) {
			return AppConstants.ERROR_VAL_PI;
		}

		if (!request.uses.pa.equalsIgnoreCase("n")) {
			return AppConstants.ERROR_VAL_PA;
		}

		if (!request.uses.pfa.equalsIgnoreCase("n")) {
			return AppConstants.ERROR_VAL_PFA;
		}

		if (!request.uses.bio.equalsIgnoreCase("n")) {
			return AppConstants.ERROR_VAL_BIO;
		}

		if (!request.uses.bt.equalsIgnoreCase("")) {
			return AppConstants.ERROR_REQ_BT;
		}

		if (!request.uses.pin.equalsIgnoreCase("n")) {
			return AppConstants.ERROR_VAL_PIN;
		}

		if (!request.uses.otp.equalsIgnoreCase("y")) {
			return AppConstants.ERROR_VAL_OTP;
		}

		// Meta
		if (request.meta == null) {
			return AppConstants.ERROR_REQ_META;
		}

		if (!request.meta.dpId.equals("")) {
			return AppConstants.ERROR_REQ_DPID;
		}
		if (!request.meta.rdsId.equals("")) {
			return AppConstants.ERROR_REQ_RDSID;
		}
		if (!request.meta.rdsVer.equals("")) {
			return AppConstants.ERROR_REQ_RDSVER;
		}
		if (!request.meta.dc.equals("")) {
			return AppConstants.ERROR_REQ_DC;
		}
		if (!request.meta.mi.equals("")) {
			return AppConstants.ERROR_REQ_MI;
		}
		if (!request.meta.mc.equals("")) {
			return AppConstants.ERROR_REQ_MC;
		}

		/*
		 * if (request.skey == null) { return AppConstants.ERROR_REQ_SKEY; }
		 * 
		 * if (request.skey.ci == null || request.skey.ci.equals("")) { return
		 * AppConstants.ERROR_REQ_CI; } if (verifyInput(request.skey.ci) == null) {
		 * return AppConstants.ERROR_VAL_CI; }
		 */
		

		/*
		 * if (request.skey.Data==null || request.skey.Data.equals("")) { return
		 * AppConstants.ERROR1004; }
		 */
		
		
		
		// Getting decoder  
        Base64.Decoder decoder = Base64.getDecoder();  
        // Decoding string  
        String sKey = new String(decoder.decode(PropertiesUtil.getSessionKey()));  
		
		if (sKey.equals("") || sKey.length()!=16) {
			return AppConstants.ERROR_VAL_SKEY;
		}
		
		

		if (request.data == null) {
			return AppConstants.ERROR_REQ_DATA;
		}

		/*
		 * if (request.hmac == null) { return AppConstants.ERROR1017; }
		 */

		if (request.data.type == null
				|| !(request.data.type.equals(DataType.X) || request.data.type.equals(DataType.P))) {
			return AppConstants.ERROR_VAL_DATA_TYPE;
		}

		/*
		 * if (request.data.data==null || request.data.data.equals("")) { return
		 * AppConstants.ERROR1016; }
		 */

		if (request.ts == null || request.ts.trim().equals("")) {
			return AppConstants.ERROR_REQ_TS;
		}

		if (otp == null || otp.trim().equals("")) {
			return AppConstants.ERROR_REQ_OTP_VAL;
		}
				
		return "";
	}

	private static boolean isValidUID(String strUID, String type) {
		if (strUID == null || strUID.trim().equals("")) {
			return false;
		}
		String pattern = "\\d+";
		Pattern replace = Pattern.compile(pattern);
		Matcher m = replace.matcher(strUID);
		switch (type) {
		case "A":
			if (strUID.length() != 12) {
				return false;
			}

			if (!m.matches()) {
				return false;
			}
			return true;
		case "V":
			if (strUID.length() != 16) {
				return false;
			}

			if (!m.matches()) {
				return false;
			}
			return true;
		case "T":
			if (strUID.length() != 72) {
				return false;
			}
			return true;
		default:
			return true;
		}
	}
	
	public static String toHexString(byte[] hash) {
		BigInteger number = new BigInteger(1, hash);
		StringBuilder hexString = new StringBuilder(number.toString(16));
		while (hexString.length() < 64) {
			hexString.insert(0, '0');
		}
		return hexString.toString();
	}
	
	private static final java.text.SimpleDateFormat sdf = 
		    new java.text.SimpleDateFormat("yyyyMMdd");

		public static java.util.Date verifyInput(String input) {
		  if (input != null) {
		    try {
		      java.util.Date ret = sdf.parse(input.trim());
		      if (sdf.format(ret).equals(input.trim())) {
		        return ret;
		      }
		    } catch (Exception e) {
		      //e.printStackTrace();
		      ExceptionLogger.logAsyncKsa("Error validating ci :", e);
		      return null;
		    }
		  }
		  return null;
		}
}
