package com.example.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import com.example.controller.OTPEkycController;
import com.example.models.KUAData;
import com.example.models.Pid;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class XMLBuilder {
	private static final String CERTIFICATE_TYPE = "X.509";
	private static final String JCE_PROVIDER = "BC";
//start - add Skey 	
	private byte[] encXMLPIDData;

	private byte[] encryptedHmacBytes;

	private byte[] encryptedSessionKey;

	private byte[] cipherTextWithTS;

	private String hmac;

	private String certificateIdentifier;

//	  private Encrypter encrypter;
	private Encrypter_Skey encrypter;

	private HashGenerator hashGenerator;

	public FileInputStream inputstream = null;

	public String pidXml = null;

	byte[] encSrcHash;

	public XMLBuilder() throws Exception {
		// System.out.println("Setting Hash Generator and Encrypter");
		this.hashGenerator = new HashGenerator();
		this.encrypter = new Encrypter_Skey("D:\\uidai_auth_encrypt_preprod.cer");
	}
	// end - add Skey

	public static String buildRequestOTP(KUAData request, Pid pid) {
		try {

			XMLBuilder M = new XMLBuilder();
			M.pidXml = M.buildPIDxmlFile(pid);
			M.Generate(M.pidXml);
			// request.data.type = M.cipherTextWithTS;
			// System.out.println("Data value is:" + M.cipherTextWithTS);

			/* PID block data encryption */
			String dataValue = Base64.getMimeEncoder().encodeToString(M.cipherTextWithTS);
			// System.out.println("PID Data value in String:" + dataValue);

			String certificateIdentifier = M.certificateIdentifier;
			byte[] bytes = M.encryptedSessionKey;

			System.out.println(M.certificateIdentifier);
			System.out.println(pid.ts);
			

			String key = new String(M.encryptedSessionKey);
			String dynamic_Skey = Base64.getMimeEncoder().encodeToString(bytes);
			// System.out.println("Dynamic Session Key = " + dynamic_Skey);

			StringWriter stringWriter = new StringWriter();
			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();

			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("KUAData");
			xMLStreamWriter.writeAttribute("xmlns", "http://kua.gujarat.gov.in/kyc/gog-kyc-request");

			xMLStreamWriter.writeStartElement("uid");

			/*
			 * UID Base64 encoded string
			 */
			String uid = Base64.getEncoder().encodeToString(request.uid.getBytes());
			xMLStreamWriter.writeCharacters(uid);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("saTxn");
			xMLStreamWriter.writeCharacters(request.saTxn);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("sa");
			xMLStreamWriter.writeCharacters(request.sa);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("deviceId");
			xMLStreamWriter.writeCharacters(request.deviceId);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("ver");
			xMLStreamWriter.writeCharacters(request.ver);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("ra");
			xMLStreamWriter.writeCharacters(request.ra.value());
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("rc");
			xMLStreamWriter.writeCharacters(request.rc);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("lr");
			xMLStreamWriter.writeCharacters(request.lr);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("pfr");
			xMLStreamWriter.writeCharacters(request.pfr);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("Type");
			xMLStreamWriter.writeCharacters(request.type.value());
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("Info");
			// xMLStreamWriter.writeEmptyElement("Info");
			if (request.info.rdsrno != null) {
				xMLStreamWriter.writeAttribute("rdsrno", request.info.rdsrno);
			} else {
				xMLStreamWriter.writeAttribute("rdsrno", "");
			}
			xMLStreamWriter.writeAttribute("txnType", request.info.txnType);
			xMLStreamWriter.writeAttribute("schemeName", request.info.schemeName);
			if (request.info.buildingNo.isPresent()) {
				xMLStreamWriter.writeAttribute("buildingNo", request.info.buildingNo.get().toString());
			}
			xMLStreamWriter.writeAttribute("buildingName", request.info.buildingName);
			if (request.info.street.isPresent()) {
				xMLStreamWriter.writeAttribute("street", request.info.street.get().toString());
			}
			xMLStreamWriter.writeAttribute("city", request.info.city);
			xMLStreamWriter.writeAttribute("pinCode", request.info.pinCode);
			xMLStreamWriter.writeEndElement();// End Info

			xMLStreamWriter.writeStartElement("ReqType");
			xMLStreamWriter.writeCharacters(request.ReqType);
			xMLStreamWriter.writeEndElement();
			xMLStreamWriter.writeStartElement("Uses");
			xMLStreamWriter.writeAttribute("otp", request.uses.otp);
			xMLStreamWriter.writeAttribute("pin", request.uses.pin);
			xMLStreamWriter.writeAttribute("bio", request.uses.bio);
			xMLStreamWriter.writeAttribute("bt", request.uses.bt);
			xMLStreamWriter.writeAttribute("pfa", request.uses.pfa);
			xMLStreamWriter.writeAttribute("pa", request.uses.pa);
			xMLStreamWriter.writeAttribute("pi", request.uses.pi);
			xMLStreamWriter.writeEndElement();// End Uses

			xMLStreamWriter.writeStartElement("Meta");
			xMLStreamWriter.writeAttribute("rdsId", request.meta.rdsId);
			xMLStreamWriter.writeAttribute("rdsVer", request.meta.rdsVer);
			xMLStreamWriter.writeAttribute("dpId", request.meta.dpId);
			xMLStreamWriter.writeAttribute("dc", request.meta.dc);
			xMLStreamWriter.writeAttribute("mi", request.meta.mi);
			xMLStreamWriter.writeAttribute("mc", request.meta.mc);
			xMLStreamWriter.writeEndElement();// End Meta

			xMLStreamWriter.writeStartElement("Skey");
			xMLStreamWriter.writeAttribute("ci", certificateIdentifier);
			xMLStreamWriter.writeCharacters(dynamic_Skey);
			xMLStreamWriter.writeEndElement();// End Skey

			xMLStreamWriter.writeStartElement("Hmac");

			xMLStreamWriter.writeCharacters(Base64.getMimeEncoder().encodeToString(M.encSrcHash));
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("Data");
			xMLStreamWriter.writeAttribute("type", request.data.type.value());

			request.data.data = dataValue;
			// request.data.data = Base64.getEncoder().encodeToString(buildPIDBlockData(pid,
			// dynamic_Skey, request.ts).getBytes());
			if (request.data.data == null) {
				ExceptionLogger.logAsyncKsa("Error building PID Block" + "Transaction ID:" + request.saTxn + ":");
				return null;
			}

			xMLStreamWriter.writeCharacters(request.data.data);
			xMLStreamWriter.writeEndElement();// End Data

			xMLStreamWriter.writeStartElement("Ts");
			xMLStreamWriter.writeCharacters(request.ts);
			xMLStreamWriter.writeEndElement();// End Data

			xMLStreamWriter.writeEndElement();// End KUAData
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			e.printStackTrace();
			ExceptionLogger.logAsyncKsa("Error building ASA Request:" + "Transaction ID:" + request.saTxn + ":", e);
			return null;
		}
	}

	public void Generate(String pidXml) {
		try {
			AESCipherEncrypter aesCipher = new AESCipherEncrypter();

			// System.out.println("In Ganrater class and value of PID is:" + pidXml);

			byte[] inputData = pidXml.getBytes();
			byte[] sessionKey = aesCipher.generateSessionKey();
			String ts = AESCipherEncrypter.getCurrentISOTimeInUTF8();
			// System.out.println("inputDATA===---> " + inputData);
			// System.out.println("sessionKey===---> " + sessionKey);
			// System.out.println("ts PID generate time===---> " + ts);

			this.cipherTextWithTS = aesCipher.encrypt(inputData, sessionKey, ts);

			byte[] srcHash = aesCipher.generateHash(inputData);
			byte[] iv = aesCipher.generateIv(ts);
			// System.out.println("iv=====" + iv);
			byte[] aad = aesCipher.generateAad(ts);
			// System.out.println("ts=====" + ts);
			this.encSrcHash = aesCipher.encryptDecryptUsingSessionKey(true, sessionKey, iv, aad, srcHash);
			SimpleDateFormat df2 = new SimpleDateFormat("yyyyMMdd");
			this.certificateIdentifier = df2.format(this.encrypter.getCertExpiryDate());
			this.encryptedSessionKey = this.encrypter.encryptUsingPublicKey(sessionKey);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String byteArrayToHexString(byte[] bytes) {
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < bytes.length; i++)
			result.append(Integer.toString((bytes[i] & 0xFF) + 256, 16).substring(1));
		return result.toString();
	}

	/*
	 * public static String buildPIDBlockData(Pid pid, String dynamicsKey, String
	 * salt) { try { StringWriter stringWriter = new StringWriter();
	 * 
	 * XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
	 * XMLStreamWriter xMLStreamWriter =
	 * xMLOutputFactory.createXMLStreamWriter(stringWriter);
	 * xMLStreamWriter.writeStartDocument("UTF-8", "1.0");
	 * 
	 * xMLStreamWriter.writeStartElement("Pid");
	 * xMLStreamWriter.writeAttribute("ts", pid.ts);
	 * xMLStreamWriter.writeAttribute("ver", pid.ver);
	 * xMLStreamWriter.writeAttribute("wadh", pid.wadh);
	 * 
	 * if (pid.demo.lang != null && pid.demo.lang.isPresent()) {
	 * xMLStreamWriter.writeStartElement("Demo"); //
	 * xMLStreamWriter.writeAttribute("lang", pid.demo.lang.get().value());
	 * xMLStreamWriter.writeAttribute("lang",""); xMLStreamWriter.writeEndElement();
	 * } xMLStreamWriter.writeStartElement("Pv");
	 * xMLStreamWriter.writeAttribute("otp", pid.pv.otp.toString());
	 * xMLStreamWriter.writeEndElement();
	 * 
	 * xMLStreamWriter.writeEndElement();// End Pid
	 * xMLStreamWriter.writeEndDocument(); xMLStreamWriter.flush();
	 * xMLStreamWriter.close();
	 * 
	 * String xmlString = stringWriter.getBuffer().toString(); xmlString =
	 * xmlString.replace("?>", " standalone=\"yes\"?>"); System.out.println();
	 * System.out.println("PID block xml file => :" + xmlString);
	 * System.out.println(); // RSA Encryption of sessionkey
	 * 
	 * FileInputStream fin = new FileInputStream(PropertiesUtil.getCerPath());
	 * CertificateFactory f = CertificateFactory.getInstance("X.509");
	 * X509Certificate certificate = (X509Certificate) f.generateCertificate(fin);
	 * PublicKey publicKey = certificate.getPublicKey();
	 * 
	 * // System.out.println("publicKey : " + publicKey);
	 * 
	 * 
	 * // Start - PID block data FileInputStream fileInputStream = null; PublicKey
	 * publicKey_Original = null; CertificateFactory certFactory =
	 * CertificateFactory.getInstance(CERTIFICATE_TYPE, JCE_PROVIDER);
	 * fileInputStream = new FileInputStream(new
	 * File("D:\\uidai_auth_encrypt_preprod.cer")); X509Certificate cert =
	 * (X509Certificate) certFactory.generateCertificate(fileInputStream);
	 * publicKey_Original =cert.getPublicKey();
	 * System.out.println("publicKey_Original => "+publicKey_Original); // end - PID
	 * block data
	 * 
	 * 
	 * Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	 * cipher.init(Cipher.ENCRYPT_MODE, publicKey_Original);
	 * 
	 * byte[] b=cipher.doFinal(dynamicsKey.getBytes(StandardCharsets.UTF_8)); String
	 * encryptedKey = Base64.getEncoder().encodeToString(b);
	 * System.out.println("RSA encrypted key : " + encryptedKey);
	 * stringWriter.close();
	 * 
	 * // create aES 256 key from dynamic RSA encrypted key PBEKeySpec spec = new
	 * PBEKeySpec(encryptedKey.toCharArray(), salt.getBytes(StandardCharsets.UTF_8),
	 * 65537, 256); SecretKey key =
	 * SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec);
	 * 
	 * byte[] IV = new byte[12]; IV = salt.substring(salt.length() - 12).getBytes();
	 * 
	 * System.out.println("req.data.data :" + xmlString);
	 * 
	 * xmlString =
	 * AES256.encryptGCMNOPADDING(xmlString.getBytes(StandardCharsets.UTF_8), key,
	 * IV); System.out.println("req.data.data encrypted:" + xmlString);
	 * 
	 * // String decryptGCMNOPADDING = //
	 * //AES256.decryptGCMNOPADDING(xmlString.getBytes(StandardCharsets.UTF_8), key,
	 * IV); // System.out.println("req.data.data // decrypted:"+xmlString);
	 * 
	 * return xmlString; } catch (Exception e) { e.printStackTrace();
	 * ExceptionLogger.logAsyncKsa("Error building PID Block Request:", e); return
	 * null; } }
	 */
	public static String buildPIDBlockHMAC(String dataValue, Pid pid, String dynamicSkey, String salt) {
		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("Pid");
			xMLStreamWriter.writeAttribute("ts", pid.ts);
			System.out.println(pid.ts);
			xMLStreamWriter.writeAttribute("ver", pid.ver);
			xMLStreamWriter.writeAttribute("wadh", pid.wadh);

			if (pid.demo.lang != null && pid.demo.lang.isPresent()) {
				xMLStreamWriter.writeStartElement("Demo");
				xMLStreamWriter.writeAttribute("lang", "");
//				xMLStreamWriter.writeAttribute("lang", pid.demo.lang.get().value());
				xMLStreamWriter.writeEndElement();
			}
			xMLStreamWriter.writeStartElement("Pv");
			xMLStreamWriter.writeAttribute("otp", pid.pv.otp.toString());
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeEndElement();// End Pid
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
//			xmlString=buildPIDxmlFile();
			stringWriter.close();
			// Getting decoder
			/*
			 * Base64.Decoder decoder = Base64.getDecoder(); // Decoding string String dStr
			 * = new String(decoder.decode(sKey)); if (dStr.length() != 16) { return null; }
			 */
			// System.out.println("PID Block :" + xmlString);
			xmlString = new SHA256Encrypt().getSHAHash(xmlString);
			// System.out.println("SHA256 HASH of PID Block :" + xmlString);
			// System.out.println("dynamicSkey : "+dynamicSkey);
			xmlString = Encryption.SHAEncryptAndEncodedWithKey(xmlString, dynamicSkey, salt);
			// System.out.println("xmlString PID Block Encrypted using sessionkey and
			// encoded :" + xmlString);
			return xmlString;
		} catch (Exception e) {
			e.printStackTrace();
			ExceptionLogger.logAsyncKsa("Error building PID Block Request:", e);
			return null;
		}
	}

	public static String rendomSkey() throws NoSuchAlgorithmException {
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
		SecureRandom secureRandom = new SecureRandom();
		int keyBitSize = 256;
		keyGenerator.init(keyBitSize, secureRandom);
		SecretKey secretKey = keyGenerator.generateKey();
		String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
		return encodedKey;

	}

	public static String buildErrorRequestOTP(String error) {
		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("KUAData");
			xMLStreamWriter.writeAttribute("xmlns", "http://kua.gujarat.gov.in/kyc/gog-kyc-request");

			xMLStreamWriter.writeStartElement("error");
			xMLStreamWriter.writeCharacters(error);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeEndElement();// End KUAData
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			e.printStackTrace();
			ExceptionLogger.logAsyncKsa("Error building Error Request", e);
			return null;
		}
	}

	private static String getsKey(String sKey, String salt) {

		// System.out.println("sKey :" + sKey);
		// sKey= new String(Base64.getDecoder().decode(sKey.getBytes()));
		// System.out.println("Decoded sKey :"+sKey);

		String cipherText = Encryption.AESEncrypt(sKey, sKey, salt);
		// System.out.println("Encrypted sKey :" + cipherText);
		cipherText = new String(Base64.getEncoder().encode(cipherText.getBytes()));
		// System.out.println("Encoded sKey :" + cipherText);

		/*
		 * cipherText=new String(Base64.getDecoder().decode(cipherText.getBytes()));
		 * System.out.println("Decoded sKey :" + cipherText);
		 * 
		 * sKey=Encryption.AESDecrypt(cipherText,sKey,salt);
		 * System.out.println("Decrypted sKey :" + sKey);
		 */
		return cipherText;
	}

	public String buildPIDxmlFile(Pid pid) {

		try {
			StringWriter stringWriter = new StringWriter();
			XMLBuilder M = new XMLBuilder();
			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
//			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("Pid");
			xMLStreamWriter.writeAttribute("ts", pid.ts);
			xMLStreamWriter.writeAttribute("ver", pid.ver);
			// xMLStreamWriter.writeAttribute("wadh", pid.wadh);

			if (pid.demo.lang != null && pid.demo.lang.isPresent()) {
				xMLStreamWriter.writeStartElement("Demo");
//					xMLStreamWriter.writeAttribute("lang", pid.demo.lang.get().value());
				xMLStreamWriter.writeAttribute("lang", "");
				xMLStreamWriter.writeEndElement();
			}
			xMLStreamWriter.writeStartElement("Pv");
			xMLStreamWriter.writeAttribute("otp", pid.pv.otp.toString());
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeEndElement();// End Pid
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
//			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
			// System.out.println();
			// System.out.println("PID block xml file => :" + xmlString);
			// System.out.println();
			// RSA Encryption of sessionkey
			return xmlString;
		} catch (Exception e) {
			e.printStackTrace();
			ExceptionLogger.logAsyncKsa("Error building PID Block Request:", e);
			return null;
		}
	}

	// *********************************** Getting Parameter From Request
	// ***********************************

	public static Pid parsePIDInput(HttpServletRequest httpRequest) {
		try {
			Pid pid = new Pid();
			pid.ts = AESCipherEncrypter.getCurrentISOTimeInUTF8();
			pid.ver = "2.0";
			String deASttribute = "Y";
			if (httpRequest.getParameter("de") == null || httpRequest.getParameter("de").trim().equals("")) {
				deASttribute = "Y";
			} else {
				deASttribute = httpRequest.getParameter("de");
			}
			pid.wadh = new SHA256Encrypt()
					.encrypt(pid.ts + pid.ver + pid.ts + httpRequest.getParameter("ra") + httpRequest.getParameter("rc")
							+ httpRequest.getParameter("lr") + deASttribute + httpRequest.getParameter("pfr"));

			pid.pv.otp = httpRequest.getParameter("otpVal");
			return pid;
		} catch (Exception e) {
			// e.printStackTrace();
			ExceptionLogger.logAsyncKua("Error fetching request values from Request PID Block:", e);
			return null;
		}
	}
}
//}
