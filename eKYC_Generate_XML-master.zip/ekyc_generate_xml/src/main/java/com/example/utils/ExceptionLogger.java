/**
 * 
 */
package com.example.utils;

import org.apache.log4j.Logger;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class ExceptionLogger {
	private static final Logger KuaLogger = Logger.getLogger("kua");
	private static final Logger KsaLogger = Logger.getLogger("ksa");
	private static final Logger DbFailLogger = Logger.getLogger("dbFail");

	public static void logAsyncKua(String message, Exception e) {
		KuaLogger.error(message, e);
	}

	public static void logAsyncKsa(String message, Exception e) {
		KsaLogger.error(message, e);
	}

	public static void logAsyncKua(String message) {
		KuaLogger.error(message);
	}

	public static void logAsyncKsa(String message) {
		KsaLogger.error(message);
	}

	public static void logAsyncDbFail(String message) {
		DbFailLogger.error(message);
	}

}
