package com.example.utils;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class SHA256Encrypt {
	
	// *********************************** SHA256 Encryption ***********************************
		public String encrypt(String originalString) {
			try {
				MessageDigest digest = null;

				digest = MessageDigest.getInstance("SHA-256");
				
				final byte[] hashbytes = digest.digest(originalString.getBytes(StandardCharsets.UTF_8));
				String sha3_256hex = bytesToHex(hashbytes);
				return sha3_256hex;
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			return null;
		}

		private static String bytesToHex(byte[] hash) {
			StringBuffer hexString = new StringBuffer();
			for (int i = 0; i < hash.length; i++) {
				String hex = Integer.toHexString(0xff & hash[i]);
				if (hex.length() == 1)
					hexString.append('0');
				hexString.append(hex);
			}
			return hexString.toString();
		}
		
		public String encrypt(String originalString,String sKey) {
			try {
				MessageDigest digest = null;

				digest = MessageDigest.getInstance("SHA-256");
				
				final byte[] hashbytes = digest.digest(originalString.getBytes(StandardCharsets.UTF_8));
				String sha3_256hex = bytesToHex(hashbytes);
				//encrypt using skey
				sha3_256hex=encryptUsingSessionKey(sha3_256hex,sKey);
				//encode using base64
				sha3_256hex = Base64.getEncoder().encode(sha3_256hex.getBytes()).toString();
				return sha3_256hex;
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			return null;
		}
		
		public static String encryptUsingSessionKey(String value,String sKey) {
			try {
				IvParameterSpec iv = new IvParameterSpec(PropertiesUtil.getInitVector().getBytes(StandardCharsets.UTF_8));
				SecretKeySpec skeySpec = new SecretKeySpec(sKey.getBytes(StandardCharsets.UTF_8), "AES");

				Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
				cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

				byte[] encrypted = cipher.doFinal(value.getBytes());
				return bytesToHex(encrypted);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;
		}
		
		public String getSHAHash(String originalString) {
			try {
				MessageDigest digest = null;

				digest = MessageDigest.getInstance("SHA-256");
				
				final byte[] hashbytes = digest.digest(originalString.getBytes(StandardCharsets.UTF_8));
				//BigInteger noHash = new BigInteger(1, hashbytes);
				//String hash = noHash.toString(16);
				return new String(hashbytes);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			return null;
		}
}
