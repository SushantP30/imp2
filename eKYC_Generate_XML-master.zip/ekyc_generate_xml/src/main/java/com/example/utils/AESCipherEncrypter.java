package com.example.utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.AESEngine;
import org.bouncycastle.crypto.modes.GCMBlockCipher;
import org.bouncycastle.crypto.params.AEADParameters;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class AESCipherEncrypter {
	 public static final int AES_KEY_SIZE_BITS = 256;
	  
	  public static final int IV_SIZE_BITS = 96;
	  
	  public static final int AAD_SIZE_BITS = 128;
	  
	  public static final int AUTH_TAG_SIZE_BITS = 128;
	  
	  private static final String JCE_PROVIDER = "BC";
	  
	  private static final String ASYMMETRIC_ALGO = "RSA/ECB/PKCS1Padding";
	  
	  private static final int SYMMETRIC_KEY_SIZE = 256;
	  
	  private static final String CERTIFICATE_TYPE = "X.509";
	  
	  private PublicKey publicKey;
	  
	  private Date certExpiryDate;
	  
	  private String algorithm = "SHA-256";
	  
	  private static final String SECURITY_PROVIDER = "BC";
	  
	  private int HMAC_SIZE = 32;
	  
	  static {
	    Security.addProvider((Provider)new BouncyCastleProvider());
	  }
	  
	  AESCipherEncrypter(String publicKeyFileName) {
	    FileInputStream fileInputStream = null;
	    try {
	      CertificateFactory certFactory = CertificateFactory.getInstance("X.509", "BC");
	      fileInputStream = new FileInputStream(new File(publicKeyFileName));
	      X509Certificate cert = (X509Certificate)certFactory.generateCertificate(fileInputStream);
	      this.publicKey = cert.getPublicKey();
	      this.certExpiryDate = cert.getNotAfter();
	    } catch (Exception e) {
	      e.printStackTrace();
	      throw new RuntimeException("Could not intialize encryption module", e);
	    } finally {
	      if (fileInputStream != null)
	        try {
	          fileInputStream.close();
	        } catch (IOException e) {
	          e.printStackTrace();
	        }  
	    } 
	  }
	  
	  public AESCipherEncrypter() {}
	  
	  public byte[] encryptDecryptUsingSessionKey(boolean cipherOperation, byte[] skey, byte[] iv, byte[] aad, byte[] data) throws IllegalStateException, InvalidCipherTextException {
	    AEADParameters aeadParam = new AEADParameters(new KeyParameter(skey), 128, iv, aad);
	    GCMBlockCipher gcmb = new GCMBlockCipher((BlockCipher)new AESEngine());
	    gcmb.init(cipherOperation, (CipherParameters)aeadParam);
	    int outputSize = gcmb.getOutputSize(data.length);
	    byte[] result = new byte[outputSize];
	    int processLen = gcmb.processBytes(data, 0, data.length, result, 0);
	    gcmb.doFinal(result, processLen);
	    return result;
	  }
	  
	  public byte[] encryptUsingPublicKey(byte[] data) throws IOException, GeneralSecurityException {
	    Cipher pkCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
	    pkCipher.init(1, this.publicKey);
	    byte[] encSessionKey = pkCipher.doFinal(data);
	    return encSessionKey;
	  }
	  
	  public byte[] generateSessionKey() throws NoSuchAlgorithmException, NoSuchProviderException {
	    KeyGenerator kgen = KeyGenerator.getInstance("AES", "BC");
	    kgen.init(256);
	    SecretKey key = kgen.generateKey();
	    byte[] symmKey = key.getEncoded();
	    return symmKey;
	  }
	  
	  public static String getCurrentISOTimeInUTF8() {
	    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
	    String timeNow = df.format(new Date());
	    return timeNow;
	  }
	  
	  public byte[] generateIv(String ts) throws UnsupportedEncodingException {
	    return getLastBits(ts, 12);
	  }
	  
	  public byte[] generateAad(String ts) throws UnsupportedEncodingException {
	    return getLastBits(ts, 16);
	  }
	  
	  public byte[] getLastBits(String ts, int bits) throws UnsupportedEncodingException {
	    byte[] tsInBytes = ts.getBytes("UTF-8");
	    return Arrays.copyOfRange(tsInBytes, tsInBytes.length - bits, tsInBytes.length);
	  }
	  
//	  public static void main(String[] args) throws Exception {
//		 AESCipherEncrypter aesCipher = new AESCipherEncrypter();
//	    byte[] inputData = "UIDAI World!".getBytes();
//	    byte[] sessionKey = aesCipher.generateSessionKey();
//	    String ts = getCurrentISOTimeInUTF8();
//	    //System.out.println("Plain text Hex  ---> " + byteArrayToHexString(inputData));
//	    byte[] cipherTextWithTS = aesCipher.encrypt(inputData, sessionKey, ts);
//	    System.out.println("Cipher text Hex ---> " + byteArrayToHexString(cipherTextWithTS));
//	    byte[] srcHash = aesCipher.generateHash(inputData);
//	    byte[] iv = aesCipher.generateIv(ts);
//	    byte[] aad = aesCipher.generateAad(ts);
//	    byte[] pidData = aesCipher.encrypt(inputData, sessionKey, ts);
//	    byte[] encSrcHash = aesCipher.encryptDecryptUsingSessionKey(true, sessionKey, iv, aad, srcHash);
//	    System.out.println("encrypted Hash Cipher text Hex ---> " + byteArrayToHexString(encSrcHash));
//	    byte[] decryptedText = aesCipher.decrypt(cipherTextWithTS, sessionKey, encSrcHash);
//	    System.out.println("Decrypted Plain text Hex  ---> " + byteArrayToHexString(decryptedText));
//	  }
	  
	  public static String byteArrayToHexString(byte[] bytes) {
	    StringBuffer result = new StringBuffer();
	    for (int i = 0; i < bytes.length; i++)
	      result.append(Integer.toString((bytes[i] & 0xFF) + 256, 16)
	          .substring(1)); 
	    return result.toString();
	  }
	  
	  private static byte[] hexStringToByteArray(String data) {
	    int k = 0;
	    byte[] results = new byte[data.length() / 2];
	    for (int i = 0; i < data.length(); ) {
	      results[k] = (byte)(Character.digit(data.charAt(i++), 16) << 4);
	      results[k] = (byte)(results[k] + (byte)Character.digit(data.charAt(i++), 16));
	      k++;
	    } 
	    return results;
	  }
	  
	  public byte[] encrypt(byte[] inputData, byte[] sessionKey, String ts) throws IllegalStateException, InvalidCipherTextException, Exception {
	  //  System.out.println("ts value in encrypt function ===" + ts);
	  //  System.out.println("inputData value in encrypt function ===" + inputData);
	    byte[] iv = generateIv(ts);
	    byte[] aad = generateAad(ts);
	    byte[] cipherText = encryptDecryptUsingSessionKey(true, sessionKey, iv, aad, inputData);
	    byte[] tsInBytes = ts.getBytes("UTF-8");
	    byte[] packedCipherData = new byte[cipherText.length + tsInBytes.length];
	    System.arraycopy(tsInBytes, 0, packedCipherData, 0, tsInBytes.length);
	    System.arraycopy(cipherText, 0, packedCipherData, tsInBytes.length, cipherText.length);
	    return packedCipherData;
	  }
	  
	  public byte[] decrypt(byte[] inputData, byte[] sessionKey, byte[] encSrcHash) throws IllegalStateException, InvalidCipherTextException, Exception {
	    byte[] bytesTs = Arrays.copyOfRange(inputData, 0, 19);
	    String ts = new String(bytesTs);
	    byte[] cipherData = Arrays.copyOfRange(inputData, bytesTs.length, inputData.length);
	    byte[] iv = generateIv(ts);
	    byte[] aad = generateAad(ts);
	    byte[] plainText = encryptDecryptUsingSessionKey(false, sessionKey, iv, aad, cipherData);
	    byte[] srcHash = encryptDecryptUsingSessionKey(false, sessionKey, iv, aad, encSrcHash);
	    System.out.println("Decrypted HAsh in cipher text: " + byteArrayToHexString(srcHash));
	    boolean result = validateHash(srcHash, plainText);
	    if (!result)
	      throw new Exception("Integrity Validation Failed : The original data at client side and the decrypted data at server side is not identical"); 
	    System.out.println("Hash Validation is Successful!!!!!");
	    return plainText;
	  }
	  
	  private boolean validateHash(byte[] srcHash, byte[] plainTextWithTS) throws Exception {
	    byte[] actualHash = generateHash(plainTextWithTS);
	    System.out.println("Hash of actual plain text in cipher hex:--->" + byteArrayToHexString(actualHash));
	    if ((new String(srcHash, "UTF-8")).equals(new String(actualHash, "UTF-8")))
	      return true; 
	    return false;
	  }
	  
	  public byte[] generateHash(byte[] message) throws Exception {
	    byte[] hash = null;
	    try {
	      MessageDigest digest = MessageDigest.getInstance(this.algorithm, "BC");
	      digest.reset();
	      this.HMAC_SIZE = digest.getDigestLength();
	      hash = digest.digest(message);
	    } catch (GeneralSecurityException e) {
	      throw new Exception(
	          "SHA-256 Hashing algorithm not available");
	    } 
	    return hash;
	  }
	  
	  public Date getCertExpiryDate() {
	    return this.certExpiryDate;
	  }
	  
	  public String getCertificateIdentifier() {
	    SimpleDateFormat ciDateFormat = new SimpleDateFormat("yyyyMMdd");
	    ciDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
	    String certificateIdentifier = ciDateFormat.format(this.certExpiryDate);
	    return certificateIdentifier;
	  }

}
