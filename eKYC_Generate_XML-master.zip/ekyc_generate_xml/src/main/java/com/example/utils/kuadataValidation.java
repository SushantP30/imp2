package com.example.utils;

import javax.servlet.http.HttpServletRequest;

public class kuadataValidation {
	
	public static String parseInputValidation(HttpServletRequest httpRequest) {
		// Below commented values are set internally so no need to set them,
		// default values will be used
		if (httpRequest.getParameter("uid") == null || httpRequest.getParameter("uid").trim().equals("")) {
			return AppConstants.ERROR_REQ_UID;
		}
		
		if (httpRequest.getParameter("saTxn") == null || !httpRequest.getParameter("saTxn").startsWith("AuthOtp")) {
			return AppConstants.ERROR_VAL_SATXN;
		}

		if (httpRequest.getParameter("sa") == null || httpRequest.getParameter("sa").trim().equals("")) {
			return AppConstants.ERROR_REQ_SA;
		}
		/*
		 * if (httpRequest.getParameter("deviceId") == null ||
		 * httpRequest.getParameter("deviceId").trim().equals("")) { return
		 * AppConstants.ERROR_REQ_DEVID; }
		 */
		
		if (httpRequest.getParameter("ra") == null) {
			return AppConstants.ERROR_REQ_RA;
		}
		if(!httpRequest.getParameter("ra").equalsIgnoreCase("O")) {
			return AppConstants.ERROR_VAL_RA;
		}

		if (httpRequest.getParameter("rc") == null || (httpRequest.getParameter("rc").toString().trim().equals(""))) {
			return AppConstants.ERROR_REQ_RC;
		}
		
		if (!httpRequest.getParameter("rc").equalsIgnoreCase("Y")) {
			return AppConstants.ERROR_VAL_RC;
		}
		
		if (httpRequest.getParameter("lr") == null || (httpRequest.getParameter("lr").toString().trim().equals(""))
				|| !(httpRequest.getParameter("lr").toString().equalsIgnoreCase("Y") || httpRequest.getParameter("lr").toString().equalsIgnoreCase("N"))) {
			return AppConstants.ERROR_REQ_LR;
		}

		if (httpRequest.getParameter("pfr") == null || httpRequest.getParameter("pfr").toString().trim().equals("")) {
			return AppConstants.ERROR_REQ_PFR;
		}
		
		if (!(httpRequest.getParameter("pfr").equalsIgnoreCase("Y") || httpRequest.getParameter("pfr").equalsIgnoreCase("N"))) {
			return AppConstants.ERRORK_546;
		}
		
		if(httpRequest.getParameter("type")==null || httpRequest.getParameter("type").trim().equals("")) {
			return AppConstants.ERROR1015;
		}
		
		if (httpRequest.getParameter("schemeName") == null || httpRequest.getParameter("schemeName").trim().equals("")) {
			return AppConstants.ERROR_REQ_SCHEME;
		}
		
		if (httpRequest.getParameter("buildingName") == null || httpRequest.getParameter("buildingName").trim().equals("")) {
			return AppConstants.ERROR_REQ_BUILDING;
		}

		if (httpRequest.getParameter("city") == null || httpRequest.getParameter("city").trim().equals("")) {
			return AppConstants.ERROR_REQ_CITY;
		}
		if (httpRequest.getParameter("pinCode") == null || httpRequest.getParameter("pinCode").equals("")) {
			return AppConstants.ERROR_REQ_PINCODE;
		}

		if (httpRequest.getParameter("pinCode").length() != 6) {
			return AppConstants.ERROR_VAL_PINCODE;
		}
		

		if (httpRequest.getParameter("otp")==null || !httpRequest.getParameter("otp").equalsIgnoreCase("y")) {
			return AppConstants.ERROR_VAL_OTP;
		}
		
		/*
		 * if (httpRequest.getParameter("ci") == null ||
		 * httpRequest.getParameter("ci").trim().equals("")) { return
		 * AppConstants.ERROR_REQ_CI; } if (verifyInput(httpRequest.getParameter("ci"))
		 * == null) { return AppConstants.ERROR_VAL_CI; }
		 */
		/*
		 * if (httpRequest.getParameter("sKey") == null) { return
		 * AppConstants.ERROR_REQ_SKEY; }
		 */
		
		// Getting decoder  
		/*
		 * Base64.Decoder decoder = Base64.getDecoder(); // Decoding string String sKey
		 * = new String(decoder.decode(PropertiesUtil.getSessionKey()));
		 * 
		 * if (sKey.equals("") || sKey.length()!=16) { return
		 * AppConstants.ERROR_VAL_SKEY; }
		 */

		/*
		 * if (request.skey.Data==null || request.skey.Data.equals("")) { return
		 * AppConstants.ERROR1004; }
		 */
		
		/*
		 * if (httpRequest.getParameter("hmac") == null) { return
		 * AppConstants.ERROR1017; }
		 * 
		 * if (httpRequest.getParameter("data") == null ||
		 * httpRequest.getParameter("data").trim().equals("")) { return
		 * AppConstants.ERROR_REQ_DATA; }
		 */

		if (httpRequest.getParameter("otpVal") == null || httpRequest.getParameter("otpVal").trim().equals("")) {
			return AppConstants.ERROR_REQ_OTP_VAL;
		}
				
		return "";
	}
	private static final java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyyMMdd");

		public static java.util.Date verifyInput(String input) {
		  if (input != null) {
		    try {
		      java.util.Date ret = sdf.parse(input.trim());
		      if (sdf.format(ret).equals(input.trim())) {
		        return ret;
		      }
		    } catch (Exception e) {
		      //e.printStackTrace();
		      ExceptionLogger.logAsyncKsa("Error validating ci :", e);
		      return null;
		    }
		  }
		  return null;
		}

}
