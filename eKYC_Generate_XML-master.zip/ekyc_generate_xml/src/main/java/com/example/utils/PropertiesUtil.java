package com.example.utils;

import java.util.Base64;
import java.util.ResourceBundle;

/**
 * 
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class PropertiesUtil {
	private static ResourceBundle messageBundle = ResourceBundle.getBundle("aadhar");

	private static String getValue(String key) {
		return messageBundle.getString(key).trim();
	}
	
	public static String getAESEncryptionKey() {
		return getValue("AES256.encryptionKey");
	};
	
	public static String getInitVector() {
		return getValue("AES256.initVector");
	};
	
	public static String getSessionKey() {
		return getValue("sKey");
	};
	
	public static String getCerPath() {
		return getValue("cerPath");
	};
	
}
