/**
 * 
 */
package com.example.utils;

import java.time.Duration;

import javax.xml.namespace.QName;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public interface AppConstants {
	public Duration TIMEOUT = Duration.ofSeconds(10);
	// attributes for node Auth
	public QName QNAME_AC = new QName("ac");
	public QName QNAME_LK = new QName("lk");
	public QName QNAME_RC = new QName("rc");
	public QName QNAME_SA = new QName("sa");
	public QName QNAME_TID = new QName("tid");
	public QName QNAME_TXN = new QName("txn");
	public QName QNAME_UID = new QName("uid");
	public QName QNAME_VER = new QName("ver");
	// attributes for node Uses
	public QName QNAME_PI = new QName("pi");
	public QName QNAME_PA = new QName("pa");
	public QName QNAME_PFA = new QName("pfa");
	public QName QNAME_BIO = new QName("bio");
	public QName QNAME_BT = new QName("bt");
	public QName QNAME_PIN = new QName("pin");
	public QName QNAME_OTP = new QName("otp");
	// attributes for node Meta
	public QName QNAME_DPID = new QName("dpId");
	public QName QNAME_RDSID = new QName("rdsId");
	public QName QNAME_RDSVER = new QName("rdsVer");
	public QName QNAME_DC = new QName("dc");
	public QName QNAME_MI = new QName("mi");
	public QName QNAME_MC = new QName("mc");
	// attributes for node Skey
	public QName QNAME_CI = new QName("ci");

	public QName QNAME_TYPE = new QName("type");
	public QName QNAME_CH = new QName("ch");
	// attributes for node Info
	public QName QNAME_RDSRNO = new QName("rdsrno");
	public QName QNAME_TXNTYPE = new QName("txnType");
	public QName QNAME_SCHEMENAME = new QName("schemeName");
	public QName QNAME_BUILDINGNO = new QName("buildingNo");
	public QName QNAME_BUILDINGNAME = new QName("buildingName");
	public QName QNAME_STREET = new QName("street");
	public QName QNAME_CITY = new QName("city");
	public QName QNAME_PINCODE = new QName("pinCode");
	public QName QNAME_XMLNS = new QName("xmlns");
	// attributes for CIDR Response XML
	public QName QNAME_RET = new QName("ret");
	public QName QNAME_CODE = new QName("code");
	public QName QNAME_ERR = new QName("err");
	public QName QNAME_TS = new QName("ts");
	public QName QNAME_ACTN = new QName("actn");
	public QName QNAME_INFO = new QName("info");
	// error constants
	public String ERROR1001 = "1001:Xml is not as per the GOG AUA-ASA XSD Standard";
	public String ERROR1015 = "1015:Aadhaar number type is invalid";
	public String ERROR1007 = "1007:UID/VID/UID Token is invalid";
	public String ERROR1012 = "1012:Transaction id is invalid";
	public String ERROR1004 = "1004:Public key not found";
	public String ERROR1016 = "1016:Data tag is invalid";
	public String ERROR1017 = "1017:Hmac tag is invalid";
	public String ERROR1011 = "1011:Version tag value is invalid";
	public String ERROR1008 = "1008:ReqType is invalid";
	public String ERROR1014 = "1014:SUB-AUA code is invalid";
	public String ERROR2002 = "2002 :AUA license key expired or invalid";
	public String ERROR3001 = "3001: CIDR Service is not available";// CIDR Services is not availbale
	public String ERROR3002 = "3002: CIDR Service is not available";// ASA Services is not availbale
	public String ERROR3003 = "3003: CIDR Service is not available";// AUA Services is not availbale
	public String ERRORK_546 = "K-546: Invalid value for “pfr” attribute";

	// Required messages
	public String ERROR_REQ_UID = "1007:UID is required";
	public String ERROR_REQ_RA = "Ra is required";
	public String ERROR_REQ_RC = "Rc is required";
	public String ERROR_REQ_SA = "SubAUACode is required";
	public String ERROR_REQ_VER = "Ver is required.It should be 2.5.";
	public String ERROR_REQ_TXN = "Txn is required";
	public String ERROR_REQ_REQTYPE = "ReqType is required";
	public String ERROR_REQ_DEVID = "DeviceId is required";
	public String ERROR_REQ_TYPE = "Type is required";
	public String ERROR_REQ_TS = "Ts is required";

	public String ERROR_REQ_USES = "Uses is required";
	public String ERROR_REQ_BT = "Uses.bt should be blank";
	public String ERROR_REQ_PI = "Uses.Pi is required";
	public String ERROR_REQ_PA = "Uses.Pa is required";
	public String ERROR_REQ_PFA = "Uses.pfa is required";
	public String ERROR_REQ_PIN = "Uses.pin is required";
	public String ERROR_REQ_OTP = "Uses.otp is required";

	public String ERROR_REQ_META = "Meta is required";
	public String ERROR_REQ_DPID = "Meta.dpId must be blank";
	public String ERROR_REQ_RDSID = "Meta.rdsId must be blank";
	public String ERROR_REQ_RDSVER = "Meta.rdsVer must be blank";
	public String ERROR_REQ_DC = "Meta.dc must be blank";
	public String ERROR_REQ_MI = "Meta.mi must be blank";
	public String ERROR_REQ_MC = "Meta.mc must be blank";

	public String ERROR_REQ_SKEY = "Skey is required";
	public String ERROR_REQ_CI = "Skey.ci is required";
	public String ERROR_REQ_DATA = "Data is required";

	public String ERROR_REQ_INFO = "Info is required";
	public String ERROR_REQ_RDSRN = "Info.rdsrn is required";
	public String ERROR_REQ_SCHEME = "Info.scheme is required";
	public String ERROR_REQ_BUILDING = "Info.building is required";
	public String ERROR_REQ_CITY = "Info.city is required";
	public String ERROR_REQ_PINCODE = "Info.pincode is required";
	public String ERROR_REQ_AC = "AUA Code is required";
	public String ERROR_REQ_TID = "tid is required";
	public String ERROR_REQ_LK = "license key is required";
	public String ERROR_REQ_SIGN = "Signature is required";

	// Invalid value messages
	public String ERROR_VAL_PINCODE = "Info.pincode is invalid";
	public String ERROR_VALID_RC = "Rc must be present and value must be 'Y'";
	public String ERROR_VAL_PI = "Uses.Pi is missing or invalid";
	public String ERROR_VAL_PA = "Uses.Pa is missing or invalid";
	public String ERROR_VAL_PFA = "Uses.pfa is missing or invalid";
	public String ERROR_VAL_BIO = "Uses.bio is missing or invalid";
	public String ERROR_VAL_PIN = "Uses.pin is missing or invalid";
	public String ERROR_VAL_OTP = "Uses.otp is missing or invalid";

	// meta attributes must be blank for request type demo and otpAuth
	public String ERROR_VAL_DPID = "Meta.dpId value must be blank for request type demo and otpAuth";
	public String ERROR_VAL_RDSID = "Meta.rdsId value must be blank for request type demo and otpAuth";
	public String ERROR_VAL_RDSVER = "Meta.rdsVer value must be blank for request type demo and otpAuth";
	public String ERROR_VAL_DC = "Meta.dc value must be blank for request type demo and otpAuth";
	public String ERROR_VAL_MI = "Meta.mi value must be blank for request type demo and otpAuth";
	public String ERROR_VAL_MC = "Meta.mc value must be blank for request type demo and otpAuth";

	public String ERROR_VAL_BT = "Uses.bt has invalid value";
	public String ERROR_VAL_BT_2 = "Uses.bt must be blank";

	public String ERROR_VAL_TXNTYPE = "Info.txnType has invalid value";
	public String ERROR_VAL_CH = "4001: Value of ch is invalid";
	public String ERROR_VAL_TID = "Value of tid is required";

	public String ERROR_VAL_SATXN = "saTxn is required.It should start with AuthOtp";
	public String ERROR_REQ_LR = "Lr is required. Valid values are Y or N";
	public String ERROR_REQ_PFR = "Pfr is required. Valid values are Y or N";
	public String ERROR_VAL_RDSRNO = "Info.rdsrno has invalid value";
	public String ERROR_REQ_VAL_TYPE = "Request Type is required. Only valid value is OTP";
	public String ERROR_VAL_DATA_TYPE = "DATA.type should be either X or P";
	public String ERROR_VAL_RC = "Rc is invalid";
	public String ERROR_VAL_SKEY = "Invalid AES key length: 8 bytes";
	public String ERROR_REQ_OTP_VAL = "OTP value is required";
	public String ERROR_VAL_CI = "ci must be in YYYYMMDD Format";
	public String ERROR_VAL_RA = "ra value must be O for otp request";
}
