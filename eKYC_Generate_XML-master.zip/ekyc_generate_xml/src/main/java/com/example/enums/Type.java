package com.example.enums;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public enum Type {
	A, V, T, E;

	public String value() {
		return name();
	}

	public static Type fromValue(String v) {
		return valueOf(v);
	}
}
