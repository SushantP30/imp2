package com.example.enums;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */

public enum Lang {

	Assamese("01"), Bengali("02"), Gujarati("05"), Hindi("06"), Kannada("07"), Malayalam("11"), Manipuri("12"),
	Marathi("13"), Oriya("15"), Punjabi("16"), Tamil("20"), Telugu("21"), Urdu("22");

	public final String label;

	private Lang(String label) {
		this.label = label;
	}

	public String value() {
		return name();
	}

	public static Lang fromValue(String v) {
		return valueOf(v);
	}

}
