/**
 * 
 */
package com.example.enums;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public enum Environment {
	Staging, Production;

}
