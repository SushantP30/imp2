package com.example.enums;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public enum ra {
	F, I, O, P;

	public String value() {
		return name();
	}

	public static ra fromValue(String v) {
		return valueOf(v);
	}
}
