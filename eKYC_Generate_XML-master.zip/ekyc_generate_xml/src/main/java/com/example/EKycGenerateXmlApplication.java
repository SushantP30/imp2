package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */

@SpringBootApplication
public class EKycGenerateXmlApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(EKycGenerateXmlApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(EKycGenerateXmlApplication.class);
	}
}
