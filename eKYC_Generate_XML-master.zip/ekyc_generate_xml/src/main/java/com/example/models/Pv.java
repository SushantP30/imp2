package com.example.models;

/**
 * 
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class Pv {

	public String otp;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Pv [otp=");
		builder.append(otp);
		builder.append("]");
		return builder.toString();
	}
	
	
}
