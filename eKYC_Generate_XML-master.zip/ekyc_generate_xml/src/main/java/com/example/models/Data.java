/**
 * 
 */
package com.example.models;

import com.example.enums.*;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class Data {

	/**
	 * Type of the PID block format. It can have two values – “X” for XML
	 */
	public DataType type = DataType.X;

	/**
	 * Data – PID block data should be encrypted with a dynamic session key using
	 * AES-256 symmetric algorithm (AES/GCM/No Padding). Session key, in turn, is
	 * encrypted with 2048-bit UIDAI public key using asymmetric algorithm
	 * (RSA/ECB/PKCS1Padding). Reference implementation demonstrates this in detail.
	 * Session key must not be stored anywhere except in memory and should not be
	 * reused across transactions. Only re-use of session key that is allowed is its
	 * use as seed key when using synchronized session key scheme.
	 */
	public String data;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Data [data=");
		builder.append(data);
		builder.append(", type=");
		builder.append(type);
		builder.append("]");
		return builder.toString();
	}

}
