/**
 * 
 */
package com.example.models;

import java.util.Arrays;

import com.example.enums.Type;
import com.example.enums.ra;
/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 * Root element of the input XML for e-KYC service. Xmlns value must be http://kua.gujarat.gov.in/kyc/gog-kyc-request.
 */

public class KUAData {
	
	/**
	*(mandatory) this must be 64-encoded value. 
	* It can be Aadhaar Number (wherever Aadhaar number is used, in future, an encrypted Aadhaar number may also be used) or Virtual ID or agency specific UID token of the person being authenticated.
	* o Aadhaar Number must be 12 digits.
	* o VID must be 16 digits. 
	* o UID token must be 72 characters. 
	*/
	public String uid;
	
	/**
	 * (mandatory) value must be start with “AuthOtp”. 
	 * SUB-AUA can choose to pass this as part of input but, duplicate transaction ID will not be valid. 
	 * This is returned as part of response as is. 
	 * This is very useful for linking transactions full round trip across systems. 
	 */
	public String saTxn;
	/**
	 *  (mandatory) a unique “Sub-AUA” code as provided by UIDAI. o This allows auditing and business intelligence to be provided at SA level. o This is an alpha-numeric string.
	 */
	public String sa;
	/**
	 * (mandatory) provided by the Department of Science and Technology (DST).
	 */
	public String deviceId;
	/**
	 * (mandatory) version of the API. Currently only valid value is “2.5”. 
	 */
	public String ver="2.5";
	/**
	 * (mandatory) Resident authentication type. Valid values are “F”, “I”, “O”, “P” or any combination of these. 
	 *  Front end e-KYC application that capture the resident authentication PID block, should determine value of this attribute based on what is captured. 
	 *  For example, if resident authentication uses fingerprints, then this should be “F”, if both fingerprint and OTP are used this should be “FO”, and so on (see table below for all values). 
	 *  This and actual authentication factors within PID block do not match, an error is returned. 
	 */
	public ra ra;
	/**
	 * (mandatory) Represents resident’s explicit consent for accessing the resident’s identity and address data from Aadhaar system. Only valid value is “Y”. 
	 * Without explicit consent of the Aadhaar number holder application should not call this API.  
	 */
	public String rc="Y";
	
	/**
	 * -(optional) Flag indicating if AUA application require local language data in addition to English. Valid values are “Y” and “N”. Default value is “N” (by default, this API does not return local Indian language data).  
	 */
	public String lr="N";
	
	/**
	 * (optional) Print format request flag for retrieving E-Aadhaar document in PDF format as part of response. Only valid values are "Y" and "N". If "Y" is passed the print format is returned in the response in addition to XML.
	 */
	public String pfr;
	
	/**
	 * Type - (Mandatory): Aadhaar number type like A, V, T, E 
	 * A = Aadhaar Number V = Virtual ID T = UID Token E = Encrypted Aadhaar number
	 */
	public Type type;
	
	/**
	 *  (Mandatory): This element specifies of transaction related information
	 */
	public Info info=new Info();
	/**
	 * (mandatory) SUB-AUA specific request identifier. AUA can forward the request to UIDAI as per received the request type. ReqType must be “OTP” for OTP based e-KYC.
	 */
	public String ReqType="OTP";
	
	/**
	 *  (mandatory) 
	 */
	public Uses uses=new Uses();
	
	/**
	 *  (mandatory) 
	 *  This element specifies metadata related to the device. All other attributes are valid only for biometric e-KYC. 
	 */
	public Meta meta=new Meta();
	
	/**
	 * (mandatory) Value of this element is base-64 encoded value of encrypted 256-bit AES session key. Session key must be dynamically generated for every transaction (session key must not be reused) 
	 * and must not be stored anywhere except in memory. 
	 */
	public Skey skey=new Skey();

	/**
	*(mandatory)
	 Devices which is constructing the “Pid” element must perform the following to provide the Hmac value:
	o If Pid type is “X” (XML), then:
	 After forming Pid XML, compute SHA-256 hash of Pid XML string
	 Then encrypt using session key
	 Then encode using base-64 encoding (as described earlier, encoding can be done on the AUA server when forming final Auth XML)
	o If Pid type is “P” (Protobuf), then:
	 After forming Protobuf byte array for Pid, compute SHA-256 hash of Pid protobuf bytes.
	 Then encrypt using session key
	 Then encode using base-64 encoding (as described earlier, encoding can be done on the AUA server when forming final Auth XML)
	Authentication server performs the following processing on each authentication request:
	1. Decode and Decrypt the Pid from Data element. Based on type attribute of the “Data” element, the value of Data is either interpreted as XML or Protobuf bytes.
	2. Re-compute the SHA-256 Hash of Pid.
	3. Decode and decrypt the value of Hmac element.
	4. Compare the re-computed SHA-256 hash with Hmac value received in authentication request.
	Version 2.5 Aadhaar Authentication API
	© UIDAI, 2011-2018 http://uidai.gov.in/ Page 14 of 33
	a. If both values match, then, integrity of authentication request is preserved and server will proceed with further processing of the request.
	b. If values do not match, reject the authentication request with error code representing “HMAC Validation failed”.
	*/
	public byte[] hmac;
	
	/**
	 * 
	 */
	public Data data=new Data();
	
	/**
	* timestamp
	*/
	public String ts;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("KUAData [uid=");
		builder.append(uid);
		builder.append(", saTxn=");
		builder.append(saTxn);
		builder.append(", sa=");
		builder.append(sa);
		builder.append(", deviceId=");
		builder.append(deviceId);
		builder.append(", ver=");
		builder.append(ver);
		builder.append(", ra=");
		builder.append(ra);
		builder.append(", rc=");
		builder.append(rc);
		builder.append(", lr=");
		builder.append(lr);
		builder.append(", pfr=");
		builder.append(pfr);
		builder.append(", type=");
		builder.append(type);
		builder.append(", info=");
		builder.append(info);
		builder.append(", ReqType=");
		builder.append(ReqType);
		builder.append(", uses=");
		builder.append(uses);
		builder.append(", meta=");
		builder.append(meta);
		builder.append(", skey=");
		builder.append(skey);
		builder.append(", hmac=");
		builder.append(Arrays.toString(hmac));
		builder.append(", data=");
		builder.append(data);
		builder.append(", ts=");
		builder.append(ts);
		builder.append("]");
		return builder.toString();
	}

}
