package com.example.models;
import java.lang.*;
/**
 * 
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class Pid {

	/**
	 * (Mandatory) Timestamp at the time of capture of authentication input. 
	 * This is in format “YYYY-MM-DDThh:mm:ss” (derived from ISO 8601). 
	 * Time zone should not be specified and is automatically defaulted to IST (UTC +5.30). 
	 * Since timestamp plays a critical role, it is highly recommended that devices are time synchronized with a time server. 
	 */
	public String ts;
	
	/**
	 *  (mandatory) version of the “Pid” element. Currently only valid value is “2.0” Notice that this is NOT same as Authentication API version. 
	 */
	public String ver="2.0";
	
	/**
	 * (optional) “Wrapper API data hash”. SHOULD BE empty for all regular authentication transactions. 
	 * ONLY to be used for specific transaction types such as eKYC and Update APIs. See those API documents for detail. 
	 * This is a hash value passed by those wrapper APIs for PID binding. No other authentication call should pass any value in this attribute and must be left empty. 
	 */
	public String wadh;
	
	/**
	 * No description found in document
	 */
	public Demo demo=new Demo();
	
	public Pv pv=new Pv();

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Pid [ts=");
		builder.append(ts);
		builder.append(", ver=");
		builder.append(ver);
		builder.append(", wadh=");
		builder.append(wadh);
		builder.append(", demo=");
		builder.append(demo);
		builder.append(", pv=");
		builder.append(pv);
		builder.append("]");
		return builder.toString();
	}
	
	
}
