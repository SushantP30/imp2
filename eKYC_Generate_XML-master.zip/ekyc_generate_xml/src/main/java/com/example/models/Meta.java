/**
 * 
 */
package com.example.models;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 */
public class Meta {
	/**
	 * (mandatory) value must be blank when using OTP base e-KYC.
	 */
	public String dpId = "";
	/**
	 * (mandatory) value must be blank when using OTP base e-KYC.
	 */
	public String rdsId = "";

	/**
	 * (mandatory) value must be blank when using OTP base e-KYC.
	 */
	public String rdsVer = "";

	/**
	 * (mandatory) value must be blank when using OTP base e-KYC.
	 */
	public String dc = "";

	/**
	 * (mandatory) value must be blank when using OTP base e-KYC.
	 */
	public String mi = "";

	/**
	 * (mandatory) value must be blank when using OTP base e-KYC.
	 */
	public String mc = "";

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Meta [dpId=");
		builder.append(dpId);
		builder.append(", rdsId=");
		builder.append(rdsId);
		builder.append(", rdsVer=");
		builder.append(rdsVer);
		builder.append(", dc=");
		builder.append(dc);
		builder.append(", mi=");
		builder.append(mi);
		builder.append(", mc=");
		builder.append(mc);
		builder.append("]");
		return builder.toString();
	}
}
