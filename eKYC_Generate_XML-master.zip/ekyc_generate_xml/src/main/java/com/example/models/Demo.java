package com.example.models;

import java.util.Optional;
import java.lang.*;
import com.example.enums.Lang;

/**
 * 
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class Demo {
	/**
	 * (optional) “Indian Language Code” in the case of using Indian language data
	 * for demographic match.
	 * 
	 */
	public Optional<Lang> lang;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Demo [lang=");
		builder.append(lang);
		builder.append("]");
		return builder.toString();
	}
	
	
}
