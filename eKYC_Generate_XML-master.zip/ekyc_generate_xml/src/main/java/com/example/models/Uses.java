package com.example.models;

/**
 * @author Jinal
 * @author Parth
 * @author Shambhu
 * (mandatory)
 */
public class Uses {

	/**
	 * (mandatory) valid values are “y” or “n”. Value must be “n” for OTP e-KYC.
	 */
	public String pi="n";
	/**
	 * (mandatory) valid values are “y” or “n”. Value must be “n” for OTP e-KYC.
	 */
	public String pa="n";
	/**
	 * (mandatory) valid values are “y” or “n”. Value must be “n” for OTP e-KYC.
	 */
	public String pfa="n";
	/**
	 * (mandatory) valid values are “y” or “n”. Value must be “n” for OTP e-KYC.
	 */
	public String bio="n";
	/**
	 * (mandatory) value must be blank for OTP authentication.
	 */
	public String bt="";
	/**
	 * (mandatory) valid values are “y” or “n”. Value must be “n” for OTP e-KYC.
	 */
	public String pin="n";
	/**
	 * (mandatory) valid values are “y” or “n”. If the value is “y” then OTP should be used in e-KYC. 
	 */
	public String otp;
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Uses [pi=");
		builder.append(pi);
		builder.append(", pa=");
		builder.append(pa);
		builder.append(", pfa=");
		builder.append(pfa);
		builder.append(", bio=");
		builder.append(bio);
		builder.append(", bt=");
		builder.append(bt);
		builder.append(", pin=");
		builder.append(pin);
		builder.append(", otp=");
		builder.append(otp);
		builder.append("]");
		return builder.toString();
	}
}
