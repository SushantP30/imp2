package com.example.models;

import java.util.Optional;

/**
 * 
 * @author Jinal
 * @author Parth
 * @author Shambhu
 *
 */
public class Info {

	/**
	 *  (optional) this attribute only for Biometric-KYC request. Default value is “NA.” 
	 */
	public String rdsrno="NA";
	
	/**
	 * (mandatory) SUB-AUA specific transaction identifier. AUA can forward the request to UIDAI as per received the transaction type. txnType must be “OTP” for OTP based e-KYC. 
	 */
	public String txnType="OTP";
	
	/**
	 * (mandatory) SUB-AUA mention the specific scheme name for the transaction. 
	 */
	public String schemeName;
	
	/**
	 * (optional) SUB-AUA mention specific building no of the transaction origin place.
	 */
	public Optional<String> buildingNo;
	
	/**
	 * (mandatory) SUB-AUA mention specific building name or shop name of the transaction origin place
	 */
	public String buildingName;
	
	/**
	 *  (optional) SUB-AUA mention specific street name of the transaction origin place. 
	 */
	public Optional<String> street;
	
	/**
	 * (mandatory) SUB-AUA mention specific city name of the transaction origin place
	 */
	public String city;
	
	/**
	 *  (mandatory) SUB-AUA mention specific Pin code of the transaction origin place. 
	 */
	public String pinCode;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Info [rdsrno=");
		builder.append(rdsrno);
		builder.append(", txnType=");
		builder.append(txnType);
		builder.append(", schemeName=");
		builder.append(schemeName);
		builder.append(", buildingNo=");
		builder.append(buildingNo);
		builder.append(", buildingName=");
		builder.append(buildingName);
		builder.append(", street=");
		builder.append(street);
		builder.append(", city=");
		builder.append(city);
		builder.append(", pinCode=");
		builder.append(pinCode);
		builder.append("]");
		return builder.toString();
	}

}
