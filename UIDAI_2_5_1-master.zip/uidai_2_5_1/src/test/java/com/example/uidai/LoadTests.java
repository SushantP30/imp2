/**
 * 
 */
package com.example.uidai;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import org.junit.jupiter.api.Test;
import com.utils.SignatureUtil;

/**
 * @author harsh
 *
 */
class LoadTests {

	/*
	 * +
	 * +++++++++++++++++++
	 * 04.
	 * 
	 * 
	 * public void finalize() throws Throwable {
	 * System.out.println("Object is destroyed by the Garbage Collector"); }
	 */
	@Test
	void generateSignature_LoadTest() {

		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\r\n" + "<Auth>\r\n"
				+ "	<Txn>AuthBio:20191016145417376279167</Txn>\r\n" + "	<Ver>2.5</Ver>\r\n"
				+ "	<SubAUACode>PFCDG18028</SubAUACode>\r\n" + "	<ReqType>bio</ReqType>\r\n"
				+ "	<DeviceId>FCSPROD25</DeviceId>\r\n" + "	<UID>NjAwMjYxOTcyNjcz</UID>\r\n" + "	<Rc>Y</Rc>\r\n"
				+ "	<Type>A</Type>\r\n" + "	<Ts>2019-10-16T02:54:17</Ts>\r\n"
				+ "	<Uses pi=\"n\" pa=\"n\" pfa=\"n\" bt=\"FMR\" bio=\"y\" pin=\"n\" otp=\"n\" />\r\n"
				+ "	<Meta udc=\"FCSPROD25\" rdsId=\"MANTRA.WIN.001\" rdsVer=\"1.0.0\"\r\n"
				+ "		dc=\"218ffdb5-fbb4-4145-b630-33a3a0af3d8b\" dpId=\"MANTRA.MSIPL\"\r\n"
				+ "		mi=\"MFS100\"\r\n"
				+ "		mc=\"MIIEGzCCAwOgAwIBAgIINoMSOoSVVHUwDQYJKoZIhvcNAQELBQAwgekxKjAoBgNVBAMTIURTIE1hbnRyYSBTb2Z0ZWNoIEluZGlhIFB2dCBMdGQgNTFNMEsGA1UEMxNEQiAyMDMgU2hhcGF0aCBIZXhhIG9wcG9zaXRlIEd1amFyYXQgSGlnaCBDb3VydCBTIEcgSGlnaHdheSBBaG1lZGFiYWQxEjAQBgNVBAkTCUFobWVkYWJhZDEQMA4GA1UECBMHR3VqYXJhdDESMBAGA1UECxMJVGVjaG5pY2FsMSUwIwYDVQQKExxNYW50cmEgU29mdGVjaCBJbmRpYSBQdnQgTHRkMQswCQYDVQQGEwJJTjAeFw0xOTEwMTMwNTMxMzhaFw0xOTEwMjcwMzI2NDBaMIGwMSQwIgYJKoZIhvcNAQkBFhVzdXBwb3J0QG1hbnRyYXRlYy5jb20xCzAJBgNVBAYTAklOMRAwDgYDVQQIEwdHVUpBUkFUMRIwEAYDVQQHEwlBSE1FREFCQUQxDjAMBgNVBAoTBU1TSVBMMR4wHAYDVQQLExVCaW9tZXRyaWMgTWFudWZhY3R1cmUxJTAjBgNVBAMTHE1hbnRyYSBTb2Z0ZWNoIEluZGlhIFB2dCBMdGQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCqlIXRYkTT3+t2PeK3BSsV5r/6n4vYbVhUe/8efHRRJpAyLvQv6lZIlifSocogSMOSD1RLelUqCLXnUTG326uVll9Uxnt1zGH0Ye/e9PhJPCmjW7uGoCsXgSg52tPup3xcQp+NXJQsY30QraJ7tbzMOWoFPWRi4PBAo3wnQjmhBveeKqLt6ziebuSS8EUiyDgl0xxHTQVAQvH0oqOKjsMwJF4dNcf7iPzJp0nd8OcFu5d6W5ETZlxJ3Wy0xEMU1IOiJrpvRzIM56bkHOWTeSnrs0cmMaSSsJrxE9VZ7YAjnqNnvauaRgj7992QptJHR/ZnP+VoTOLop7SEITarTtirAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAAse5RFaEJLQ6l5Px5+gWoxCpJ6u6lWYeeBsh62exXdxBfBYXGS7JZPvKOuVheezDh2ldQwKOwSa3cURwJMrr2C1BgMwIPdlJh5d847WeD8hA5QkaIkVCvR8dzasUJSZkSYXjjbhi/93kwNpsZ9PktH29b7BB8xuOTHCrjAj1WSTkX28QeEhn3UyaCJRLAoflw/4lsh2XckgXDTrWM/h4EJu/ju5DP03glWw5of5d1wU1EMFkXwvB8hVC7yp58JPZSp5eEeT0dLQ4bLpWlRBAMG/ub9llBB1kHe/L2e/FE4bk2DRisnY4JNsizaJTBFagoXn11KbcjBjwp1/xo+JIwU=\"\r\n"
				+ "		rdsrn=\"1874474\" />\r\n"
				+ "	<Skey ci=\"20191230\">g3nIjBcPuLXPbqVNZQrvWBQTSaWg8JyyK0d98CCVwYtKs9CI3jCMG2aNZATxAn3nPlLwKgaZGYR4SNbOxE02FKIEPvBMWKVgFac6HswHYWy+Mczh5ijA26wHMUzuHvbmVoSRs+OhypOwGLltGfV8/JoG2UESrt1Jz44PVE5vpKWVOghjoZUIDS5qLNVWwNnp0je50YJ1OQ1fKGOqE4q0NikPi+R6SEe3k8U4/7d8tyZS3l+j4tglb07W1xyg0uO0feLGk0/3cqynGoVOYp2lSMLXrQr+1To7XVPAQphf2eoBpZBJ/0aPMaOxcK+K+uJ+lF49Fh7v9p6dHm2e3xTHZw==</Skey>\r\n"
				+ "	<Data type=\"X\">MjAxOS0xMC0xNlQxNDo1NDoxNf4/aS1VtQV9JPYue5BNYKnbIcqFtsoEg6Fgu1ZkVjlhaCEZRA9wiuzyQZnSk+p9ecOnuGRSVGM3XrOFZFG6s3EJ6RRntp3Jd/BSY2mNr12t+VTxU5Nsp8NJ3vc5Ey5AtKSbEHHNaPOQNyM69zF1CtTevYeCowz1yTBIOCn8TugMrM5RAN6HLvwPUggVz2nRU4NE1zYL533BbFyCIqHbCSg7gcZEH92+FM+mAfoSsO57SffQNcpeA851zEOh2nKXZQpmUvT7Sewd/qsT2KKaHhaVybG/yK66q07YBxCDbqrXpPPVGTwIXFZnNDn//2X3BUxEDhEwJgiat9nCZib/Osj+ZXJj4CYBB3SLLXTyRwaHeJaDQLS2wIjnsEE9q4h0EvO+B8dHfKyFQV8vQDFJBvgJKAWEZh912eRWsNRlN35mrORKp9bvFAaip3Asz1WV3dV+czLgHDPHL6eoRqEYhtdRnopYqXjG9Amez4/gpuZ8NfbaMBg148YG27+ot/bFtqsTsdiaEAj1PK7ANSAZJdBTVhGMsbxHCs3ddjmug67qIeSMusaStdQD57dqG+NMWe70ik6R9S6AcO0lEwBGv6do8pWm+aFM+F799BciAOUkCYYzI9AoEE0Ghm1MVHznc/LRQO/2yP9dXLXLYeFsmAPv1X2IH4WwtkYCRQ5mjXAyl2d5yZkBqelki4Axixwi5o1W7K7VRpzpIaBkxGcJeUdzly5UzNz7/qevFNp48VdzXbRXIDVmlBYG+EJVg4ley6ueiJGvLrwEDuWxUR6zlXLSo7me3AfkDqa2NrOkpy8t5I7SO0tH+jPiFivMIjRmers0kZUcNtqzrpnwODydb9BQjeSmXDk9uqT0fbsMwyXfE4q5o+7uGIjeDqLoUWNCNEUS51K/nS5I0lz3O/0MoqFxpa/4DZAfiJi6ssVdDBLGgrKYJF3wi+WL0Pt1PQ+ircve6KPABqfXAdr850mrmXC09OYJK5QjnvkU5i8nzCXIooC7mlVEPCgwOTaHS2i3zQIvMPGUXyIOtD6RC+3IqGxBTPNfgaIS32lbuQYa7uU4jqnYh1E+yLcIqgNWsmXXKv/5inXe38ber0xlbzYihA4NawXcjww8oJN/WSKmQyu4/5m3EG/uQFcH2VVr5qLlxLI66DbmE4c7I6PsyGUcWsonwH3x99X6XYeoNtw=</Data>\r\n"
				+ "	<Hmac>8AY7plwcRG4833haiU+ebvMUmQO2mZYq5V8cwxJaQ/pY0yjvnOkEw870BR45C24n</Hmac>\r\n"
				+ "	<Info rdsrno=\"1874474\" txnType=\"bio\" schemeName=\"eFPS\"\r\n"
				+ "		buildingNo=\"FCS\" buildingName=\"FCS\" street=\"FCS\" city=\"Gandhinagar\"\r\n"
				+ "		pinCode=\"382010\" />\r\n" + "</Auth>";
		LocalDateTime time1, time2;
		time1 = LocalDateTime.now();
		byte hsmValue = 0;
		System.out.println("Start New Algorith test: " + time1);
		for (int i = 0; i < 1; i++) {
			try {
				String signXML = SignatureUtil.signXML(xml,hsmValue,"101");
				System.out.println("Signed Documents: " + (i + 1));
				System.out.println("Sign HSM: "+signXML);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		time2 = LocalDateTime.now();
		System.out.println("Finish New Algorith test: " + time2);
		System.out.println("Time Taken: " + (time1.until(time2, ChronoUnit.MILLIS)) / 1000.0);

	}


}
