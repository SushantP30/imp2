/**
 * 
 */
package com.utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.models.SignHSM;
import com.models.SignResponse;

/**
 * SignatureUtil class is used for signing to Authentication request XML and
 * verifying response XML. For signing there is two way in this class the one is
 * signed by hardware security module and second one is costumes way of the
 * code..
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 01/09/2021
 * @since 2.5
 */

@SuppressWarnings({ "unchecked", "rawtypes" })
public class SignatureUtil {

	public static CertificateFactory certFactory;
	private static final char[] PASSWORD = "GILaua!Dec2023".toCharArray();
	private static final String ALIAS = "le-1d7e979a-802e-40ae-b445-3f0ac3a5791b";
	private static final String FILEPATH_PRIVATEKEY = "C:\\UIDAI\\Keys\\DSC2023.pfx";
	private static final String FILEPATH_PUBLICKEY = "C:\\UIDAI\\Keys\\uidai_auth_prod.cer";
	private static final Boolean INCLUDEKEYINFO = true;
	private static final String WHOLE_DOC_URI = "";

	/**
	 * @param xml Authentication request XML
	 * @param hsm value is either 1 or 0, If value is 1 the authentication request
	 *            XML pass to HSM and value is 0 then authentication request XML has
	 *            signed by costume code.
	 * @param txn Authentication Transaction ID
	 * @return signXML
	 */
	@SuppressWarnings("resource")
	public static String signXML(String xml, byte hsm, String txn) {

		if (hsm == 1) {
			SignHSM signhsm = new SignHSM();
			signhsm.orgXML = Base64.getEncoder().encodeToString(xml.getBytes());
			signhsm.txn = txn;

			/**
			 * @param signhsm is object of SignHSM class which represented to HSM's request
			 *                entities.
			 * 
			 * @return response is object of SignResponse class which represented to HSM's
			 *         response entities.
			 */
			try {
				SignResponse response = HttpClientUtil.sendToHsm(signhsm);
				if (response.status != 1) {
					ApplicationLogger.logAsyncAua(response.toString());
					return "";
				}
				return new String(Base64.getDecoder().decode(response.signedXML), "utf-8");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				ApplicationLogger.logAsyncAua("Error in HSM:", e);
				return "";
			}
		} else {
			try {
				Security.addProvider(new BouncyCastleProvider());
				X509Certificate x509Cert;
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				dbf.setNamespaceAware(true);
				XMLSignatureFactory FAC = XMLSignatureFactory.getInstance("DOM");
				KeyStore ks = KeyStore.getInstance("PKCS12");
				// FileInputStream keyFileStream = new FileInputStream(FILEPATH_PRIVATEKEY);//
				// replace with below code // this instantiation cause garbage collection
				// pauses, even if properly cause.
				InputStream keyFileStream = Files.newInputStream(Paths.get(FILEPATH_PRIVATEKEY)); // Attached 09/09/2021
				ks.load(keyFileStream, PASSWORD);
				KeyStore.PrivateKeyEntry KEYENTRY = (KeyStore.PrivateKeyEntry) ks.getEntry(ALIAS,
						new KeyStore.PasswordProtection(PASSWORD));
				Reference ref = FAC.newReference(WHOLE_DOC_URI, FAC.newDigestMethod(DigestMethod.SHA1, null),
						Collections.singletonList(FAC.newTransform(Transform.ENVELOPED, (TransformParameterSpec) null)),
						null, null);
				SignedInfo sInfo = FAC.newSignedInfo(
						FAC.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE, (C14NMethodParameterSpec) null),
						FAC.newSignatureMethod(SignatureMethod.RSA_SHA1, null), Collections.singletonList(ref));
				KeyInfoFactory kif = FAC.getKeyInfoFactory();
				x509Cert = (X509Certificate) KEYENTRY.getCertificate();
				List x509Content = new ArrayList();
				x509Content.add(x509Cert.getSubjectX500Principal().getName());
				x509Content.add(x509Cert);
				X509Data xd = kif.newX509Data(x509Content);
				KeyInfo kInfo = kif.newKeyInfo(Collections.singletonList(xd));
				Transformer trans = TransformerFactory.newInstance().newTransformer();
				StringWriter stringWriter = new StringWriter();
				Document xmlDocument = dbf.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
				DOMSignContext dsc = new DOMSignContext(KEYENTRY.getPrivateKey(), xmlDocument.getDocumentElement());
				XMLSignature signature = FAC.newXMLSignature(sInfo, INCLUDEKEYINFO ? kInfo : null);
				signature.sign(dsc);
				Node node = dsc.getParent();
				Document signedDocument = node.getOwnerDocument();
				trans.transform(new DOMSource(signedDocument), new StreamResult(stringWriter));
				return stringWriter.getBuffer().toString();
			} catch (Exception e) {
				ApplicationLogger.logAsyncAua("Error while trying to sign xml:", e);
				return "";
			}
		}

	}

	/**
	 * It'll Verifying UIDAI's signature in Response XML.
	 * 
	 * @param xml Authentication Response XML.
	 * 
	 * @return isVerified If it's verified then it's passed to true value else
	 *         false.
	 */

	@SuppressWarnings("resource")
	public static boolean isVerified(String xml) {
		try {
			Security.addProvider(new BouncyCastleProvider());
			DocumentBuilderFactory DBF = DocumentBuilderFactory.newInstance();
			DBF.setNamespaceAware(true);
			XMLSignatureFactory FAC = XMLSignatureFactory.getInstance("DOM");
			CertificateFactory certFactory = CertificateFactory.getInstance("X.509", "BC");
			Document xmlDocument = DBF.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
			NodeList nl = xmlDocument.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
			if (nl.getLength() == 0) {
				ApplicationLogger.logAsyncAua("Cannot find Signature element.");
				return false;
			}
			FileInputStream FIS = new FileInputStream(FILEPATH_PUBLICKEY);
			DOMValidateContext valContext = new DOMValidateContext(
					((X509Certificate) certFactory.generateCertificate(FIS)).getPublicKey(), nl.item(0));
			XMLSignature signature = FAC.unmarshalXMLSignature(valContext);
			return signature.validate(valContext);
		} catch (Exception e) {
			ApplicationLogger.logAsyncAua("Error verifying signature:", e);
			return false;

		}
	}

}
