/**
 * 
 */
package com.utils;

import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import com.models.Request2_5;
import com.models.Response2_5;

/**
 * XMLBuilder class is build several XMLs i.e Authentication Request XML, OTP
 * Generation XML, Response XML, Error XML, OTP Response XML.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 26/08/2021
 * @since 2.5
 */
public class XMLBuilder {

	/**
	 * This Method is build response XML at AuA level, If exception occurred at run
	 * time it self it return null and write exception in AuA logs file.
	 *
	 * @param response    Object of Response2_5 class which is stored response
	 *                    elements.
	 * @param requestType It is type of request send by SUB_AUA and generate
	 *                    response XML depends on requestType value.
	 * @exception Exception It's a general Exception, It's return null value and
	 *                      throw exception massage in application logs.
	 * 
	 * @return Response XML
	 */
	public static String buildAUAResp(Response2_5 response, String requestType) {
		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("AuthRes");

			xMLStreamWriter.writeStartElement("SubAUAtransId");
			xMLStreamWriter.writeCharacters(response.txn_subAua);
			xMLStreamWriter.writeEndElement();

			if (!requestType.equals("otp")) {

				xMLStreamWriter.writeStartElement("UIDToken");
				xMLStreamWriter.writeCharacters(response.uidToken);
				xMLStreamWriter.writeEndElement();

				xMLStreamWriter.writeStartElement("Ret");
				xMLStreamWriter.writeCharacters(response.ret);
				xMLStreamWriter.writeEndElement();

				if (response.bfdRanks != null) {
					xMLStreamWriter.writeStartElement("BfdRanks");
					for (int i = 0; i < response.bfdRanks.size(); i++) {
						xMLStreamWriter.writeEmptyElement("BfdRank");
						xMLStreamWriter.writeAttribute("pos", response.bfdRanks.get(i).pos.value());
						xMLStreamWriter.writeAttribute("value", Integer.toString(response.bfdRanks.get(i).value));
					}
					xMLStreamWriter.writeEndElement();
				}

				xMLStreamWriter.writeStartElement("Actn");
				xMLStreamWriter.writeCharacters(response.actn);
				xMLStreamWriter.writeEndElement();
			}

			xMLStreamWriter.writeStartElement("ResponseTs");
			xMLStreamWriter.writeCharacters(response.ts);
			xMLStreamWriter.writeEndElement();

			if (requestType.equals("otp")) {
				xMLStreamWriter.writeStartElement("OtpRet");
				xMLStreamWriter.writeCharacters(response.ret);
				xMLStreamWriter.writeEndElement();
			}

			xMLStreamWriter.writeStartElement("ResponseCode");
			xMLStreamWriter.writeCharacters(response.code);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("errorCode");
			xMLStreamWriter.writeCharacters(response.err);
			xMLStreamWriter.writeEndElement();

			if (requestType.equals("otp")) {
				xMLStreamWriter.writeStartElement("OtpSentOn");
				xMLStreamWriter.writeCharacters(response.maskedMobile + ";" + response.maskedEmail);
				xMLStreamWriter.writeEndElement();
			}

			xMLStreamWriter.writeEndElement();// End AuthRes
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\" ?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncAua("Error building Response:" + "Transaction ID:" + response.txn + ":", e);
			return null;
		}
	}

	private static String buildASARespOTP(Response2_5 response) {
		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("OtpRes");
			xMLStreamWriter.writeAttribute("ret", response.ret);
			xMLStreamWriter.writeAttribute("code", response.code);
			xMLStreamWriter.writeAttribute("txn", response.txn);
			xMLStreamWriter.writeAttribute("err", response.err);
			xMLStreamWriter.writeAttribute("ts", response.ts);
			xMLStreamWriter.writeAttribute("info", response.info);

			xMLStreamWriter.writeEndElement();// End AuthRes
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\" ?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncAsa("Error building Response:" + "Transaction ID:" + response.txn + ":", e);
			return null;
		}
	}

	public static String buildASARespForError(Response2_5 response, String requestType) {
		response.ret = "n";
		response.actn = "NA";
		response.info = "";
		response.code = "";
		if (requestType.equals("otp")) {
			return buildASARespOTP(response);
		}
		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("AuthRes");
			xMLStreamWriter.writeAttribute("ret", response.ret);
			xMLStreamWriter.writeAttribute("code", response.code);
			xMLStreamWriter.writeAttribute("txn", response.txn);
			xMLStreamWriter.writeAttribute("err", response.err);
			xMLStreamWriter.writeAttribute("ts", response.ts);
			xMLStreamWriter.writeAttribute("actn", response.actn);
			xMLStreamWriter.writeAttribute("info", response.info);

			xMLStreamWriter.writeEndElement();// End AuthRes
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\" ?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncAsa("Error building Response:" + "Transaction ID:" + response.txn + ":", e);
			return null;
		}
	}

	/**
	 * Build OTP Generation Request XML at AuA level.
	 * 
	 * @param request object of Request2_5.
	 * @exception Exception It's a general Exception, It's return null value and
	 *                      throw exception massage in application logs.
	 * @return Request XML for OTP Generation
	 */
	private static String buildASARequestOTP(Request2_5 request) {
		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("Otp");
			xMLStreamWriter.writeAttribute("uid", request.uid);
			xMLStreamWriter.writeAttribute("ac", request.ac);
			xMLStreamWriter.writeAttribute("sa", request.sa);
			xMLStreamWriter.writeAttribute("ver", request.ver);
			xMLStreamWriter.writeAttribute("txn", request.txn);
			xMLStreamWriter.writeAttribute("ts", request.ts);
			xMLStreamWriter.writeAttribute("lk", request.lk);
			xMLStreamWriter.writeAttribute("type", request.type);

			xMLStreamWriter.writeEmptyElement("Opts");
			xMLStreamWriter.writeAttribute("ch", request.ch);

			xMLStreamWriter.writeEndElement();// End Auth
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncAua("Error building ASA Request:" + "Transaction ID:" + request.txn_subAua + ":",
					e);
			return null;
		}
	}

	/**
	 * Build Authentication Request XML or OTP Generation Request XML at AuA level.
	 * 
	 * @param request object of Request2_5.
	 * @exception Exception It's a general Exception, It's return null value and
	 *                      throw exception massage in application logs.
	 * @return xmlString is AuA level request XML i.e Authentication (Bio,Demo and
	 *         OTP) Request XML and OTP Generation request XML if any issue occurred
	 *         XML's build time its self pass null value.
	 */
	public static String buildASARequest(Request2_5 request) {
		if (request.reqType.equals("otp")) {
			return buildASARequestOTP(request);
		}

		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("Auth");
			xMLStreamWriter.writeAttribute("ac", request.ac);
			xMLStreamWriter.writeAttribute("lk", request.lk);
			xMLStreamWriter.writeAttribute("rc", request.rc);
			xMLStreamWriter.writeAttribute("sa", request.sa);
			xMLStreamWriter.writeAttribute("tid", request.tid);
			xMLStreamWriter.writeAttribute("txn", request.txn);
			xMLStreamWriter.writeAttribute("uid", request.uid);
			xMLStreamWriter.writeAttribute("ver", request.ver);

			xMLStreamWriter.writeEmptyElement("Uses");
			xMLStreamWriter.writeAttribute("bio", request.uses.bio);
			xMLStreamWriter.writeAttribute("bt", request.uses.bt);
			xMLStreamWriter.writeAttribute("otp", request.uses.otp);
			xMLStreamWriter.writeAttribute("pa", request.uses.pa);
			xMLStreamWriter.writeAttribute("pfa", request.uses.pfa);
			xMLStreamWriter.writeAttribute("pi", request.uses.pi);
			xMLStreamWriter.writeAttribute("pin", request.uses.pin);

			xMLStreamWriter.writeEmptyElement("Meta");
			xMLStreamWriter.writeAttribute("dc", request.meta.dc);
			xMLStreamWriter.writeAttribute("dpId", request.meta.dpId);
			xMLStreamWriter.writeAttribute("mc", request.meta.mc);
			xMLStreamWriter.writeAttribute("mi", request.meta.mi);
			xMLStreamWriter.writeAttribute("rdsId", request.meta.rdsId);
			xMLStreamWriter.writeAttribute("rdsVer", request.meta.rdsVer);

			xMLStreamWriter.writeStartElement("Skey");
			xMLStreamWriter.writeAttribute("ci", request.skey.ci);
			xMLStreamWriter.writeCharacters(request.skey.Data);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("Hmac");
			xMLStreamWriter.writeCharacters(new String(request.hmac, StandardCharsets.UTF_8));
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("Data");
			xMLStreamWriter.writeAttribute("type", request.data.type.toString());
			xMLStreamWriter.writeCharacters(request.data.data);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeEndElement();// End Auth
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncAua("Error building ASA Request:" + "Transaction ID:" + request.txn_subAua + ":",
					e);
			return null;
		}
	}
}
