/**
 * 
 */
package com.utils;

import java.time.LocalDateTime;

/**
 * A date-time without a time-zone in the ISO-8601 calendar system, such as
 * {@code 2007-12-03T10:15:30}.
 *
 * @author Harsh H. Barot
 * @version 2.5.1, 04/09/2021
 * @since 2.5
 */
public class DateTimeUtil {
	/**
	 * 
	 * @return returns Date Time stamp in format YYYY-MM-DDThh:mm:sss+5:30
	 */
	public static String getCurrentDate() {
		return LocalDateTime.now().toString().substring(0, 23) + "+5:30";
	}

	/**
	 * 
	 * @return returns Date Time stamp in format YYYY-MM-DD hh:mm:sss . Used for
	 *         saving in database
	 */
	public static String getCurrentDateSQLFormat() {
		return LocalDateTime.now().toString().substring(0, 23).replace("T", " ");
	}
}
