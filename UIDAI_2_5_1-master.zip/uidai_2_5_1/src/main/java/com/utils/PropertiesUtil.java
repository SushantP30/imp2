/**
 * 
 */
package com.utils;

import java.util.Base64;
import java.util.ResourceBundle;

import com.enums.Environment;

/**
 * PropertiesUtil class is retrieve data from properties file i.e environment
 * and uidai's file.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 25/08/2021
 * @since 2.5
 * 
 */
public class PropertiesUtil {
	private static ResourceBundle messageBundle = ResourceBundle.getBundle("uidai");
	private static ResourceBundle messageBundle_env = ResourceBundle.getBundle("environment");

	/**
	 * @param String value which want to decoded.
	 * @return Based 64 Decoded String
	 */
	private static String getDecodedValue(String key) {
		return new String(Base64.getDecoder().decode(messageBundle.getString(key).trim().getBytes()));
	}

	/**
	 * Retrieve data from uidai.properties file.
	 * 
	 * @param String parameter which want from properties file.
	 * @return Value parameter
	 */
	private static String getValue(String key) {
		return messageBundle.getString(key).trim();
	}

	/**
	 * get the application environment value i.e in staging or production from
	 * environment.properties file.
	 * 
	 * @return Application's environment
	 */
	private static Environment getEnvironment() {
		if (messageBundle_env.getString("environment").trim().equals("staging")) {
			return Environment.Staging;
		} else if (messageBundle_env.getString("environment").trim().equals("production")) {
			return Environment.Production;
		} else {
			return null;
		}
	};

	/**
	 * Fetch API version from uidai.properties file which is 2.5
	 * 
	 * @return Value of API Version
	 */
	public static String getApiVersion() {
		return getValue("apiversion");
	};

	/**
	 * Fetch AuA License key from uidai.properties, either it's production key or
	 * staging key.
	 * 
	 * @return Decoded AuA license key
	 */
	public static String getAuaLicenseKey() {
		if (getEnvironment() == Environment.Production) {
			return getDecodedValue("auaLicenseKeyProduction");
		} else {
			return getDecodedValue("auaLicenseKeyStaging");
		}
	};

	/**
	 * Fetch AsA License key uidai.properties, either it's production key or staging
	 * key.
	 * 
	 * @return Decoded AsA license key
	 */
	public static String getAsaLicenseKey() {
		if (getEnvironment() == Environment.Production) {
			return getDecodedValue("asaLicenseKeyProduction");
		} else {
			return getDecodedValue("asaLicenseKeyStaging");
		}
	};

	/**
	 * Fetch AuA code from uidai.properties, either it's production key or staging
	 * key.
	 * 
	 * @return AuA code
	 */
	public static String getAauaCode() {
		if (getEnvironment() == Environment.Production) {
			return getValue("auaCodeProduction");
		} else {
			return getValue("auaCodeStaging");
		}
	};

	/**
	 * Fetch CIDR Authentication URL from uidai.properties, either it's production
	 * key or staging key.
	 * 
	 * @return CIDR Authentication URL
	 */
	public static String getCidrAuthUrl() {
		if (getEnvironment() == Environment.Production) {
			return getValue("cidrAuthUrlProduction");
		} else {
			return getValue("cidrAuthUrlStaging");
		}
	};

	/**
	 * Fetch CIDR OTP generation URL from uidai.properties, either it's production
	 * key or staging key.
	 * 
	 * @return CIDR OTP generation URL
	 */
	public static String getCidrOtpUrl() {
		if (getEnvironment() == Environment.Production) {
			return getValue("cidrOtpUrlProduction");
		} else {
			return getValue("cidrOtpUrlStaging");
		}
	};

	/**
	 * Fetch AuA Database Connection Parameter from uidai.properties, either it's
	 * production key or staging key.
	 * 
	 * @return AuA Database Connection Parameter
	 */
	public static String getAuaConnectionParams() {
		if (getEnvironment() == Environment.Production) {
			return getValue("auaConnectionParamsProduction");
		} else {
			return getValue("auaConnectionParamsStaging");
		}
	};

	/**
	 * Fetch AsA Database Connection Parameter from uidai.properties, either it's
	 * production key or staging key.
	 * 
	 * @return AsA Database Connection Parameter
	 */
	public static String getAsaConnectionParams() {
		if (getEnvironment() == Environment.Production) {
			return getValue("asaConnectionParamsProduction");
		} else {
			return getValue("asaConnectionParamsStaging");
		}
	};

	/**
	 * Fetch Terminal ID for biometrics from uidai.properties file.
	 * 
	 * @return Terminal ID
	 */
	public static String getTerminalId() {
		return getValue("terminalId");
	};

	/**
	 * Fetch Terminal ID for Demographics from uidai.properties file.
	 * 
	 * @return Terminal ID for Demographics
	 */
	public static String getTerminalIdDemo() {
		return getValue("terminalIdDemo");
	};

	/**
	 * Fetch Terminal ID for OTP Authentication from uidai.properties file.
	 * 
	 * @return Terminal ID for OTP Authentication
	 */
	public static String getTerminalIdOtpAuth() {
		return getValue("terminalIdOtpAuth");
	};

	/**
	 * Fetch AsA Authentication server URL from uidai.properties file.
	 * 
	 * @return AsA Authentication server URL
	 */
	public static String getAsaAuthServerUrl() {
		return getValue("asaAuthServerUrl");
	};

	/**
	 * Fetch AsA OTP server URL from uidai.properties file.
	 * 
	 * @return AsA OTP server URL
	 */
	public static String getAsaOTPServerUrl() {
		return getValue("asaOTPServerUrl");
	};
	/**
	 * Fetch HSM Server URL's from uidai.properties file.
	 * 
	 * @return HSM Servers URL
	 * 
	 */
	public static String getHSMUrl() {
		return getValue("hsmServer");
	};

	/**
	 * Fetch HSM value from uidai.properties file.
	 * 
	 * @return HSM value
	 */
	public static String getHSMvalue() {
		return getValue("HSM");
	};

}
