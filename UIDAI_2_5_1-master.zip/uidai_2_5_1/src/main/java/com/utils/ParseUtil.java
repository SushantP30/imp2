/**
 * 
 */
package com.utils;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Base64;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import com.models.*;
import com.enums.*;

/**
 * ParseUtil class which performed here Parse the various type of request and
 * response XML's to Object and stored value in models class.
 * <p>
 * For reference
 * {@link https://www.journaldev.com/1191/java-stax-parser-example-read-xml-file}
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 24/08/2021
 * @since 2.5
 */

public class ParseUtil {

	/**
	 * @param XML Request XML which sent by SUB-AuA, If the XML's is null and
	 *            occurred any exception to run time it self it return null value.
	 * @implNote Modified Info parameter and add new attribute like LK (SuB-AUA's
	 *           License Key).
	 * @exception Exception It's a general Exception, It's return null value and
	 *                      throw exception massage in application logs.
	 * 
	 * @return XML's to request2_5 object
	 */
	public static Request2_5 parseAuaXML(String xml) {
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		xmlInputFactory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		Request2_5 request2_5 = new Request2_5();
		StringReader reader = new StringReader(xml);
		XMLEvent xmlEvent;
		try {
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(reader);
			while (xmlEventReader.hasNext()) {
				xmlEvent = xmlEventReader.nextEvent();
				if (xmlEvent.isStartElement()) {
					StartElement startElement = xmlEvent.asStartElement();
					switch (startElement.getName().toString()) {
					case "": {// do nothing}

						break;
					}
					case "Txn": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.txn_subAua = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Ver": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.ver = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "SubAUACode": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.sa = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "ReqType": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.reqType = xmlEvent.asCharacters().getData();
						}
						break;
					}
					// add new filed in 24.08.2021
					/*
					 * case "lk": { xmlEvent = xmlEventReader.nextEvent(); if
					 * (xmlEvent.isCharacters()) { request2_5.subauaLk =
					 * xmlEvent.asCharacters().getData(); } break; }
					 */
					case "UID": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							try {
								request2_5.uid = new String(
										Base64.getDecoder().decode(xmlEvent.asCharacters().getData()), "utf-8");
							} catch (Exception e) {
								ApplicationLogger.logAsyncAua("Error getting UID:", e);
							}
						}
						break;
					}
					case "Rc": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.rc = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Type": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.type = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Ts": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.ts = xmlEvent.asCharacters().getData();
						}
						break;
					}
					// Modified Info tag at 24.08.2021
					case "Info": {
						request2_5.info = new Info();
						request2_5.info.rdsrno = startElement.getAttributeByName(AppConstants.QNAME_RDSRNO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSRNO).getValue();
						request2_5.info.appCode = startElement.getAttributeByName(AppConstants.QNAME_APPCODE) == null
								? ""
								: startElement.getAttributeByName(AppConstants.QNAME_APPCODE).getValue();
						request2_5.info.scheamCode = startElement
								.getAttributeByName(AppConstants.QNAME_SCHEMECODE) == null ? ""
										: startElement.getAttributeByName(AppConstants.QNAME_SCHEMECODE).getValue();
						break;

					}
					case "Uses": {
						request2_5.uses = new Uses();
						request2_5.uses.pi = startElement.getAttributeByName(AppConstants.QNAME_PI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PI).getValue();
						request2_5.uses.pa = startElement.getAttributeByName(AppConstants.QNAME_PA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PA).getValue();
						request2_5.uses.pfa = startElement.getAttributeByName(AppConstants.QNAME_PFA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PFA).getValue();
						request2_5.uses.bio = startElement.getAttributeByName(AppConstants.QNAME_BIO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_BIO).getValue();
						request2_5.uses.bt = startElement.getAttributeByName(AppConstants.QNAME_BT) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_BT).getValue();
						request2_5.uses.pin = startElement.getAttributeByName(AppConstants.QNAME_PIN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PIN).getValue();
						request2_5.uses.otp = startElement.getAttributeByName(AppConstants.QNAME_OTP) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_OTP).getValue();
						break;
					}
					case "Meta": {
						request2_5.meta = new Meta();
						request2_5.meta.dpId = startElement.getAttributeByName(AppConstants.QNAME_DPID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DPID).getValue();
						request2_5.meta.rdsId = startElement.getAttributeByName(AppConstants.QNAME_RDSID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSID).getValue();
						request2_5.meta.rdsVer = startElement.getAttributeByName(AppConstants.QNAME_RDSVER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSVER).getValue();
						request2_5.meta.dc = startElement.getAttributeByName(AppConstants.QNAME_DC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DC).getValue();
						request2_5.meta.mi = startElement.getAttributeByName(AppConstants.QNAME_MI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_MI).getValue();
						request2_5.meta.mc = startElement.getAttributeByName(AppConstants.QNAME_MC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_MC).getValue();
						break;
					}

					case "Skey": {
						request2_5.skey = new Skey();
						request2_5.skey.ci = startElement.getAttributeByName(AppConstants.QNAME_CI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CI).getValue();
						if (startElement.getAttributeByName(AppConstants.QNAME_TYPE) != null) {
							request2_5.skey.type = startElement.getAttributeByName(AppConstants.QNAME_TYPE).getValue();
						}
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.skey.Data = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Data": {
						request2_5.data = new Data();
						request2_5.data.type = DataType
								.fromValue(startElement.getAttributeByName(AppConstants.QNAME_TYPE).getValue());
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.data.data = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Hmac": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.hmac = xmlEvent.asCharacters().toString().getBytes();
						}
						break;
					}
					case "ch": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.ch = xmlEvent.asCharacters().getData();
						}
						break;
					}
					}
				}
			}
		} catch (Exception e) {
			ApplicationLogger.logAsyncAua("Error parsing Sub-AUA XML:", e);
			return null;
		}
		return request2_5;
	}

	/**
	 * @param XML Request XML which sent by AUA, If the XML's is null and occurred
	 *            any exception to run time it self it return null value.
	 * 
	 * @exception Exception It's a general Exception, It's return null value and
	 *                      throw exception massage in application logs.
	 * 
	 * @return XML's to request2_5 object
	 */
	public static Request2_5 parseAsaXML(String xml) {
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		xmlInputFactory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		Request2_5 request2_5 = new Request2_5();
		StringReader reader = new StringReader(xml);
		XMLEvent xmlEvent;
		try {
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(reader);
			while (xmlEventReader.hasNext()) {
				xmlEvent = xmlEventReader.nextEvent();
				if (xmlEvent.isStartElement()) {
					StartElement startElement = xmlEvent.asStartElement();
					switch (startElement.getName().getLocalPart().toString()) {
					case "": {// do nothing}
						break;
					}
					case "Auth": {
						request2_5.ac = startElement.getAttributeByName(AppConstants.QNAME_AC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_AC).getValue();
						request2_5.lk = startElement.getAttributeByName(AppConstants.QNAME_LK) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LK).getValue();
						request2_5.rc = startElement.getAttributeByName(AppConstants.QNAME_RC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RC).getValue();
						request2_5.sa = startElement.getAttributeByName(AppConstants.QNAME_SA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_SA).getValue();
						request2_5.tid = startElement.getAttributeByName(AppConstants.QNAME_TID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TID).getValue();
						request2_5.txn = startElement.getAttributeByName(AppConstants.QNAME_TXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TXN).getValue();
						request2_5.uid = startElement.getAttributeByName(AppConstants.QNAME_UID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_UID).getValue();
						request2_5.ver = startElement.getAttributeByName(AppConstants.QNAME_VER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_VER).getValue();
						request2_5.reqType = "other";
						break;
					}
					case "Uses": {
						request2_5.uses = new Uses();
						request2_5.uses.pi = startElement.getAttributeByName(AppConstants.QNAME_PI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PI).getValue();
						request2_5.uses.pa = startElement.getAttributeByName(AppConstants.QNAME_PA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PA).getValue();
						request2_5.uses.pfa = startElement.getAttributeByName(AppConstants.QNAME_PFA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PFA).getValue();
						request2_5.uses.bio = startElement.getAttributeByName(AppConstants.QNAME_BIO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_BIO).getValue();
						request2_5.uses.bt = startElement.getAttributeByName(AppConstants.QNAME_BT) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_BT).getValue();
						request2_5.uses.pin = startElement.getAttributeByName(AppConstants.QNAME_PIN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PIN).getValue();
						request2_5.uses.otp = startElement.getAttributeByName(AppConstants.QNAME_OTP) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_OTP).getValue();
						break;
					}
					case "Meta": {
						request2_5.meta = new Meta();
						request2_5.meta.dpId = startElement.getAttributeByName(AppConstants.QNAME_DPID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DPID).getValue();
						request2_5.meta.rdsId = startElement.getAttributeByName(AppConstants.QNAME_RDSID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSID).getValue();
						request2_5.meta.rdsVer = startElement.getAttributeByName(AppConstants.QNAME_RDSVER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSVER).getValue();
						request2_5.meta.dc = startElement.getAttributeByName(AppConstants.QNAME_DC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DC).getValue();
						request2_5.meta.mi = startElement.getAttributeByName(AppConstants.QNAME_MI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_MI).getValue();
						request2_5.meta.mc = startElement.getAttributeByName(AppConstants.QNAME_MC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_MC).getValue();
						break;
					}

					case "Skey": {
						request2_5.skey = new Skey();
						request2_5.skey.ci = startElement.getAttributeByName(AppConstants.QNAME_CI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CI).getValue();
						if (startElement.getAttributeByName(AppConstants.QNAME_TYPE) != null) {
							request2_5.skey.type = startElement.getAttributeByName(AppConstants.QNAME_TYPE).getValue();
						}
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.skey.Data = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Hmac": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.hmac = xmlEvent.asCharacters().toString().getBytes();
						}
						break;
					}

					case "Data": {
						request2_5.data = new Data();
						request2_5.data.type = DataType
								.fromValue(startElement.getAttributeByName(AppConstants.QNAME_TYPE).getValue());
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.data.data = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Signature": {
						request2_5.isSignaturePresent = true;
						// not getting entire signature, just setting some value to check
						// Signature Element is present
						break;
					}
					case "Otp": {
						request2_5.uid = startElement.getAttributeByName(AppConstants.QNAME_UID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_UID).getValue();

						request2_5.ac = startElement.getAttributeByName(AppConstants.QNAME_AC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_AC).getValue();
						request2_5.sa = startElement.getAttributeByName(AppConstants.QNAME_SA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_SA).getValue();
						request2_5.ver = startElement.getAttributeByName(AppConstants.QNAME_VER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_VER).getValue();
						request2_5.txn = startElement.getAttributeByName(AppConstants.QNAME_TXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TXN).getValue();
						request2_5.tid = startElement.getAttributeByName(AppConstants.QNAME_TS) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TS).getValue();
						request2_5.lk = startElement.getAttributeByName(AppConstants.QNAME_LK) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LK).getValue();
						request2_5.rc = startElement.getAttributeByName(AppConstants.QNAME_RC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RC).getValue();
						request2_5.reqType = "otp";
						break;
					}
					case "Opts": {
						request2_5.ch = startElement.getAttributeByName(AppConstants.QNAME_CH) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CH).getValue();
						break;
					}

					}

				}
			}
		} catch (Exception e) {
			ApplicationLogger.logAsyncAsa("Error parsing AUA XML : ", e);
			return null;
		}
		return request2_5;

	}

	/**
	 * AUA has received response XML from ASA side and this method parse the XML's
	 * node and store data in Response2_5 class.
	 * 
	 * @param XML Response XML received from ASA
	 * @exception Genral Exception, It's return null value and throw exception value
	 *                   in application logs.
	 * @return response2_5 object of Response2_5, If the XML's is null and occurred
	 *         any exception to run time it self it return null value.
	 */
	public static Response2_5 parseCIDRXML(String xml) {
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		Response2_5 response2_5 = new Response2_5();
		StringReader reader = new StringReader(xml);
		XMLEvent xmlEvent;
		try {
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(reader);
			while (xmlEventReader.hasNext()) {
				xmlEvent = xmlEventReader.nextEvent();
				if (xmlEvent.isStartElement()) {
					StartElement startElement = xmlEvent.asStartElement();
					switch (startElement.getName().getLocalPart().toString()) {
					case "": {// do nothing}
						break;
					}
					case "AuthRes": {
						response2_5.ret = startElement.getAttributeByName(AppConstants.QNAME_RET) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RET).getValue();
						response2_5.code = startElement.getAttributeByName(AppConstants.QNAME_CODE) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CODE).getValue();
						response2_5.txn = startElement.getAttributeByName(AppConstants.QNAME_TXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TXN).getValue();
						response2_5.err = startElement.getAttributeByName(AppConstants.QNAME_ERR) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_ERR).getValue();
						response2_5.ts = startElement.getAttributeByName(AppConstants.QNAME_TS) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TS).getValue();
						response2_5.actn = startElement.getAttributeByName(AppConstants.QNAME_ACTN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_ACTN).getValue();
						response2_5.info = startElement.getAttributeByName(AppConstants.QNAME_INFO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_INFO).getValue();
						response2_5.uidToken = response2_5.info.equals("") ? ""
								: response2_5.info.substring(response2_5.info.indexOf('{') + 1,
										response2_5.info.indexOf(','));
						break;
					}

					case "BfdRanks": {
						response2_5.bfdRanks = new ArrayList<>();
						break;
					}
					case "BfdRank": {
						response2_5.bfdRanks.add(new BfdRank(
								FingerPosition
										.fromValue(startElement.getAttributeByName(AppConstants.BFDPOS).getValue()),
								Integer.parseInt(startElement.getAttributeByName(AppConstants.BFDVALUE).getValue())));

						break;
					}
					case "OtpRes": {
						response2_5.ret = startElement.getAttributeByName(AppConstants.QNAME_RET) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RET).getValue();
						response2_5.code = startElement.getAttributeByName(AppConstants.QNAME_CODE) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CODE).getValue();
						response2_5.txn = startElement.getAttributeByName(AppConstants.QNAME_TXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TXN).getValue();
						response2_5.err = startElement.getAttributeByName(AppConstants.QNAME_ERR) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_ERR).getValue();
						response2_5.ts = startElement.getAttributeByName(AppConstants.QNAME_TS) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TS).getValue();
						response2_5.info = startElement.getAttributeByName(AppConstants.QNAME_INFO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_INFO).getValue();
						//New Change
						if(!response2_5.info.equals("")) {
							String[] array = response2_5.info.split(",");
							response2_5.maskedMobile = array[6].toString();
							response2_5.maskedEmail = array[7].toString().replaceAll("}", "");
						}
						response2_5.isOtpResponse = true;
						break;
					}
					case "Signature":
						response2_5.isSignaturePresent = true;
						return response2_5;
					}
				}
			}
			return response2_5;
		} catch(ArrayIndexOutOfBoundsException e) { //changes 28/02/2022
			ApplicationLogger.logAsyncAua("Error Response Return from CIDR : "+response2_5.err, e);
			return null;
		} catch (Exception e) {
			ApplicationLogger.logAsyncAua("Error parsing CIDR Response : ", e);
			return null;
		}

	}
}