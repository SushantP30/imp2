
package com.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.models.*;
import com.enums.*;

/**
 * Validator class is validate all request entities at AUA and ASA level.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 25/08/2021
 * @since 2.5
 */

public class Validator {

	/**
	 * In Validate method It is validate request XML's data at AUA and ASA level, if
	 * all data are validating successful its self return null value else its pass
	 * error code.
	 * 
	 * @param request Object of Request2_5 class.
	 * @return Validation status either null or error code.
	 */
	public static String Validate(Request2_5 request) {
		if (request.requestTo == RequestTo.AUA) {
			// following validations applicable to only SubAUA Request XML
			if (request.txn_subAua == null || request.txn_subAua.equals("")) {
				return AppConstants.ERROR1005;
			}
			if (request.txn_subAua.length() > 50) {
				return AppConstants.ERROR1006;
			}
			if (request.ts == null || request.ts.trim().equals("")) {
				return AppConstants.ERROR1007;
			}
			if (!(request.type.equals("A") || request.type.equals("V") || request.type.equals("T")
					|| request.type.equals("E"))) {
				return AppConstants.ERROR1008;
			}
			if (!isValidUID(request.uid, request.type)) {
				return AppConstants.ERROR1009;
			}
			if (!request.ver.equals(PropertiesUtil.getApiVersion())) {
				return AppConstants.ERROR1010;
			}
			/*
			 * if (request.info.appCode.equals("")) { return AppConstants.ERROR1024;
			 * 
			 * } if (request.info.scheamCode.equals("")) { return AppConstants.ERROR1025;
			 * 
			 * }
			 */

			if (!request.reqType.equals("otp")) {// following validations not applicable to otp request

				if (request.uses == null) {
					return AppConstants.ERROR1030;
				}

				if (request.meta == null) {
					return AppConstants.ERROR1040;
				}

				if (request.skey == null) {
					return AppConstants.ERROR1011;
				}

				if (request.skey.ci.equals("")) {
					return AppConstants.ERROR1012;
				}

				if (request.data == null) {
					return AppConstants.ERROR1013;
				}

				if (request.hmac == null) {
					return AppConstants.ERROR1014;
				}

				if (request.skey.Data.equals("")) {
					return AppConstants.ERROR1015;
				}
				if (request.data.data.equals("")) {
					return AppConstants.ERROR1016;
				}
			} else {// ch element present only for otp request

				if (!(request.ch.equals("00") || request.ch.equals("01") || request.ch.equals("02")
						|| request.ch.equals(""))) {
					return AppConstants.ERROR1017;
				}
			}

			if (request.reqType.equals("bio") || request.reqType.equals("bfd")) {
				// uses
				if (!request.uses.pi.equals("n")) {
					return AppConstants.ERROR1031;
				}

				if (!request.uses.pa.equals("n")) {
					return AppConstants.ERROR1032;
				}

				if (!request.uses.pfa.equals("n")) {
					return AppConstants.ERROR1033;
				}

				if (!request.uses.bio.equals("y")) {
					return AppConstants.ERROR1034;
				}

				if (!(request.uses.bt.equals("FMR") || request.uses.bt.equals("FIR") || request.uses.bt.equals("IIR")
						|| request.uses.bt.equals("FID") || request.uses.bt.equals("FMR,FIR"))) {
					return AppConstants.ERROR1035;
				}

				if (!request.uses.pin.equals("n")) {
					return AppConstants.ERROR1036;
				}

				if (!request.uses.otp.equals("n")) {
					return AppConstants.ERROR1037;
				}
				// meta
				if (request.meta.dpId.equals("")) {
					return AppConstants.ERROR1041;
				}
				if (request.meta.rdsId.equals("")) {
					return AppConstants.ERROR1042;
				}
				if (request.meta.rdsVer.equals("")) {
					return AppConstants.ERROR1043;
				}
				if (request.meta.dc.equals("")) {
					return AppConstants.ERROR1044;
				}
				if (request.meta.mi.equals("")) {
					return AppConstants.ERROR1045;
				}
				if (request.meta.mc.equals("")) {
					return AppConstants.ERROR1046;
				}
				// Info
				if (request.info.rdsrno.equals("")) {
					return AppConstants.ERROR1023;
				}

			}
			if (request.reqType.equals("demo") || request.reqType.equals("otpAuth")) {
				// meta
				if (!request.meta.dpId.equals("")) {
					return AppConstants.ERROR1050;
				}
				if (!request.meta.rdsId.equals("")) {
					return AppConstants.ERROR1051;
				}
				if (!request.meta.rdsVer.equals("")) {
					return AppConstants.ERROR1052;
				}
				if (!request.meta.dc.equals("")) {
					return AppConstants.ERROR1053;
				}
				if (!request.meta.mi.equals("")) {
					return AppConstants.ERROR1054;
				}
				if (!request.meta.mc.equals("")) {
					return AppConstants.ERROR1055;
				}
				// uses
				if (!request.uses.bio.equals("n")) {
					return AppConstants.ERROR1034;
				}

				if (!request.uses.bt.equals("")) {
					return AppConstants.ERROR1039;
				}

			}
			if (request.reqType.equals("demo")) {
				if (!(request.uses.pi.equals("y") || request.uses.pi.equals("n"))) {
					return AppConstants.ERROR1031;
				}

				if (!(request.uses.pa.equals("y") || request.uses.pa.equals("n"))) {
					return AppConstants.ERROR1032;
				}

				if (!(request.uses.pfa.equals("y") || request.uses.pfa.equals("n"))) {
					return AppConstants.ERROR1033;
				}

				if (!(request.uses.pin.equals("n"))) {
					return AppConstants.ERROR1036;
				}
				if (!(request.uses.otp.equals("n"))) {
					return AppConstants.ERROR1037;
				}

			}

			if (request.reqType.equals("otpAuth")) {
				if (!request.uses.pi.equals("n")) {
					return AppConstants.ERROR1031;
				}

				if (!request.uses.pa.equals("n")) {
					return AppConstants.ERROR1032;
				}

				if (!request.uses.pfa.equals("n")) {
					return AppConstants.ERROR1033;
				}

				if (!request.uses.pin.equals("n")) {
					return AppConstants.ERROR1036;
				}
				if (!request.uses.otp.equals("y")) {
					return AppConstants.ERROR1038;
				}
			}
		}
		if (request.requestTo == RequestTo.ASA) {
			if (request.tid == null) {
				return AppConstants.ERROR1019;
			}
			if (!request.isSignaturePresent) {
				return AppConstants.ERROR1020;
			}

		}
		// following validations applicable to SubAUA as well as AUA Request XML

		return "";
	}

	/**
	 * @param strUID UIDAI value i.e A: Aadhaar Number (12 Digit value), V: Virtual
	 *               ID number (16 Digit value), T: UIDI Token Value (72 Digit
	 *               Value)
	 * @param type   It's Unique ID request type i.e A: Aadhaar Number, V: Virtual
	 *               Number, T: UID Token
	 * @return UID is match with pattern then pass true value else false.
	 */
	private static boolean isValidUID(String strUID, String type) {
		if (strUID == null || strUID.trim().equals("")) {
			return false;
		}
		String pattern = "\\d+";
		Pattern replace = Pattern.compile(pattern);
		Matcher m = replace.matcher(strUID);
		switch (type) {
		case "A":
			if (strUID.length() != 12) {
				return false;
			}

			if (!m.matches()) {
				return false;
			}
			return true;
		case "V":
			if (strUID.length() != 16) {
				return false;
			}

			if (!m.matches()) {
				return false;
			}
			return true;
		case "T":
			if (strUID.length() != 72) {
				return false;
			}
			return true;
		default:
			return false;
		}
	}

}
