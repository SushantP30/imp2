
package com.utils;

import com.models.*;

/**
 * Authenticator class is validate entry level requested data i.e SUB-AuA code,
 * request type, License key and AuA code at AUA and ASA level.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 25/08/2021
 * @since 2.5
 */

public class Authenticator {

	private static final String DST = "STGGOGT001";
	private static final String DSTEST = "STGDST00001GTPL";
	private static final String FCS = "SFCDG18028";
	private static final String AGRI = "SAFWC18030";
	private static final String NWR = "SNWRG18029";
	private static final String TWCD = "SWCDG18032";
	private static final String SJED = "SSJED18031";
	private static final String RAV = "SREVD18033";
	private static final String IMD = "SIMDC18034";
	private static final String TRB = "STDDP18036";
	private static final String EDU = "SEDGO18035";

//	private static final String DST = "0000970000";
//	private static final String FCS = "PFCDG18028";
//	private static final String AGRI = "PAFWC18030";
//	private static final String NWR = "PNWRG18029";
//	private static final String TWCD = "PWCDG18032";
//	private static final String SJED = "PSJED18031";
//	private static final String RAV = "PREVD18033";
//	private static final String IMD = "PIMDC18034";
//	private static final String EDU = "PEDGO18035";
//	private static final String TRB = "PTDDP18036";

	/**
	 * @param request object of Request2_5 class.
	 * @return result object of AuthenticationResult class if all data is validating
	 *         successfully then its pass true value in 'isAuthenticated' and null
	 *         value in error code else its pass false value in 'isAuthenticated'
	 *         and specified error code in 'ErrorCode'.
	 */
	public static AuthenticationResult isAuthenticated(Request2_5 request) {
		AuthenticationResult result = new AuthenticationResult();
		result.isAuthenticated = true;
		result.ErrorCode = "";

		switch (request.requestTo) {
		case AUA:
			if (request.sa == null || request.sa.equals("")) {
				result.isAuthenticated = false;
				result.ErrorCode = AppConstants.ERROR1002;
				request.reqType = (request.reqType == null) ? "NA" : request.reqType;
				break;
				// TODO: based SUB AUA code and request type check if the request is
				// authenticated
			}
			if (request.reqType == null || request.reqType.equals("")) {
				result.isAuthenticated = false;
				result.ErrorCode = AppConstants.ERROR1003;
				request.reqType = (request.reqType == null) ? "NA" : request.reqType;
				break;
			}

			switch (request.reqType) {
			case "demo": {
				if (!(request.sa.equals(FCS) || request.sa.equals(DST) || request.sa.equals(AGRI)
						|| request.sa.equals(NWR) || request.sa.equals(TWCD) || request.sa.equals(RAV)
						|| request.sa.equals(SJED) || request.sa.equals(IMD) || request.sa.equals(EDU)
						|| request.sa.equals(TRB) || request.sa.equals(DSTEST))) {
					result.isAuthenticated = false;
					result.ErrorCode = AppConstants.ERROR1002;
				}
				break;
			}
			case "bio": {
				if (!(request.sa.equals(FCS) || request.sa.equals(DST) || request.sa.equals(RAV)
						|| request.sa.equals(SJED) || request.sa.equals(TWCD) || request.sa.equals(IMD)
						|| request.sa.equals(TRB) || request.sa.equals(DSTEST))) {
					result.isAuthenticated = false;
					result.ErrorCode = AppConstants.ERROR1002;
				}
				break;
			}
			case "otp": {
				if (!(request.sa.equals(FCS) || request.sa.equals(DST) || request.sa.equals(RAV)
						|| request.sa.equals(SJED) || request.sa.equals(IMD) || request.sa.equals(TRB)
						|| request.sa.equals(DSTEST))) {
					result.isAuthenticated = false;
					result.ErrorCode = AppConstants.ERROR1002;
				}
				break;
			}
			case "otpAuth": {
				if (!(request.sa.equals(FCS) || request.sa.equals(DST) || request.sa.equals(AGRI)
						|| request.sa.equals(RAV) || request.sa.equals(SJED) || request.sa.equals(IMD)
						|| request.sa.equals(TRB) || request.sa.equals(DSTEST))) {
					result.isAuthenticated = false;
					result.ErrorCode = AppConstants.ERROR1002;
				}
				break;
			}
			case "bfd": {
				if (!(request.sa.equals(DST))) {
					result.isAuthenticated = false;
					result.ErrorCode = AppConstants.ERROR1002;
				}
				break;
			}
			default:
				result.isAuthenticated = false;
				result.ErrorCode = AppConstants.ERROR1003;
			}
			break;
		case ASA:
			if (request.ac == null || request.ac.equals("")) {
				result.isAuthenticated = false;
				result.ErrorCode = AppConstants.ERROR1018;
			}

			if (request.lk == null || request.lk.equals("")) {
				// in future when there are more AUAs then getAuaLicenseKey() by AUAcode and
				// then validate
				result.isAuthenticated = false;
				result.ErrorCode = AppConstants.ERROR2002;
			}
			break;
		}
		return result;
	}
}
