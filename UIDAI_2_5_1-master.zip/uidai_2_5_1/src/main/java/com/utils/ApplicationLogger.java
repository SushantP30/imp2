/**
 * 
 */
package com.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * ExceptionLogger class using store run time Exception value in application
 * logs for escalating to issue.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 04/09/2021
 * @since 2.5
 */
public class ApplicationLogger {
	private static final Logger AuaLogger = LogManager.getLogger("aua");
	private static final Logger AsaLogger = LogManager.getLogger("asa");
	private static final Logger DbFailLogger = LogManager.getLogger("dbFail");

	/**
	 * 
	 * Runtime Exception which come from AUA side and storing value in AUA
	 * Application logs.
	 * 
	 * @param message From where to exception occurred.
	 * @param e       run time exception value.
	 */
	public static void logAsyncAua(String message, Exception e) {
		AuaLogger.error(message, e);
	}

	/**
	 * 
	 * Runtime Exception which come from ASA side and storing value in ASA
	 * Application logs.
	 * 
	 * @param message From where to exception occurred.
	 * @param e       run time exception value.
	 */
	public static void logAsyncAsa(String message, Exception e) {
		AsaLogger.error(message, e);
	}

	/**
	 * Runtime Massage come from AUA side which throw by Developer and stored in AUA
	 * application logs.
	 * 
	 * @param message Massage printed by Developer
	 */
	public static void logAsyncAua(String message) {
		AuaLogger.error(message);
	}

	/**
	 * Runtime Massage come from ASA side which throw by Developer and stored in ASA
	 * application logs.
	 * 
	 * @param message Massage printed by Developer
	 */
	public static void logAsyncAsa(String message) {
		AsaLogger.error(message);
	}

	/**
	 * When database connection failed then database logs will be store in DB
	 * application logs
	 * 
	 * @param message database logs
	 */
	public static void logAsyncDbFail(String message) {
		DbFailLogger.error(message);
	}

}
