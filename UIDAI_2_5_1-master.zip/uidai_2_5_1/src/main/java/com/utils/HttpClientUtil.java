/**
 * 
 */
package com.utils;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.client.RestTemplate;

import com.models.SignHSM;
import com.models.SignResponse;

/**
 * The HTTP Client was added in Java 11. It can be used to request HTTP
 * resources over the network. It supports HTTP/1.1 and HTTP/2, both synchronous
 * and asynchronous programming models, handles request and response bodies as
 * reactive-streams, and follows the familiar builder pattern.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 01/09/2021
 * @since 2.5
 */
public class HttpClientUtil {
	private static String CIDR_URL;
	private static String CIDR_OTP_URL;
	private static String HSM_SIGNIN_URL;

	static {
		try {
			HSM_SIGNIN_URL = PropertiesUtil.getHSMUrl();
		}
		catch (Exception e) {
			// TODO: handle exception
			ApplicationLogger.logAsyncAua("Fatal Error generating HSM URL", e);
		}
		try {
			CIDR_URL = PropertiesUtil.getCidrAuthUrl() + "/" + PropertiesUtil.getApiVersion() + "/"
					+ PropertiesUtil.getAauaCode() + "/%1$s/%2$s/"
					+ URLEncoder.encode(PropertiesUtil.getAsaLicenseKey(), "UTF-8");
		} catch (Exception e) {
			ApplicationLogger.logAsyncAsa("Fatal Error generating CIDR URL", e);
		}
		try {
			CIDR_OTP_URL = PropertiesUtil.getCidrOtpUrl() + "/" + PropertiesUtil.getApiVersion() + "/"
					+ PropertiesUtil.getAauaCode() + "/%1$s/%2$s/"
					+ URLEncoder.encode(PropertiesUtil.getAsaLicenseKey(), "UTF-8");
		} catch (Exception e) {
			ApplicationLogger.logAsyncAsa("Fatal Error generating CIDR URL", e);
		}

	}

	/**
	 * Sends Request to ASA which hosted on same server if response didn't receive
	 * in 10 Millisecond then code itself disconnect connection and revert response.
	 * 
	 * @param signedXML   Authentication request XML's which signed by AUA.
	 * @param uid         Authenticators UIDAI number.
	 * @param requestType Request XML's type
	 * @return Authentication response's XML.
	 */
	@Async
	public static CompletableFuture<String> postToAsaAsync(String signedXML, String requestType) {
		if (requestType.equals("otp")) {
			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(PropertiesUtil.getAsaOTPServerUrl()))
					.timeout(AppConstants.TIMEOUT).header("Content-Type", "application/xml")
					.POST(BodyPublishers.ofString(signedXML)).build();
			HttpClient client = HttpClient.newHttpClient();
			return client.sendAsync(request, BodyHandlers.ofString()).thenApply(HttpResponse::body);
		} else {
			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(PropertiesUtil.getAsaAuthServerUrl()))
					.timeout(AppConstants.TIMEOUT).header("Content-Type", "application/xml")
					.POST(BodyPublishers.ofString(signedXML)).build();
			HttpClient client = HttpClient.newHttpClient();
			return client.sendAsync(request, BodyHandlers.ofString()).thenApply(HttpResponse::body);
		}

	}

	/**
	 * Sends Request to CIDR Asynchronously and if response didn't receive in 10
	 * Millisecond then code itself disconnect connection and revert response.
	 * 
	 * @param requestXML  Either Authentication request XML or OTP generations XML
	 *                    which has sent by ASA.
	 * @param uid         Authenticators UIDAI number.
	 * @param requestType Request XML's type
	 * @return CIDR Response XML
	 */
	@Async
	public static CompletableFuture<String> postToCIDRAsync(String requestXML, String uid, String requestType) {
		char ch1 = uid.charAt(0);
		char ch2 = uid.charAt(1);

		if (uid.length() != 12) {
			ch1 = '0';
			ch2 = '0';
		} else {
			ch1 = uid.charAt(0);
			ch2 = uid.charAt(1);
		}          
		if (requestType.equals("otp")) {
			//ExceptionLogger.logAsyncAsa("In Http Clint  ==  "+requestXML);
			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(String.format(CIDR_OTP_URL, ch1, ch2)))
					.timeout(AppConstants.TIMEOUT).header("Content-Type", "application/xml")
					.POST(BodyPublishers.ofString(requestXML)).build();
			HttpClient client = HttpClient.newHttpClient();
			return client.sendAsync(request, BodyHandlers.ofString()).thenApply(HttpResponse::body);
		} else {

			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(String.format(CIDR_URL, ch1, ch2)))
					.timeout(AppConstants.TIMEOUT).header("Content-Type", "application/xml")
					.POST(BodyPublishers.ofString(requestXML)).build();
			HttpClient client = HttpClient.newHttpClient();
			return client.sendAsync(request, BodyHandlers.ofString()).thenApply(HttpResponse::body);
		}
		

	}

	/**
	 * Sends Request to HSM Asynchronously for singing XML.
	 * 
	 * @param signHsm is object of SignHSM class.
	 * @return response to SignResponse class.
	 */
	@Async
	public static SignResponse sendToHsm(SignHSM signHsm) {
		RestTemplate restTemplate = new RestTemplate(getClientHttpRequestFactory());
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<SignHSM> entity = new HttpEntity<>(signHsm, headers);
		return restTemplate.exchange(HSM_SIGNIN_URL, HttpMethod.POST, entity, SignResponse.class).getBody();
	}

	/**
	 * Set here connection time out (the timeout value in milliseconds) to
	 * connecting to HSM and value is 10.
	 */
	private static HttpComponentsClientHttpRequestFactory getClientHttpRequestFactory() {
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		// Connect timeout
		clientHttpRequestFactory.setConnectTimeout(45);

		// Read timeout
		// clientHttpRequestFactory.setReadTimeout(10);
		return clientHttpRequestFactory;
	}

}
