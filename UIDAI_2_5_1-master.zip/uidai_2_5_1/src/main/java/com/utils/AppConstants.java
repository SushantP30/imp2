/**
 * 
 */
package com.utils;

import java.time.Duration;

import javax.xml.namespace.QName;

/**
 * AppConstants Interface demonstrated Fixed Error code for AUA and ASA,
 * Connection Timeout value and declared QNAME for XMLs attributes.
 * 
 * @author Harsh. H. Barot
 * @version 2.5.1, 26/08/2021
 * @since 2.5
 *
 */
public interface AppConstants {
	public Duration TIMEOUT = Duration.ofSeconds(10);
	// attributes for node Auth
	public QName QNAME_AC = new QName("ac");
	public QName QNAME_LK = new QName("lk");
	public QName QNAME_RC = new QName("rc");
	public QName QNAME_SA = new QName("sa");
	public QName QNAME_TID = new QName("tid");
	public QName QNAME_TXN = new QName("txn");
	public QName QNAME_UID = new QName("uid");
	public QName QNAME_VER = new QName("ver");
	// attributes for node Uses
	public QName QNAME_PI = new QName("pi");
	public QName QNAME_PA = new QName("pa");
	public QName QNAME_PFA = new QName("pfa");
	public QName QNAME_BIO = new QName("bio");
	public QName QNAME_BT = new QName("bt");
	public QName QNAME_PIN = new QName("pin");
	public QName QNAME_OTP = new QName("otp");
	// attributes for node Meta
	public QName QNAME_DPID = new QName("dpId");
	public QName QNAME_RDSID = new QName("rdsId");
	public QName QNAME_RDSVER = new QName("rdsVer");
	public QName QNAME_DC = new QName("dc");
	public QName QNAME_MI = new QName("mi");
	public QName QNAME_MC = new QName("mc");
	// attributes for node Skey
	public QName QNAME_CI = new QName("ci");

	public QName QNAME_TYPE = new QName("type");
	public QName QNAME_CH = new QName("ch");
	// attributes for node Info
	public QName QNAME_RDSRNO = new QName("rdsrno");
	public QName QNAME_APPCODE = new QName("appCode");
	public QName QNAME_SCHEMECODE = new QName("schemeCode");
	// attributes for CIDR Response XML
	public QName QNAME_RET = new QName("ret");
	public QName QNAME_CODE = new QName("code");
	public QName QNAME_ERR = new QName("err");
	public QName QNAME_TS = new QName("ts");
	public QName QNAME_ACTN = new QName("actn");
	public QName QNAME_INFO = new QName("info");
	
	//testing
	public QName BFDPOS = new QName("pos");
	public QName BFDVALUE = new QName("value");

	// ********************1. Application's Status ************************
	public String AAPSTATUSAUA = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><status>AUA of GOG Up &amp; Runing</status>";
	public String AAPSTATUSASA = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><status>ASA of GOG Up &amp; Runing</status>";

	// ********************2. Error Constant ******************************
	// ********************2.1. Parse the XML to Object *******************
	public String ERROR1001 = "1001:XML is not as per the GOG AUA-ASA XSD Standard";

	// ********************2.2. Authentication ****************************
	public String ERROR1002 = "1002:SUB-AUA code is either null or invalid";
	public String ERROR1003 = "1003:ReqType either null or invalid";
	//public String ERROR1004 = "1004:SUB-AUA lincense key is null";
	public String ERROR1018 = "1018:AUA Code is required";
	public String ERROR2002 = "2002:AUA license key expired or invalid";

	// ********************2.3. Validation ********************************
	public String ERROR1005 = "1005:Txn is required";
	public String ERROR1006 = "1006:Txn is invalid";
	public String ERROR1007 = "1007:Ts is required";
	public String ERROR1008 = "1008:UID type is invalid";
	public String ERROR1009 = "1009:UID/VID/UID Token is invalid or null";
	public String ERROR1010 = "1010:Ver is null or invalid";
	public String ERROR1011 = "1011:Skey is required";
	public String ERROR1012 = "1012:Skey.ci is required";
	public String ERROR1013 = "1013:Data tag is invalid or null";
	public String ERROR1014 = "1014:Hmac tag is invalid or null";
	public String ERROR1015 = "1015:Skey.Data tag is invalid or null";
	public String ERROR1016 = "1016:Data tag is invalid or null";
	public String ERROR1017 = "1017:ch is invalid or null";

	// ********************2.3.1 Uses *************************************
	public String ERROR1030 = "1030:Uses is required";
	public String ERROR1031 = "1031:Uses.Pi is missing or invalid";
	public String ERROR1032 = "1032:Uses.Pa is missing or invalid";
	public String ERROR1033 = "1033:Uses.pfa is missing or invalid";
	public String ERROR1034 = "1034:Uses.bio is missing or invalid";
	public String ERROR1035 = "1035:Uses.bt has invalid or null";
	public String ERROR1036 = "1036:Uses.pin is missing or invalid";
	public String ERROR1037 = "1037:Uses.otp is missing or invalid";
	public String ERROR1038 = "1038:Uses.otp value is required";
	public String ERROR1039 = "1039:Uses.bt must be blank";

	// ********************2.3.2 Meta (Required) **************************
	public String ERROR1040 = "1040:Meta is required";
	public String ERROR1041 = "1041:Meta.dpId is required";
	public String ERROR1042 = "1042:Meta.rdsId is required";
	public String ERROR1043 = "1043:Meta.rdsVer is required";
	public String ERROR1044 = "1044:Meta.dc is required";
	public String ERROR1045 = "1045:Meta.mi is required";
	public String ERROR1046 = "1046:Meta.mc is required";

	// ********************2.3.3 Meta (Must Be Blank) *********************
	public String ERROR1050 = "1050:Meta.dpId value must be blank";
	public String ERROR1051 = "1051:Meta.rdsId value must be blank";
	public String ERROR1052 = "1052:Meta.rdsVer value must be blank";
	public String ERROR1053 = "1053:Meta.dc value must be blank";
	public String ERROR1054 = "1054:Meta.mi value must be blank";
	public String ERROR1055 = "1055:Meta.mc value must be blank";

	// ********************2.3.4 Info *************************************
	public String ERROR1023 = "1023:Info.rdsrno is required";
	public String ERROR1024 = "1024:Info.appCode is required";
	public String ERROR1025 = "1025:Info.scheamCode is required";

	// ********************2.4. ASA ***************************************
	public String ERROR1019 = "1019:tid is required";
	public String ERROR1020 = "1020:AUAs Signature is required";

	// ********************2.5. HSM and Signing ****************************
	public String ERROR1021 = "1021:HSM is Down";
	public String ERROR1022 = "1022:Signing Issue";

	// ********************2.6. Signature Verification *********************

	// ********************2.7. Issue from CIDR ****************************
	public String ERROR3001 = "3001:CIDR Service is not available";// CIDR Services is not available
	public String ERROR3002 = "3002:CIDR Service is not available";// ASA Services is not available
	public String ERROR3003 = "3003:CIDR Service is not available";// AUA Services is not available

}
