/**
 * 
 */
package com.utils;

import java.time.LocalDateTime;
import java.util.Random;

/**
 * Generate unique transaction ID which used for communication between AUA and
 * CIDR.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 26/08/2021
 * @since 2.5
 */
public class TransactionNoUtil {
	/**
	 * generates unique transaction no format in For Bio/Demo/BFD-->
	 * AUACode:YYYYMMDD/hhMMss/(nanosecond)/(UID extract)/(3 digit random no) For
	 * OTP and OTP Auth-->(auacode):(sub AUA code):(transaction No of Sub AUA)
	 * 
	 * @param uid         Citizen UID Number
	 * @param requestType current request being processed
	 * @return String Unique transaction No
	 */

	public static String generateTxnNo(String uid, String requestType) {
		Random rnd = new Random();
		LocalDateTime dt = LocalDateTime.now();
		if (requestType.equals("otp") || requestType.equals("otpAuth")) {
			// return PropertiesUtil.getAauaCode() + ":" + request.sa + ":" +
			// request.txn_subAua;
			return new StringBuilder().append(PropertiesUtil.getAauaCode()).append(":").append(dt.getYear())
					.append(dt.getMonthValue()).append(dt.getDayOfMonth()).append(dt.getHour()).append(uid.charAt(0))
					.append(uid.charAt(2)).append(uid.charAt(4)).append(uid.charAt(6)).append(uid.charAt(8))
					.append(uid.charAt(10)).toString();
		} else if (requestType.equals("demo") || requestType.equals("bio")) {
			return new StringBuilder().append(PropertiesUtil.getAauaCode()).append(":").append(dt.getYear())
					.append(dt.getMonthValue()).append(dt.getDayOfMonth()).append("/").append(dt.getHour())
					.append(dt.getMinute()).append(dt.getSecond()).append("/")
					.append(Integer.toString(dt.getNano()).substring(0, 6)).append("/").append(uid.charAt(0))
					.append(uid.charAt(2)).append(uid.charAt(4)).append(uid.charAt(6)).append(uid.charAt(8))
					.append(uid.charAt(10)).append("/").append(rnd.nextInt(1000)).toString();
		} else {

			return new StringBuilder().append("ubfd").append(":").append(dt.getYear())
					.append(dt.getMonthValue()).append(dt.getDayOfMonth()).append("/").append(dt.getHour())
					.append(dt.getMinute()).append(dt.getSecond()).append("/")
					.append(Integer.toString(dt.getNano()).substring(0, 6)).append("/").append(uid.charAt(0))
					.append(uid.charAt(2)).append(uid.charAt(4)).append(uid.charAt(6)).append(uid.charAt(8))
					.append(uid.charAt(10)).append("/").append(rnd.nextInt(1000)).toString();
		}
	}

}
