/**
 * 
 */
package com.models;

/**
 * Value of this element is base-64 encoded value of encrypted 256-bit AES
 * session key. Session key must be dynamically generated for every transaction
 * (session key must not be reused) and must not be stored anywhere except in
 * memory. See next chapter for encryption details.
 * 
 * @author Harsh. H. Barot
 * @version 2.5.1, 26/08/2021
 * @since 2.5
 */
public class Skey {
	/**
	 * (mandatory) Public key certificate identifier using which “skey” was
	 * encrypted. UIDAI may have multiple public keys in field at the same time.
	 * Value of this attribute is the certificate expiration date in the format
	 * “YYYYMMDD”. Expiry date of the certificate can be obtained from the
	 * certificate itself.
	 */
	public String ci;
	/**
	 * (optional) Type of the PID block format. It can have two values – “X” for XML
	 * and “P” for Protobuf binary format. Default value is assumed to be “X”.
	 */
	public String type = "";
	/**
	 * Contains the encrypted “Pid” element in base-64 format. See “Pid” element
	 * definition later.
	 */
	public String Data = "";

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Skey [ci=");
		builder.append(ci);
		builder.append(", type=");
		builder.append(type);
		builder.append(", Data=");
		builder.append(Data);
		builder.append("]");
		return builder.toString();
	}

}
