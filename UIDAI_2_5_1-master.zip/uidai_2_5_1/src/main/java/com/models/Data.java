/**
 * 
 */
package com.models;

import com.enums.*;

/**
 * “Data” element contains “Pid” (Personal Identity Data) element which is a
 * base-64 encoded encrypted block. Complete “Data” block should be encrypted at
 * the time of capture on the client. But, encoding (base-64) of “Data” block
 * and packaging it with enveloping XML under “Auth” element can either be done
 * on the device or on the AUA server based on the AUA needs. Device capability,
 * protocol between devices and AUA server, and data format used between devices
 * and AUA server, etc. should be considered for making that choice.
 * 
 * @author Harsh. H. Barot
 * @version 2.5.1, 26/08/2021
 * @since 2.5
 * 
 */
public class Data {

	/**
	 * Contains the encrypted “Pid” element in base-64 format. See “Pid” element
	 * definition later.
	 */
	public String data;

	/**
	 * (optional) Type of the PID block format. It can have two values – “X” for XML
	 * and “P” for Protobuf binary format. Default value is assumed to be “X”.
	 */
	public DataType type;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Data [data=");
		builder.append(data);
		builder.append(", type=");
		builder.append(type);
		builder.append("]");
		return builder.toString();
	}

}
