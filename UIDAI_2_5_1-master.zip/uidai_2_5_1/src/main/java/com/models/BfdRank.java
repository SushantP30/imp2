/**
 * 
 */
package com.models;

import com.enums.*;

/**
 * XMLBuilder class is build several XMLs i.e Authentication Request XML, OTP
 * Generation XML, Response XML, Error XML, OTP Response XML.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 08/09/2021
 * @since 2.5
 */
public class BfdRank {
	/**
	 * Finger position for which matching rank is provided. Possible values are same
	 * as that of “pos” attribute within “Bio” element of Authentication PID XML.
	 */
	public FingerPosition pos;
	/**
	 * This attribute indicates a value between 1 and 10. This attribute indicates
	 * the order of preference in which resident should use his/her fingers for
	 * authentication. Value 1 indicates first choice and 10 indicates last choice.
	 */
	public int value;

	/**
	 * Constructor useful in ParseUtil class when transaction request type is BFD
	 * and ASA receive repose from CIDR.
	 * 
	 * @param pos   Finger attribute which received from response XML.
	 * @param value Value 1 indicates first choice and 10 indicates last choice
	 */
	public BfdRank(FingerPosition pos, int value) {
		super();
		this.pos = pos;
		this.value = value;
	}

}
