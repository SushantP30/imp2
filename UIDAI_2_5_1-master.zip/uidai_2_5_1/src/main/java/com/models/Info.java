
package com.models;

/**
 * (Mandatory): This element specifies of transaction related information and
 * remove unnecessary attributes (i.e txnType, scheamName, buildingNo, street,
 * city, pinCode); Add new attribute (i.e appCode, scheamCode)
 * 
 * @author Harsh. H. Barot
 * @version 2.5.1, 24/08/2021
 * @since 2.5
 * 
 */
public class Info {

	/**
	 * (Mandatory) this attribute use for device serial number. When using
	 * biometric/BFD authentication take the serial number from RD service and put
	 * in this attribute.
	 */
	public String rdsrno = "NA";

	/**
	 * (Mandatory) SUB-AUA mention specific application name where the
	 * authentication transaction has occurred.
	 */
	public String appCode = "NA";

	/**
	 * (Mandatory) SUB-AUA mention specific application name where the
	 * authentication transaction has occurred.
	 */
	public String scheamCode = "NA";

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Info [rdsrno=");
		builder.append(rdsrno);
		builder.append(", appCode=");
		builder.append(appCode);
		builder.append(", schemeCode=");
		builder.append(scheamCode);
		builder.append("]");
		return builder.toString();
	}

	public String toStringForDb() {
		StringBuilder builder = new StringBuilder();
		builder.append(rdsrno);
		builder.append(",");
		builder.append(appCode);
		builder.append(",");
		builder.append(scheamCode);
		return builder.toString();
	}

}
