package com.models;

/**
 * This is Pojo class for request attribute for signing XML via HSM.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 08/09/2021
 * @since 2.5
 */
public class SignHSM {

	/**
	 * (mandatory) Signing Key Label
	 */
	public String keylabel = "1300";

	/**
	 * (mandatory) OTP Request unsigned XML in Base64 Encoded String format
	 */
	public String orgXML;

	/**
	 * (mandatory) Transaction Id for reference. It's a Authentication TXN ID.
	 */
	public String txn;

	@Override
	public String toString() {
		return "SignHSM [orgXML=" + orgXML + ", txn=" + txn + "]";
	}

}
