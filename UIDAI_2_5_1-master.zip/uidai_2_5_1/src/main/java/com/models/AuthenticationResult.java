/**
 * 
 */
package com.models;

/**
 * AuthenticationResult class is demonstrate the value of AuthenticatonResult
 * and errorCode
 * 
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 25/08/2021
 * @since 2.5
 */
public class AuthenticationResult {
	/**
	 * isAuthenticated is retrieved value from Authenticator.isAuthenticated after
	 * validate entry level requested data at AUA and ASA level.
	 */
	public boolean isAuthenticated;
	/**
	 * ErrorCode is demonstrate value of error which accord from authentication API.
	 */
	public String ErrorCode;

}
