package com.models;

/**
 * This is Pojo class for Response attribute for signing XML via HSM.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 08/09/2021
 * @since 2.5
 */
public class SignResponse {

	/**
	 * Error Message with cause
	 */
	public String errMsg;

	/**
	 * Base 64 encoded signed XML string
	 */
	public String signedXML;

	/**
	 * Positive Value represents success Negative Value represents failure
	 * 
	 */
	public int status;

	/**
	 * Transaction Id for reference. It's a Authentication TXN ID.
	 * 
	 */
	public String txn;
	
	/**
	 * HSM error code.
	 */
	public String errCode;

	@Override
	public String toString() {
		return "SignResponse [errMsg=" + errMsg + ", signedXML=" + signedXML + ", status=" + status + ", txn=" + txn
				+ ", errCode=" + errCode + "]";
	}


	
}
