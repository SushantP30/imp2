/**
 * 
 */
package com.models;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * The class is demonstrate AUA and ASA transaction count since server has
 * started.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 08/09/2021
 * @since 2.5
 */
public class Statistics {
	public static final LocalDateTime serverStarted = LocalDateTime.now();
	static AtomicInteger totalAUARequests = new AtomicInteger(0);
//	static AtomicInteger todayAUARequests = new AtomicInteger(0);
	static AtomicInteger totalASARequests = new AtomicInteger(0);
//	static AtomicInteger todayASARequests = new AtomicInteger(0);

	public static void addRequests_AUA() {
		totalAUARequests.getAndIncrement();
//		todayAUARequests.getAndIncrement();
	}

	public static void addRequests_ASA() {
		totalASARequests.getAndIncrement();
//		todayASARequests.getAndIncrement();
	}

	public static String getStats() {
		StringBuilder sb = new StringBuilder();
		return sb.append("Server Started:").append(serverStarted).append(System.lineSeparator())
				.append("================AUA Server ====================").append(System.lineSeparator())
				.append("Total Request: ").append(totalAUARequests).append(System.lineSeparator())
//				.append("Today's Request: ").append(todayAUARequests).append(System.lineSeparator())
				.append("================ASA Server ====================").append(System.lineSeparator())
				.append("Total Request: ").append(totalASARequests).append(System.lineSeparator())
//				.append("Today's Request: ").append(todayASARequests).append(System.lineSeparator())
				.toString();
	}

}
