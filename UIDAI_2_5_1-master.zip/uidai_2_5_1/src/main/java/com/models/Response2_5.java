/**
 * 
 */
package com.models;

import java.util.List;

/**
 * This is Model class for response's entities data for Authentication XML.
 * 
 * @author Harsh. H. Barot
 * @version 2.5.1, 04/09/2021
 * @since 2.5
 * 
 */
public class Response2_5 {
	/**
	 * This is the main authentication response. It is either “y” or “n”.
	 */
	public String ret;
	/**
	 * unique alphanumeric “authentication response” code having maximum length 40.
	 * If the input is “not” processed due to errors such as decryption, wrong hmac
	 * value, etc., a value of “NA” will be returned. But, due to some transmission
	 * errors or changes in deployments, if code is returned as “NA”, AUAs may retry
	 * the transaction and if it continues to fail, may report to UIDAI technical
	 * support
	 */
	public String code = "";
	/**
	 * Authenticator specific transaction identifier. This is exactly the same value
	 * that is sent within the request.
	 */
	public String txn;
	/**
	 * SUB-AUAs transaction ID which received from SUB-AUAs side.
	 */
	public String txn_subAua;
	/**
	 * Error Code which occurred from AUA and ASA side.
	 */
	public String err = "NA";
	/**
	 * Timestamp when the response is generated from CIDR Side. This is of type XSD
	 * dateTime
	 */
	public String ts;
	/**
	 * This attribute may or may not exist in response. This attribute, alphanumeric
	 * of max length 5, provides specific action codes (published from time to time)
	 * meant to be shown to Aadhaar number holder or operator. Refer to latest
	 * action codes at API error handling section of authentication portal at
	 * https://authportal.uidai.gov.in/developer o One possible use is to provide
	 * feedback to Aadhaar number holder for improving authentication outcomes and
	 * required data update notifications. o This attribute MUST be sent to
	 * front-end application by ASA/KSA and AUA/KUA to ensure action and
	 * corresponding message is displayed to Aadhaar number holder or operator
	 */
	public String actn = "NA";
	/**
	 * This attribute provides information on the details included in auth.
	 */
	public String info = "";
	/**
	 * Is the Agency specific and unique Aadhaar token generated for the resident.
	 * If this field may have value “NA” if there is a system error (such as
	 * signature/LK errors, internal errors, etc.)
	 */
	public String uidToken = "";
	/**
	 * (this element will be present ONLY when doing BFD) Biometric matching ranks
	 * for each finger that was part of input for BFD service.
	 * 
	 */
	public List<BfdRank> bfdRanks;
	/**
	 * UIDAI's Signature value is true or false and default is false.
	 */
	public boolean isSignaturePresent = false;

	/**
	 * Authenticator's Masked Mobile Number
	 */
	public String maskedMobile = "NA";
	/**
	 * Authenticator's Masked E-Mail Address
	 */
	public String maskedEmail = "NA";
	/**
	 * OTP Response
	 */
	public boolean isOtpResponse = false;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Response2_5 ret=");
		builder.append(ret);
		builder.append(", code=");
		builder.append(code);
		builder.append(", txn=");
		builder.append(txn);
		builder.append(", txn_subAua=");
		builder.append(txn_subAua);
		builder.append(", err=");
		builder.append(err);
		builder.append(", ts=");
		builder.append(ts);
		builder.append(", actn=");
		builder.append(actn);
		builder.append(", info=");
		builder.append(info);
		builder.append(", uidToken=");
		builder.append(uidToken);
		builder.append(", isSignaturePresent=");
		builder.append(isSignaturePresent);
		builder.append(", maskedMobile=");
		builder.append(maskedMobile);
		builder.append(", maskedEmail=");
		builder.append(maskedEmail);
		builder.append(", isOtpResponse=");
		builder.append(isOtpResponse);
		builder.append("]");
		return builder.toString();
	}
}
