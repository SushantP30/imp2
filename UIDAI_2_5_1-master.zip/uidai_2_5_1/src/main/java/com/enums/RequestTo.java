/**
 * 
 */
package com.enums;

/**
 * Demonstrate Value of two different service like AUA and ASA.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 04/09/2021
 * @since 2.5
 */
public enum RequestTo {
	AUA, ASA;

	public String value() {
		return name();
	}

	public static RequestTo fromValue(String v) {
		return valueOf(v);
	}
}
