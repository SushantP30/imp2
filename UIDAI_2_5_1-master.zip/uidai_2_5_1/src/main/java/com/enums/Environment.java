/**
 * 
 */
package com.enums;

/**
 * Demonstrate Value of Environment type.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 04/09/2021
 * @since 2.5
 */
public enum Environment {
	Staging, Production;

}
