/**
 * 
 */
package com.enums;

/**
 * Type of the PID block format. It can have two values – “X” for XML and “P”
 * for Protobuf binary format. Default value is assumed to be “X”
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 04/09/2021
 * @since 2.5
 */

public enum DataType {
	X, P;

	public String value() {
		return name();
	}

	public static DataType fromValue(String v) {
		return valueOf(v);
	}
}
