/**
 * 
 */
package com.enums;

/**
 * Finger position for which matching rank is provided. Possible values are same
 * as that of “pos” attribute within “Bio” element of Authentication PID XML.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 08/09/2021
 * @since 2.5
 */
public enum FingerPosition {
	LEFT_INDEX, LEFT_LITTLE, LEFT_MIDDLE, LEFT_RING, LEFT_THUMB, RIGHT_INDEX, RIGHT_LITTLE, RIGHT_MIDDLE, RIGHT_RING,
	RIGHT_THUMB, UNKNOWN;

	public String value() {
		return name();
	}

	public static FingerPosition fromValue(String v) {
		return valueOf(v);
	}
}
