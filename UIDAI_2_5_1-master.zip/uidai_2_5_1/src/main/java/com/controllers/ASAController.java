/**
 * 
 */
package com.controllers;

import javax.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.models.AuthenticationResult;
import com.models.Request2_5;
import com.models.Response2_5;
import com.models.Statistics;
import com.enums.*;
import com.utils.AppConstants;
import com.utils.AuditUtil;
import com.utils.Authenticator;
import com.utils.DateTimeUtil;
import com.utils.ApplicationLogger;
import com.utils.HttpClientUtil;
import com.utils.ParseUtil;
import com.utils.Validator;
import com.utils.XMLBuilder;

/**
 * An organization or an entity providing connectivity using private secure
 * network to UIDAI’s data centres for transmitting authentication requests from
 * various AUAs.
 * <p>
 * Department of Science and Technology, Government of Gujarat registered as ASA
 * in India, that uses Aadhaar authentication services of UIDAI and sends
 * authentication requests to enable its services / business functions.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 04/09/2021
 * @since 2.5
 */
@SpringBootApplication
@RestController
@RequestMapping("/ASA2_5/rest")
public class ASAController {

	/**
	 * User can check with the concern parameter the Aadhaar authentication API 2.5
	 * is running or not.
	 * 
	 * @return Application status XML.
	 */
	@GetMapping(value = "/checkasastatus25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String checkASAStatus() {
		return AppConstants.AAPSTATUSASA;
	}

	/**
	 * Generate the OTP for Aadhaar Authentication via the this method. OTP should
	 * forward to concern's mail or mobile.
	 * 
	 * @param requestXML  OTP Generating requesting XML's which is requested by
	 *                    AUA's portal for generating OTP
	 * @param httpRequest Extends the {@link javax.servlet.ServletRequest} interface
	 *                    to provide request
	 * @return XML Response XML which received by CIDR and OTP sent to citizen's
	 *         mail or mobile.
	 */
	@PostMapping(value = "/genOtp25", produces = { "application/xml" })
	public String acceptRequest25_OTP(@RequestBody String requestXML, HttpServletRequest httpRequest) {
		return processAndBuildResponse(requestXML, httpRequest);
	}

	/**
	 * @param requestXML  Aadhaar Authentications request XML,which is requested by
	 *                    AUA's portal for Aadhaar Authentication
	 * @param httpRequest Extends the {@link javax.servlet.ServletRequest} interface
	 *                    to provide request
	 * @return XML Response XML which received by CIDR.
	 */
	@PostMapping(value = "/authreqv25", produces = { "application/xml" })
	public String acceptRequest25(@RequestBody String requestXML, HttpServletRequest httpRequest) {
		return processAndBuildResponse(requestXML, httpRequest);
	}

	/**
	 * @param requestXML  It's either Aadhaar Authentication request XML or OTP
	 *                    Generating requesting XML's which is requested by AuAs.
	 * @param httpRequest Extends the {@link javax.servlet.ServletRequest} interface
	 *                    to provide request
	 * @version 2.5.1, 24/08/2021
	 * @see 2.5
	 * @return XML Response XML.
	 */
	private String processAndBuildResponse(String requestXML, HttpServletRequest httpRequest) {
		Statistics.addRequests_ASA();
		Response2_5 errorResponse = new Response2_5();

		/**
		 * <h1>1.Parse the XML to Object</h1>
		 * 
		 * @param requestXML which received from AUA.
		 * 
		 * @return request object of Request2_5 class, If the XML's is null and Occurred
		 *         any kind of error from ParseUtil class itself return error (1001:XML
		 *         is not as per the GOG AUA-ASA XSD Standard).
		 */

		// ********************1. Parse the XML to Object *********************
		Request2_5 request = ParseUtil.parseAsaXML(requestXML);
		if (request == null) {
			errorResponse.err = AppConstants.ERROR1001;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			return XMLBuilder.buildASARespForError(errorResponse, "");
		}
		// ********************************************************************

		/**
		 * <h1>2. Authenticate</h1>
		 * 
		 * @param request Object of Request2_5 class which pass in Authenticator class
		 *                for validating data at ASA level (request type and SuB-AuA
		 *                code).
		 * @return result which come from Authenticator class in 'isAuthenticated' true
		 *         or false. If the value is false its terminated to queue and revert
		 *         response with error code.
		 */

		// ******************** 2. Authenticate *******************************
		request.RequestReceived = DateTimeUtil.getCurrentDateSQLFormat();
		request.IpAddress = httpRequest.getRemoteAddr();
		request.requestTo = RequestTo.ASA;
		errorResponse.txn = request.txn;
		AuthenticationResult authResult = Authenticator.isAuthenticated(request);
		if (!authResult.isAuthenticated) {
			errorResponse.err = authResult.ErrorCode;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveAsaAsync(request, errorResponse);
			return XMLBuilder.buildASARespForError(errorResponse, request.reqType);
		}
		// ********************************************************************

		/**
		 * <h1>3. Validate</h1>
		 * 
		 * @param request object of Request2_5 class which pass in Validator class for
		 *                validating all request filed at ASA level.
		 * 
		 * @return validationError bring null value if all data validating successfully
		 *         else it is bring error code and terminated to queue and revert
		 *         response with error code.
		 */

		// ******************** 3. Validate ***********************************
		String validationError = Validator.Validate(request);
		if (!validationError.equals("")) {
			errorResponse.err = validationError;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveAsaAsync(request, errorResponse);
			return XMLBuilder.buildASARespForError(errorResponse, request.reqType);
		}
		// ********************************************************************

		/**
		 * <h1>4. Send to CIDR and return Response</h1>
		 * 
		 * @param requestXML      Aadhaar Authentication Request XML or OTP Generating
		 *                        XML which is sent by AUA.
		 * @param request.uid     UIDAI Number
		 * 
		 * @param request.reqType Request XML's type like demo,bio,bfd,otp,otpAuth
		 * 
		 * @exception Exception It's a general Exception, It's return '3001' error and
		 *                      throw exception massage in application logs.
		 * 
		 * @return Response XML from CIDR
		 */

		// ******************** 4. Send to CIDR and return Response ***********

		request.RequestSent = DateTimeUtil.getCurrentDateSQLFormat();
		String cidrResponse = null;
		try {
			cidrResponse = HttpClientUtil.postToCIDRAsync(requestXML, request.uid, request.reqType).join();
			request.ResponseReceived = DateTimeUtil.getCurrentDateSQLFormat();
			Response2_5 response = ParseUtil.parseCIDRXML(cidrResponse);
			if (cidrResponse.contains("<html>") || cidrResponse.equals(null) || cidrResponse.equals("") || response == null) {
				errorResponse.err = AppConstants.ERROR3001;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				ApplicationLogger.logAsyncAsa("Transaction ID : "+request.txn+" CIDR NULL Rsponse XML : "+cidrResponse);
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveAsaAsync(request, errorResponse);
				return XMLBuilder.buildASARespForError(errorResponse, request.reqType);
			}
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveAsaAsync(request, response);
			return cidrResponse;
			
		} catch (Exception e) {
			errorResponse.err = AppConstants.ERROR3001;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			ApplicationLogger.logAsyncAsa("(Connection Break) Error receiving response from CIDR:", e);
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveAsaAsync(request, errorResponse);
			return XMLBuilder.buildASARespForError(errorResponse, request.reqType);
		}
		// ********************************************************************
	}
}
