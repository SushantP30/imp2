
package com.controllers;

import java.time.LocalTime;

import javax.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.utils.*;
import com.enums.RequestTo;
import com.models.*;
import org.springframework.web.bind.annotation.RestController;
import static java.time.temporal.ChronoUnit.MILLIS;

/**
 * Authentication User Agency (AUA) is an entity engaged in providing Aadhaar
 * Enabled Services to Aadhaar number Holder, using the authentication as
 * facilitated by the Authentication Service Agency (ASA).
 * <p>
 * Department of Science and Technology, Government of Gujarat registered as AUA
 * in India, that uses Aadhaar authentication services of UIDAI and sends
 * authentication requests to enable its services / business functions.
 * 
 * @author Harsh H. Barot
 * @author Jeetendra Mishra
 * @version 2.5.1, 24/08/2021
 * @since 2.5
 */

@SpringBootApplication
@RestController
@RequestMapping("/aua/rest")
public class AUAController {

	
	/**
	 * User can check with the concern parameter the Aadhaar authentication API 2.5
	 * is running or not.
	 * 
	 * @return Application status XML.
	 */
	@GetMapping(value = "/checkauastatus25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String checkAUAStatus() {
		return AppConstants.AAPSTATUSAUA;
	}

	/**
	 * Generate the OTP for Aadhaar Authentication via the this method. OTP should
	 * forward to concern's mail or mobile.
	 * 
	 * @param requestXML  OTP Generating requesting XML's which is requested by
	 *                    SuB-AUA's portal for generating OTP
	 * @param httpRequest Extends the {@link javax.servlet.ServletRequest} interface
	 *                    to provide request
	 * @return XML Response XML which received by ASA and OTP sent to citizen's mail
	 *         or mobile.
	 */
	@PostMapping(value = "/genOtp25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String acceptRequest25_OTP(@RequestBody String requestXML, HttpServletRequest httpRequest) {
		return processAndBuildResponse(requestXML, httpRequest);
	}

	/**
	 * @param requestXML  Aadhaar Authentications request XML,which is requested by
	 *                    SuB-AUA's portal for Aadhaar Authentication
	 * @param httpRequest Extends the {@link javax.servlet.ServletRequest} interface
	 *                    to provide request
	 * @return XML Response XML which received by ASA.
	 */
	@PostMapping(value = "/authreqv25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String acceptRequest25(@RequestBody String requestXML, HttpServletRequest httpRequest) {
		return processAndBuildResponse(requestXML, httpRequest);
	}

	/**
	 * @param requestXML  It's either Aadhaar Authentication request XML or OTP
	 *                    Generating requesting XML's which is requested by
	 *                    SUB-AuAs.
	 * @param httpRequest Extends the {@link javax.servlet.ServletRequest} interface
	 *                    to provide request
	 * @version 2.5.1, 24/08/2021
	 * @see 2.5
	 * @return XML Response XML.
	 */
	private  String processAndBuildResponse(String requestXML, HttpServletRequest httpRequest) {

		LocalTime refTime = LocalTime.now();
		print(System.lineSeparator() + "Entered AUA :", refTime);
		Statistics.addRequests_AUA();
		Response2_5 errorResponse = new Response2_5();
		errorResponse.ret = "n";
		errorResponse.actn = "NA";

		/**
		 * <h1>1.Parse the XML to Object</h1>
		 * 
		 * @param requestXML which received from SUB-AuAs.
		 * @return request object of Request2_5 class, If the XML's is null and Occurred
		 *         any kind of error from ParseUtil class itself return error (1001:XML
		 *         is not as per the GOG AUA-ASA XSD Standard).
		 */

		// ********************1. Parse the XML to Object *********************
		Request2_5 request = ParseUtil.parseAuaXML(requestXML);

		if (request == null) {
			errorResponse.err = AppConstants.ERROR1001;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			return XMLBuilder.buildAUAResp(errorResponse, "");
		}
		print("Parse Complete:", refTime);
		// ********************************************************************

		/**
		 * <h1>2. Authenticate</h1>
		 * 
		 * @param request Object of Request2_5 class which pass in Authenticator class
		 *                for validating data at AUA level (request type and SuB-AuA
		 *                code).
		 * @return result which come from Authenticator class in 'isAuthenticated' true
		 *         or false. If the value is false its terminated to queue and revert
		 *         response with error code.
		 */

		// ******************** 2. Authenticate *******************************
		request.RequestReceived = DateTimeUtil.getCurrentDateSQLFormat();
		request.IpAddress = httpRequest.getRemoteAddr();
		request.requestTo = RequestTo.AUA;
		errorResponse.txn_subAua = (request.txn_subAua == null || request.txn_subAua.equals(""))? "NA" : request.txn_subAua;
		AuthenticationResult result = Authenticator.isAuthenticated(request);
		if (!result.isAuthenticated) {
			errorResponse.err = result.ErrorCode;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveAuaAsync(request, errorResponse);
			return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
		}
		print("Authentication Complete:", refTime);
		// ********************************************************************

		/**
		 * <h1>3. Validate</h1>
		 * 
		 * @param request object of Request2_5 class which pass in Validator class for
		 *                validating all request filed at AuA level.
		 * @return validationError bring null value if all data validating successfully
		 *         else it is bring error code and terminated to queue and revert
		 *         response with error code.
		 */

		// ******************** 3. Validate ***********************************
		String validationError = Validator.Validate(request);
		if (!validationError.equals("")) {
			errorResponse.err = validationError;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveAuaAsync(request, errorResponse);
			return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
		}
		print("Validation Complete:", refTime);
		// ********************************************************************

		/**
		 * <h1>4. Set Request parameter at AuA level i.e tid value, AuA code, AuA
		 * transaction ID and HSM Status</h1>
		 */

		// ******************** 4. Set Request parameter at AuA level *********
		switch (request.reqType) {
		case "bio":
		case "bfd":
			request.tid = PropertiesUtil.getTerminalId();
			break;
		case "demo":
			request.tid = PropertiesUtil.getTerminalIdDemo();
			break;
		case "otpAuth":
			request.tid = PropertiesUtil.getTerminalIdOtpAuth();
			break;
		default:
			break;
		}
		request.lk = PropertiesUtil.getAuaLicenseKey();
		request.ac = PropertiesUtil.getAauaCode();
		request.hsm = (byte) (PropertiesUtil.getHSMvalue().equals("on") ? 1 : 0);
		// ********************************************************************

		/**
		 * <h1>5 Generate Transaction ID at AuA level</h1>
		 * 
		 * @param uid     This can be Aadhaar Number (wherever Aadhaar number is used,
		 *                in future, an encrypted Aadhaar number may also be used) or
		 *                Virtual ID or agency specific UID token of the person being
		 *                authenticated.
		 * @param reqType SUB-AUA specific request identifier. AUA can forward the
		 *                request to UIDAI as per received the request type. i.e
		 *                demo,bio,otp,otpAuth,BFD
		 * @return txn Unique transaction No at AUA level which communicate between AUA
		 *         and CIDR
		 */
		// ******************** 5. Generate Transaction ID at AuA level *******
		request.txn = TransactionNoUtil.generateTxnNo(request.uid, request.reqType);
		// ********************************************************************

		/**
		 * <h1>6 Generate a request XML at AuA level</h1>
		 * 
		 * @param request object of Request2_5 class which pass in XMLBuilder class for
		 *                generate request XML at AuA level.
		 * @return xml is AuA level request XML i.e Authentication (Bio,Demo and OTP)
		 *         Request XML and OTP Generation request XML if any issue occurred
		 *         XML's build time its self pass null value.
		 */
		// ******************** 6. Generate a request XML at AuA level ********
		String xml = XMLBuilder.buildASARequest(request);
		print("Auth XML genratation :", refTime);
		// ********************************************************************
		/**
		 * <h1>7. Sign Request XML</h1>
		 * 
		 * @param xml         UIDAI's Standard Authentication XML.
		 * 
		 * @param request.hsm hsm's value which retrieve from uidai.properties file and
		 *                    the value is in on and off.
		 * 
		 * @param request.txn AUA's Authentication transaction ID.
		 * 
		 * @return signedXML Signed XML either via HSM or JAVA Code.
		 */
		// ******************** 7. Sign Request XML ***************************

		String signedXML = SignatureUtil.signXML(xml, request.hsm, request.txn);
		if (signedXML.equals("")) {
			if (request.hsm == 1) {
				errorResponse.err = AppConstants.ERROR1021;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveAuaAsync(request, errorResponse);
				return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
			} else {
				errorResponse.err = AppConstants.ERROR1022;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveAuaAsync(request, errorResponse);
				return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
			}

		}

		print("Sign XML Complete, Sending to ASA :", refTime);
		// ********************************************************************

		/**
		 * <h1>8. Send to ASA</h1>
		 * 
		 * @param signedXML    is Signed Authentication Request XML by UIDAI's public
		 *                     key.
		 * 
		 * @param request.type Request type is demonstrate i.e Generate OTP or
		 *                     Authentication XML
		 * 
		 * @exception Exception It's a general Exception, It's return '3002' error and
		 *                      throw exception massage in application logs.
		 * 
		 * @return strAsaResponse Authentication repose from ASA.
		 */     

		// ******************** 8. Send to ASA ********************************
		String strAsaResponse = null;
		request.RequestSent = DateTimeUtil.getCurrentDateSQLFormat();
		try {
			strAsaResponse = HttpClientUtil.postToAsaAsync(signedXML, request.reqType).join();
			request.ResponseReceived = DateTimeUtil.getCurrentDateSQLFormat();
			print("Response Received from ASA :", refTime);

		} catch (Exception e) {
			errorResponse.err = AppConstants.ERROR3002;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			ApplicationLogger.logAsyncAua("(Connection Break) Error receiving response from AUA side:", e);
			AuditUtil.saveAuaAsync(request, errorResponse);
			return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
		}
		// ********************************************************************

		/**
		 * <h1>8. Parse Response</h1>
		 * 
		 * @param strAsaResponse Response XML, If the XML's is null and Occurred any
		 *                       kind of error from ParseUtil class itself return error
		 *                       (3002:CIDR Service is not available at AUA Level).
		 * @return response2_5 object of Response2_5 class, if the return value is null
		 *         or any exception accord at run time request is parse
		 */

		// ******************** 8.parse response ******************************
		Response2_5 response2_5 = ParseUtil.parseCIDRXML(strAsaResponse);
		if (response2_5 == null) {
			errorResponse.err = AppConstants.ERROR3002;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			ApplicationLogger.logAsyncAua("Parsing Error CIDR Rsponse XML : "+strAsaResponse);
			AuditUtil.saveAuaAsync(request, errorResponse);
			return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
		}
		// ********************************************************************

		/**
		 * <h1>9. Verify Signature</h1>
		 * 
		 * @param strAsaResponse Authentication Response XML.
		 * 
		 * @return SignatureUtil.isVerified value is true if Response XML is verified
		 *         from public key or the value is false.
		 */

		// ******************** 9.Verify Signature ****************************

		// if signature is present then response if from CIDR, verify the signature

		if (!request.reqType.equals("otp")) {
			if (response2_5.isSignaturePresent && !SignatureUtil.isVerified(strAsaResponse)) {
				errorResponse.err = "Signature Verification Failed";
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveAuaAsync(request, errorResponse);
				return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
			}
			// if signature is absent, it should be response from ASA and ret cannot be "y"
			if (!response2_5.isSignaturePresent && response2_5.ret.equals("y")) {
				errorResponse.err = "Signature Verification Failed";
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveAuaAsync(request, errorResponse);
				return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
			}
			// if signature is absent and ret ="n". get the ASA error and return
			if (!response2_5.isSignaturePresent && response2_5.ret.equals("n")) {
				errorResponse.err = response2_5.err;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveAuaAsync(request, errorResponse);
				return XMLBuilder.buildAUAResp(errorResponse, request.reqType);
			}
		}

		print("Signature Verified:", refTime);

		// ********************************************************************

		/**
		 * <h1>10. Return Response to SUB-AuAs</h1>
		 * 
		 * @param response2_5     object of Response2_5 class where stored to all
		 *                        response entities.
		 * 
		 * @param request.reqType Request type is demonstrate i.e Generate OTP or
		 *                        Authentication XML
		 * 
		 * @return Authentication Response XML.
		 */

		// ******************** 10. Return Response to SUB-AuAs ***************
		print("Response Returned:", refTime);
		response2_5.txn_subAua = request.txn_subAua;
		request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
		AuditUtil.saveAuaAsync(request, response2_5);
		return XMLBuilder.buildAUAResp(response2_5, request.reqType);
		// ********************************************************************
	}

	private void print(String message, LocalTime refTime) {
		System.out.println(message + (refTime.until(LocalTime.now(), MILLIS)));
	}
}
