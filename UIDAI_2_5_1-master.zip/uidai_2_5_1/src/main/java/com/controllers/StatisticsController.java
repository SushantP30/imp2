/**
 * 
 */
package com.controllers;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.models.Statistics;;

/**
 * StatisticsController class shown total transaction count which is done by AUA
 * and ASA
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 04/09/2021
 * @since 2.5
 */
@SpringBootApplication
@RestController
public class StatisticsController {

	/**
	 * @return Total transaction Count which is done by AUA and ASA
	 */
	@GetMapping(value = "/stats")
	public String getStatistics() {
		return "<html><head><title>Statistics of the Server</title></head><body><pre>" + Statistics.getStats()
				+ "</pre></body></html>";
	}
}
