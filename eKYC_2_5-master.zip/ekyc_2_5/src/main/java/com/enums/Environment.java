/**
 * 
 */
package com.enums;

/**
 * @author yash
 *
 */
public enum Environment {
	Staging, Production;

}
