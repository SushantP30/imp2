/**
 * 
 */
package com.enums;

/**
 * @author Harsh
 *
 */
public enum RequestTo {
	KUA, KSA;
	public String value() {
		return name();
	}

	public static RequestTo fromValue(String v) {
		return valueOf(v);
	}
}
