/**
 * 
 */
package com.enums;

/**
 * @author yash
 *
 */
public enum FingerPosition {
	LEFT_INDEX, LEFT_LITTLE, LEFT_MIDDLE, LEFT_RING, LEFT_THUMB, RIGHT_INDEX, RIGHT_LITTLE, RIGHT_MIDDLE, RIGHT_RING,
	RIGHT_THUMB, UNKNOWN;

	public String value() {
		return name();
	}

	public static FingerPosition fromValue(String v) {
		return valueOf(v);
	}
}
