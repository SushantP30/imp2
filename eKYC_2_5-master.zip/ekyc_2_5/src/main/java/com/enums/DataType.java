/**
 * 
 */
package com.enums;


/**
 * @author Adit
 *
 */

	public enum DataType {
		X,P;

		public String value() {
			return name();
		}

		public static DataType fromValue(String v) {
			return valueOf(v);
		}
	}
