
package com.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.models.*;
import com.enums.*;

/**
 * @author harsh
 *
 */
public class Validator {
	public static String Validate(Request2_5 request) {
		if (request.requestTo == RequestTo.KUA) {

			// following validations applicable to only SubAUA Request XML
			if (request.txn_subAua == null || request.txn_subAua.equals("")) {
				request.txn_subAua = "NA";
				return AppConstants.ERROR1010;

			}
			if (request.txn_subAua.length() > 50) {
				return AppConstants.ERROR1011;
			}
			if (request.ts == null || request.ts.trim().equals("")) {
				return AppConstants.ERROR1012;
			}
			if (request.uid == null || request.uid.trim().equals("")) {

				return AppConstants.ERROR1013;
			}
			if (!(request.type.equals("A") || request.type.equals("V") || request.type.equals("T")
					|| request.type.equals("E"))) {
				return AppConstants.ERROR1015;
			}
			
			if (!isValidUID(request.uid, request.type)) {
				return AppConstants.ERROR1014;
			}

			if (request.ra == null || request.ra.equals("")) {
				return AppConstants.ERROR1016;

			}

			if (!(request.ra.equals("F") || request.ra.equals("I") || request.ra.equals("O") || request.ra.equals("P")
					|| request.ra.equals("OP"))) {
				return AppConstants.ERROR1016;
			}

			if (request.rc == null || request.rc.trim().equals("")) {
				return AppConstants.ERROR1017;
			}
			if (!request.rc.equalsIgnoreCase("Y")) {
				return AppConstants.ERROR1017;
			}

			// info
			if (request.info == null) {
				return AppConstants.ERROR1020;
			}
			if (request.info.rdsrno.equals("")) {
				return AppConstants.ERROR1021;
			}
			if (request.info.appCode.equals("")) {
				return AppConstants.ERROR1022;
			}
			if (request.info.scheamCode.equals("")) {
				return AppConstants.ERROR1023;
			}
			
			if(request.pfr == null ) {
				return AppConstants.ERROR1024;
			}
			if(!(request.pfr.equals("Y") || request.pfr.equals("N"))) {
				return AppConstants.ERROR1024;
			}

			if (request.reqType.equals("bio")) {
				// uses for bio
				if (!request.uses.pi.equals("n")) {
					return AppConstants.ERROR1030;
				}

				if (!request.uses.pa.equals("n")) {
					return AppConstants.ERROR1031;
				}

				if (!request.uses.pfa.equals("n")) {
					return AppConstants.ERROR1032;
				}

				if (!request.uses.bio.equals("y")) {
					return AppConstants.ERROR1033;
				}

				if (request.uses.bt.equals("")) {
					return AppConstants.ERROR1034;
				}

				if (!(request.uses.bt.equals("FMR") || request.uses.bt.equals("FIR") || request.uses.bt.equals("IIR")
						|| request.uses.bt.equals("FID") || request.uses.bt.equals("FMR,FIR"))) {
					return AppConstants.ERROR1035;
				}

				if (!request.uses.pin.equals("n")) {
					return AppConstants.ERROR1036;
				}

				if (!request.uses.otp.equals("n")) {
					return AppConstants.ERROR1037;
				}
				// meta for bio
				if (request.meta.dpId.equals("")) {
					return AppConstants.ERROR1041;
				}
				if (request.meta.rdsId.equals("")) {
					return AppConstants.ERROR1042;
				}
				if (request.meta.rdsVer.equals("")) {
					return AppConstants.ERROR1043;
				}
				if (request.meta.dc.equals("")) {
					return AppConstants.ERROR1044;
				}
				if (request.meta.mi.equals("")) {
					return AppConstants.ERROR1045;
				}
				if (request.meta.mc.equals("")) {
					return AppConstants.ERROR1046;
				}

			}
			if (request.reqType.equals("otp")) {
				// uses
				if (!request.uses.pi.equals("n")) {
					return AppConstants.ERROR1030;
				}

				if (!request.uses.pa.equals("n")) {
					return AppConstants.ERROR1031;
				}

				if (!request.uses.pfa.equals("n")) {
					return AppConstants.ERROR1032;
				}

				if (!request.uses.bio.equals("n")) {
					return AppConstants.ERROR1033;
				}

				if (!request.uses.bt.equals("")) {
					return AppConstants.ERROR1039;
				}

				if (!request.uses.pin.equals("n")) {
					return AppConstants.ERROR1036;
				}
				if (!request.uses.otp.equals("y")) {
					return AppConstants.ERROR1037;
				}

				// meta for otp
				if (!request.meta.dpId.equals("")) {
					return AppConstants.ERROR1050;
				}
				if (!request.meta.rdsId.equals("")) {
					return AppConstants.ERROR1051;
				}
				if (!request.meta.rdsVer.equals("")) {
					return AppConstants.ERROR1052;
				}
				if (!request.meta.dc.equals("")) {
					return AppConstants.ERROR1053;
				}
				if (!request.meta.mi.equals("")) {
					return AppConstants.ERROR1054;
				}
				if (!request.meta.mc.equals("")) {
					return AppConstants.ERROR1055;
				}

			}

			// PIDs Validations
			if (request.skey == null) {
				return AppConstants.ERROR1060;
			}
			if (request.skey.ci.equals("")) {
				return AppConstants.ERROR1061;
			}
			if (request.data == null) {
				return AppConstants.ERROR1062;
			}
			if (request.hmac == null) {
				return AppConstants.ERROR1063;
			}
		}
		if (request.requestTo == RequestTo.KSA) {

			if (request.uid == null || request.uid.trim().equals("")) {

				return AppConstants.ERROR1013;
			}

			if (request.ver == null || request.ver.trim().equals("")) {
				return AppConstants.ERROR2001;
			}

			if (!request.ver.equals(PropertiesUtil.getApiVersion())) {
				return AppConstants.ERROR2002;
			}

			if (request.rad == null || request.rad.trim().equals("")) {
				return AppConstants.ERROR2003;
			}

			if (request.ac == null || request.ac.trim().equals("")) {
				return AppConstants.ERROR2004;
			}

		}

		return "";
	}

	private static boolean isValidUID(String strUID, String type) {
		if (strUID == null || strUID.trim().equals("")) {
			return false;
		}
		String pattern = "\\d+";
		Pattern replace = Pattern.compile(pattern);
		Matcher m = replace.matcher(strUID);
		switch (type) {
		case "A":
			if (strUID.length() != 12) {
				return false;
			}

			if (!m.matches()) {
				return false;
			}
			return true;
		case "V":
			if (strUID.length() != 16) {
				return false;
			}

			if (!m.matches()) {
				return false;
			}
			return true;
		case "T":
			if (strUID.length() != 72) {
				return false;
			}
			return true;
		default:
			return false;
		}
	}
}
