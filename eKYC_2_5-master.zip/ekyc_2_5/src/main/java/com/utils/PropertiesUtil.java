/**
 * 
 */
package com.utils;

import java.util.Base64;
import java.util.ResourceBundle;
import com.enums.Environment;

/**
 * @author harsh
 *
 */
public class PropertiesUtil {
	private static ResourceBundle messageBundle = ResourceBundle.getBundle("uidai");
	private static ResourceBundle messageBundle_env = ResourceBundle.getBundle("environment");

	private static String getDecodedValue(String key) {
		return new String(Base64.getDecoder().decode(messageBundle.getString(key).trim().getBytes()));
	}

	private static String getValue(String key) {
		return messageBundle.getString(key).trim();
	}

	private static Environment getEnvironment() {
		if (messageBundle_env.getString("environment").trim().equals("staging")) {
			return Environment.Staging;
		} else if (messageBundle_env.getString("environment").trim().equals("production")) {
			return Environment.Production;
		} else {
			return null;
		}
	}

	public static String getApiVersion() {
		return getValue("apiversion");
	}


	public static String getKsaLicenseKey() {
		if (getEnvironment() == Environment.Production) {
			return getDecodedValue("ksaLicenseKeyProduction");
		} else {
			return getDecodedValue("ksaLicenseKeyStaging");
		}
	}

	public static String getKuaLicenseKey() {
		if (getEnvironment() == Environment.Production) {
			return getDecodedValue("kuaLicenseKeyProduction");
		} else {
			return getDecodedValue("kuaLicenseKeyStaging");
		}
	}

	public static String getAauaCode() {
		if (getEnvironment() == Environment.Production) {
			return getValue("auaCodeProduction");
		} else {
			return getValue("auaCodeStaging");
		}
	}

	public static String getCidrAuthUrl() {
		if (getEnvironment() == Environment.Production) {
			return getValue("cidrAuthUrlProduction");
		} else {
			return getValue("cidrAuthUrlStaging");
		}
	}

	public static String getCidrOtpUrl() {
		if (getEnvironment() == Environment.Production) {
			return getValue("cidrOtpUrlProduction");
		} else {
			return getValue("cidrOtpUrlStaging");
		}
	}
	public static String getAuaConnectionParams() {
		if (getEnvironment() == Environment.Production) {
			return getValue("auaConnectionParamsProduction");
		} else {
			return getValue("auaConnectionParamsStaging");
		}
	}
	public static String getAsaConnectionParams() {
		if (getEnvironment() == Environment.Production) {
			return getValue("asaConnectionParamsProduction");
		} else {
			return getValue("asaConnectionParamsStaging");
		}
	}
	public static String getTerminalId() {
		return getValue("terminalId");
	}

	public static String getTerminalIdOtpAuth() {
		return getValue("terminalIdOtpAuth");
	}

	public static String getKsaAuthServerUrl() {
		return getValue("ksaAuthServerUrl");
	}
	
	public static String getAsaOTPServerUrl() {
		return getValue("asaOTPServerUrl");
	}
	
	public static String getHSMUrl() {
		return getValue("hsmServer");
	}

}
