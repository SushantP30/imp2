/**
 * 
 */
package com.utils;

import com.models.AuthenticationResult;
import com.models.Request2_5;

/**
 * @author harsh
 *
 */

public class Authenticator {
	private static final String FCS = "PFCDG18028";
//	private static final String FCS = "SFCDG18028";
	private static final String DST = "0000970000";

	public static AuthenticationResult isAuthenticated(Request2_5 request) {
		AuthenticationResult result = new AuthenticationResult();
		result.isAuthenticated = true;
		result.ErrorCode = "";
		
		switch (request.requestTo) {
		case KUA:
			if (request.sa == null || request.sa.equals("")) {
				result.isAuthenticated = false;
				result.ErrorCode = AppConstants.ERROR1002;
				request.reqType = (request.reqType == null) ? "NA" : request.reqType;
				break;
			}
			else if(request.reqType == null || request.reqType.equals(""))
			{
				result.isAuthenticated = false;
				result.ErrorCode = AppConstants.ERROR1004;
				request.reqType = (request.reqType == null) ? "NA" : request.reqType;
				break;
			}
			switch (request.reqType) {
			case "bio": {
				if (!(request.sa.equals(FCS) || request.sa.equals(DST) )) {
					result.isAuthenticated = false;
					result.ErrorCode = AppConstants.ERROR1002;
				}
				break;
			}
			case "otp": {
				if (!(request.sa.equals(FCS) || request.sa.equals(DST) )) {
					result.isAuthenticated = false;
					result.ErrorCode = AppConstants.ERROR1002;
				}
				break;
			}
			default:
				result.isAuthenticated = false;
				result.ErrorCode = AppConstants.ERROR1004;
				break;
			}
		default:
			break;
	
		}
		return result;
	}
}
