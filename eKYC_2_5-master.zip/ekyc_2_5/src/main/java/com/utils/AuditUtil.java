/**
 * 
 */
package com.utils;

import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.models.Request2_5;
import com.models.Response2_5;

/**
 * @author yash
 *
 */
public class AuditUtil {
	
	static SQLServerDataSource dsAua = new SQLServerDataSource();
	static SQLServerDataSource dsAsa = new SQLServerDataSource();
	static {
		String[] params = PropertiesUtil.getAuaConnectionParams().split(":");
		dsAua.setServerName(params[0]);
		dsAua.setPortNumber(Integer.parseInt(params[1]));
		dsAua.setUser(params[2]);
		dsAua.setPassword(params[3]);
		dsAua.setDatabaseName(params[4]);

		params = PropertiesUtil.getAsaConnectionParams().split(":");
		dsAsa.setServerName(params[0]);
		dsAsa.setPortNumber(Integer.parseInt(params[1]));
		dsAsa.setUser(params[2]);
		dsAsa.setPassword(params[3]);
		dsAsa.setDatabaseName(params[4]);
	}

	public static void saveKuaAsync(Request2_5 request, Response2_5 response) {

		new Thread(() -> {
			try (Connection con = dsAua.getConnection();
					PreparedStatement sp = con.prepareStatement(
							"{call dbo.usp_insert_authentication25_v1(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");) {
				sp.setString(1, request.txn_subAua);
				sp.setString(2, request.txn);
				sp.setString(3, request.reqType);
				sp.setString(4, request.sa);
				sp.setString(5, request.ra);
				sp.setString(6, request.rc);
				sp.setString(7, request.lr);
				sp.setString(8, request.de);
				sp.setString(9, request.pfr);
				sp.setString(10, request.type);
				sp.setString(11, request.tid);
				sp.setString(12, request.meta.dpId);
				sp.setString(13, request.meta.rdsId);
				sp.setString(14, request.meta.dc);
				sp.setString(15, request.meta.mi);
				sp.setString(16, request.meta.mc);
				sp.setString(17, request.uses.bt); //FMR+FIR
				sp.setString(18, request.ts);
				sp.setString(19, request.RequestReceived);
				sp.setString(20, request.RequestSent);
				sp.setString(21, request.ResponseReceived);
				sp.setString(22, request.ResponseSent);
				sp.setString(23, response.status);
				sp.setString(24, response.Ko);
				sp.setString(25, response.ret);
				sp.setString(26, response.err.length()>6?response.err.substring(0, 4):response.err);
				sp.setString(27, response.authErr); //Aadhaar error
				sp.setString(28, response.code);
				sp.setString(29, response.ts);
				sp.setString(30, response.uidToken);
				sp.setString(31, request.info.rdsrno);
				sp.setString(32, request.info.appCode);
				sp.setString(33, request.info.scheamCode);
				sp.setString(34, request.IpAddress);
				try {
					sp.setString(35, InetAddress.getLocalHost().getHostAddress());
				} catch (Exception e) {
					sp.setString(34, "");
				}
				int insertSuccess = sp.executeUpdate();
				if (insertSuccess > 0) {
					ApplicationLogger.logAsyncDbFail("------****AUA Request XML**** ------");
					ApplicationLogger.logAsyncDbFail("SUB-AUA Txn: " + request.txn + "\n SUB-AUA Code: " + request.sa
							+ "\n Type: " + request.type + "\n ts: " + request.ts + "\n RC: " + request.rc
							+ "\n Uses ==> pin: " + request.uses.pi + " pa: " + request.uses.pa + " pfa: "
							+ request.uses.pfa + " bt: " + request.uses.bt + " bio: " + request.uses.bio + " pin: "
							+ request.uses.pin + " otp: " + request.uses.otp + "\n Meta ==>rdsId: " + request.meta.rdsId
							+ "RdsVer: " + request.meta.rdsVer + "dpId: " + request.meta.dpId + "dc: " + request.meta.dc
							+ "mi: " + request.meta.mi + "Mc: " + request.meta.mc + "\n Info: " + request.info);
					ApplicationLogger.logAsyncDbFail("------****AUA Response XML**** ------");
					ApplicationLogger.logAsyncDbFail("SUB-AUA Txn: " + request.txn + "\n UIDI Tokens: "
							+ response.uidToken + "\n CIDR Response: " + response.ret + "\n actn: " + response.actn
							+ "\n Response Ts: " + response.ts + "\n error code: " + response.err + "\n cidr code: "
							+ response.code);
				}

			} catch (Exception e) {
				ApplicationLogger.logAsyncKua("Error inserting records to database from AUA:", e);

			}

		}).start();
	}

	public static void saveKsaAsync(Request2_5 request, Response2_5 response) {
		new Thread(() -> {
			try (Connection con = dsAsa.getConnection();
					PreparedStatement sp = con
							.prepareStatement("{ call dbo.usp_insert_authentication(?,?,?,?,?,?,?,?,?,?,?) }");) {
				sp.setString(1, request.txn);
				sp.setString(2, request.ac);
				sp.setString(3, request.RequestSent);
				sp.setString(4, request.ResponseReceived);
				sp.setString(5, response.ret);
				sp.setString(6, response.code);
				sp.setString(7, response.err.length()>6?response.err.substring(0, 4):response.err);
				sp.setString(8, response.ts);
				sp.setString(9, request.RequestReceived);
				sp.setString(10, request.ResponseSent);
				sp.setString(11, request.IpAddress);
				int insertSuccess = sp.executeUpdate();
				if (insertSuccess > 0) {
					ApplicationLogger.logAsyncDbFail("------****ASA Request XML**** ------");
					ApplicationLogger.logAsyncDbFail("SUB-AUA Txn: " + request.txn + "\n SUB-AUA Code: " + request.sa
							+ "\n Type: " + request.type + "\n ts: " + request.ts + "\n RC: " + request.rc
							+ "\n Uses ==> pin: " + request.uses.pi + " pa: " + request.uses.pa + " pfa: "
							+ request.uses.pfa + " bt: " + request.uses.bt + " bio: " + request.uses.bio + " pin: "
							+ request.uses.pin + " otp: " + request.uses.otp + "\n Meta ==>rdsId: " + request.meta.rdsId
							+ "RdsVer: " + request.meta.rdsVer + "dpId: " + request.meta.dpId + "dc: " + request.meta.dc
							+ "mi: " + request.meta.mi + "Mc: " + request.meta.mc + "\n Info: " + request.info);
					ApplicationLogger.logAsyncDbFail("------****ASA Response XML**** ------");
					ApplicationLogger.logAsyncDbFail("SUB-AUA Txn: " + request.txn + "\n UIDI Tokens: "
							+ response.uidToken + "\n CIDR Response: " + response.ret + "\n actn: " + response.actn
							+ "\n Response Ts: " + response.ts + "\n error code: " + response.err + "\n cidr code: "
							+ response.code);
				}

			} catch (Exception e) {
				ApplicationLogger.logAsyncKsa("Error inserting records to database from ASA:", e);
			}
		}).start();
	}

}
