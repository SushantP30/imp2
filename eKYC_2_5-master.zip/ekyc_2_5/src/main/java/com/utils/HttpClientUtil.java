/**
 * 
 */
package com.utils;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.client.RestTemplate;

import com.models.DataDecryptorRequest;
import com.models.DataDecryptorResponse;
/**
 * @author harsh
 *
 */
public class HttpClientUtil {
	private static String CIDR_URL;
	//private static String HSM_DECRYPTOR_URL = "http://172.16.29.40:8012/ekycmiddleware/dataDecryptor/decryptEkycResp";
	private static String HSM_DECRYPTOR_URL;
	
	static {
		try {
			HSM_DECRYPTOR_URL = PropertiesUtil.getHSMUrl();
		}
		catch (Exception e) {
			ApplicationLogger.logAsyncKua("Fatal Error generating HSM URL", e);
		}
		try {
			CIDR_URL = PropertiesUtil.getCidrAuthUrl() + "/kyc/" + PropertiesUtil.getApiVersion() + "/"
					+ PropertiesUtil.getAauaCode() + "/%1$s/%2$s/"
					+ URLEncoder.encode(PropertiesUtil.getKsaLicenseKey(), "UTF-8");
		} catch (Exception e) {
			ApplicationLogger.logAsyncKsa("Fatal Error generating CIDR URL", e);
		}
	}

	@Async
	public static CompletableFuture<String> postToKsaAsync(String signedXML, String uid, String txn, String ac) {

		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(PropertiesUtil.getKsaAuthServerUrl() + "/" + uid + "/" + txn + "/" + ac))
				.timeout(AppConstants.TIMEOUT).header("Content-Type", "application/xml")
				.POST(BodyPublishers.ofString(signedXML)).build();
		HttpClient client = HttpClient.newHttpClient();
		return client.sendAsync(request, BodyHandlers.ofString()).thenApply(HttpResponse::body);
	}

	/**
	 * Sends Request to CIDR Asynchronously.
	 * 
	 * @param signedXML
	 * @param uid
	 * @return
	 */
	@Async
	public static CompletableFuture<String> postToCIDRAsync(String signedXML, String uid) {
		char ch1 = uid.charAt(0);
		char ch2 = uid.charAt(1);
		if (uid == null || uid.isEmpty() || uid.length() != 12) {
			ch1 = '0';
			ch2 = '0';
		} else {
			ch1 = uid.charAt(0);
			ch2 = uid.charAt(1);
		}
		//System.out.println("value of ch1:" + ch1 + " value of ch2:" + ch2);

		HttpRequest request = HttpRequest.newBuilder().uri(URI.create(String.format(CIDR_URL, ch1, ch2)))
				.timeout(AppConstants.TIMEOUT).header("Content-Type", "application/xml")
				.POST(BodyPublishers.ofString(signedXML)).build();
		HttpClient client = HttpClient.newHttpClient();
		return client.sendAsync(request, BodyHandlers.ofString()).thenApply(HttpResponse::body);

	}

	/**
	 * Sends Request for Singing XML in HSM.
	 * 
	 * @param SignHSM
	 * @return
	 */

	@Async
	public static DataDecryptorResponse postToDecryptResponse(DataDecryptorRequest decryptorrequest) {
		RestTemplate resttem = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<DataDecryptorRequest> entity = new HttpEntity<>(decryptorrequest, headers);
		return resttem.exchange(HSM_DECRYPTOR_URL, HttpMethod.POST, entity, DataDecryptorResponse.class).getBody();

	}

}
