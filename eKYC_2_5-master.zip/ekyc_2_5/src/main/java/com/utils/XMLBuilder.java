/**
 * 
 */
package com.utils;

import java.io.StringWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import com.models.Request2_5;
import com.models.Response2_5;

/**
 * @author harsh
 *
 */
public class XMLBuilder {

	public static String buildKUAResp(Response2_5 response) {

		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();

			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("KycRes");
			xMLStreamWriter.writeAttribute("ret", response.ret);
			xMLStreamWriter.writeAttribute("ResponseCode", response.code);
			xMLStreamWriter.writeAttribute("SubAUAtransId", response.txn_subAua);
			xMLStreamWriter.writeAttribute("ttl", response.ttl);
			xMLStreamWriter.writeAttribute("ResponseTs", response.ts);
			xMLStreamWriter.writeAttribute("error", response.err);
			xMLStreamWriter.writeAttribute("AuthError", response.authErr);

			if ((response.err.equals("NA"))) {
				xMLStreamWriter.writeStartElement("UidData");
				xMLStreamWriter.writeAttribute("txn", response.uidtxn);
				xMLStreamWriter.writeEndElement(); // End UidData

				xMLStreamWriter.writeStartElement("Poi");
				xMLStreamWriter.writeAttribute("name", response.Poi.name);
				xMLStreamWriter.writeAttribute("dob", response.Poi.dob);
				xMLStreamWriter.writeAttribute("gender", response.Poi.gender);
				xMLStreamWriter.writeEndElement(); // End Poi

				xMLStreamWriter.writeStartElement("Poa");
				xMLStreamWriter.writeAttribute("co", response.Poa.co);
				xMLStreamWriter.writeAttribute("country", response.Poa.country);
				xMLStreamWriter.writeAttribute("state", response.Poa.state);
				xMLStreamWriter.writeAttribute("dist", response.Poa.dist);
				xMLStreamWriter.writeAttribute("vtc", response.Poa.vtc);
				xMLStreamWriter.writeAttribute("loc", response.Poa.loc);
				xMLStreamWriter.writeAttribute("lm", response.Poa.lm);
				xMLStreamWriter.writeAttribute("street", response.Poa.street);
				xMLStreamWriter.writeAttribute("house", response.Poa.house);
				xMLStreamWriter.writeEndElement(); // End Poa

//				xMLStreamWriter.writeStartElement("LData");
//				xMLStreamWriter.writeAttribute("lang", dataDecoding(response.LData.lang));
//				xMLStreamWriter.writeAttribute("name", dataDecoding(response.LData.name));
//				xMLStreamWriter.writeAttribute("co", dataDecoding(response.LData.co));
//				xMLStreamWriter.writeAttribute("country", dataDecoding(response.LData.country));
//				xMLStreamWriter.writeAttribute("state", dataDecoding(response.LData.state));
//				xMLStreamWriter.writeAttribute("dist", dataDecoding(response.LData.dist));
//				xMLStreamWriter.writeAttribute("vtc", dataDecoding(response.LData.vtc));
//				xMLStreamWriter.writeAttribute("loc", dataDecoding(response.LData.loc));
//				xMLStreamWriter.writeAttribute("lm", dataDecoding(response.LData.lm));
//				xMLStreamWriter.writeAttribute("street", dataDecoding(response.LData.street));
//				xMLStreamWriter.writeAttribute("house", dataDecoding(response.LData.house));
//				xMLStreamWriter.writeEndElement(); // End LData

				xMLStreamWriter.writeStartElement("LData");
				xMLStreamWriter.writeAttribute("lang", response.LData.lang);
				xMLStreamWriter.writeAttribute("name", response.LData.name);
				xMLStreamWriter.writeAttribute("co", response.LData.co);
				xMLStreamWriter.writeAttribute("country", response.LData.country);
				xMLStreamWriter.writeAttribute("state", response.LData.state);
				xMLStreamWriter.writeAttribute("dist", response.LData.dist);
				xMLStreamWriter.writeAttribute("vtc", response.LData.vtc);
				xMLStreamWriter.writeAttribute("loc", response.LData.loc);
				xMLStreamWriter.writeAttribute("lm", response.LData.lm);
				xMLStreamWriter.writeAttribute("street", response.LData.street);
				xMLStreamWriter.writeAttribute("house", response.LData.house);
				xMLStreamWriter.writeEndElement(); // End LData

				xMLStreamWriter.writeStartElement("Pht");
				xMLStreamWriter.writeCharacters(response.Pht);
				xMLStreamWriter.writeEndElement(); // End Pht

				if (response.Doc != null) {
					xMLStreamWriter.writeStartElement("Prn");
					xMLStreamWriter.writeAttribute("type", response.Doc.type);
					xMLStreamWriter.writeCharacters(response.Doc.data);
					xMLStreamWriter.writeEndElement(); // End Prn
				}
			}
			xMLStreamWriter.writeEndElement();// End Kyc
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\" ?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncKua("Error building Response: Transaction ID:" + response.txn + ":", e);
			return null;
		}
	}

	public static String buildKSARespForError(Response2_5 response) {
		response.ret = "n";
		response.code = "";

		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("Resp");
			xMLStreamWriter.writeAttribute("ret", response.ret);
			xMLStreamWriter.writeAttribute("code", response.code);
			xMLStreamWriter.writeAttribute("txn", response.txn);
			xMLStreamWriter.writeAttribute("ttl", response.ttl);
			xMLStreamWriter.writeAttribute("ts", response.ts);
			xMLStreamWriter.writeAttribute("err", response.err);
			xMLStreamWriter.writeStartElement("KycRes");
			xMLStreamWriter.writeCharacters(response.KycRes);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeEndElement();// End AuthRes
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\" ?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncKsa("Error building Response:" + "Transaction ID:" + response.txn + ":", e);
			return null;
		}
	}

	public static String buildASARequest(Request2_5 request) {

		try {
			StringWriter stringWriter = new StringWriter();

			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("Auth");
			xMLStreamWriter.writeAttribute("ac", request.ac);
			xMLStreamWriter.writeAttribute("lk", request.lk);
			xMLStreamWriter.writeAttribute("rc", request.rc);
			xMLStreamWriter.writeAttribute("sa", request.sa);
			xMLStreamWriter.writeAttribute("tid", request.tid);
			xMLStreamWriter.writeAttribute("txn", request.txn);
			xMLStreamWriter.writeAttribute("uid", request.uid);
			xMLStreamWriter.writeAttribute("ver", request.ver);

			xMLStreamWriter.writeEmptyElement("Uses");
			xMLStreamWriter.writeAttribute("bio", request.uses.bio);
			xMLStreamWriter.writeAttribute("bt", request.uses.bt);
			xMLStreamWriter.writeAttribute("otp", request.uses.otp);
			xMLStreamWriter.writeAttribute("pa", request.uses.pa);
			xMLStreamWriter.writeAttribute("pfa", request.uses.pfa);
			xMLStreamWriter.writeAttribute("pi", request.uses.pi);
			xMLStreamWriter.writeAttribute("pin", request.uses.pin);

			xMLStreamWriter.writeEmptyElement("Meta");
			xMLStreamWriter.writeAttribute("dc", request.meta.dc);
			xMLStreamWriter.writeAttribute("dpId", request.meta.dpId);
			xMLStreamWriter.writeAttribute("mc", request.meta.mc);
			xMLStreamWriter.writeAttribute("mi", request.meta.mi);
			xMLStreamWriter.writeAttribute("rdsId", request.meta.rdsId);
			xMLStreamWriter.writeAttribute("rdsVer", request.meta.rdsVer);

			xMLStreamWriter.writeStartElement("Skey");
			xMLStreamWriter.writeAttribute("ci", request.skey.ci);
			xMLStreamWriter.writeCharacters(request.skey.Data);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("Hmac");
			xMLStreamWriter.writeCharacters(new String(request.hmac, "UTF-8"));
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeStartElement("Data");
			xMLStreamWriter.writeAttribute("type", request.data.type.toString());
			xMLStreamWriter.writeCharacters(request.data.data);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeEndElement();// End Auth
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncKsa("Error building ASA Request:" + "Transaction ID:" + request.txn_subAua + ":",
					e);
			return null;
		}
	}

	public static String bulideKYCRequestxml(Request2_5 request, String encodedXML) {
		try {
			StringWriter stringWriter = new StringWriter();
			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("Kyc");
			xMLStreamWriter.writeAttribute("ver", request.ver);
			xMLStreamWriter.writeAttribute("ra", request.ra);
			xMLStreamWriter.writeAttribute("rc", request.rc);
			xMLStreamWriter.writeAttribute("lr", request.lr);
			xMLStreamWriter.writeAttribute("de", AppConstants.de);
			xMLStreamWriter.writeAttribute("pfr", request.pfr);

			xMLStreamWriter.writeStartElement("Rad");
			xMLStreamWriter.writeCharacters(encodedXML);
			xMLStreamWriter.writeEndElement();

			xMLStreamWriter.writeEndElement();// End Auth
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
			return xmlString;
		} catch (Exception e) {
			ApplicationLogger.logAsyncKsa("Error building ASA Request:" + "Transaction ID:" + request.txn_subAua + ":",
					e);
			return null;
		}
	}

//	public static String dataDecoding(String data) {
//		String value;
//		try {
//			value = new String(data.getBytes("Windows-1252"), "UTF-8");
//			return value;
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//			return null;
//		}
//
//	}
}
