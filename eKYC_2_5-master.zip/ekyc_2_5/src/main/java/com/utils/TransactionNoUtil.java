/**
 * 
 */
package com.utils;

import java.time.LocalDateTime;
import java.util.Random;

import com.models.Request2_5;

/**
 * @author yash
 *
 */
public class TransactionNoUtil {
	/**
	 * generates unique transaction no format in For Bio/Demo/BFD-->
	 * AUACode:YYYYMMDD/hhMMss/(nanosecond)/(UID extract)/(3 digit random no) For
	 * OTP and OTP Auth-->(auacode):(sub AUA code):(transaction No of Sub AUA)
	 * 
	 * @param uid     UID no of transaction
	 * @param request current request being processed
	 * @return Unique transaction No
	 */

	public static String generateTxnNo(String uid, Request2_5 request) {
		Random rnd = new Random();
		LocalDateTime dt = LocalDateTime.now();
		if (request.reqType.equals("otp")) {

			return new StringBuilder().append("UKC:").append(PropertiesUtil.getAauaCode()).append(":").append(dt.getYear())
					.append(dt.getMonthValue()).append(dt.getDayOfMonth()).append(dt.getHour()).append(uid.charAt(0))
					.append(uid.charAt(2)).append(uid.charAt(4)).append(uid.charAt(6)).append(uid.charAt(8))
					.append(uid.charAt(10)).toString();
		} else {
			return new StringBuilder().append("UKC:").append(PropertiesUtil.getAauaCode()).append(":").append(dt.getYear())
					.append(dt.getMonthValue()).append(dt.getDayOfMonth()).append(dt.getHour())
					.append(dt.getMinute()).append(dt.getSecond())
					.append(Integer.toString(dt.getNano()).substring(0, 6)).append(uid.charAt(0))
					.append(uid.charAt(2)).append(uid.charAt(4)).append(uid.charAt(6)).append(uid.charAt(8))
					.append(uid.charAt(10)).append(rnd.nextInt(1000)).toString();
		}
	}

}
