/**
 * 
 */
package com.utils;

import java.time.Duration;

import javax.xml.namespace.QName;

/**
 * @author harsh
 *
 */
public interface AppConstants {
	public Duration TIMEOUT = Duration.ofSeconds(20);

	// attributes for ekyc

	public QName QNAME_VER = new QName("ver");
	public QName QNAME_RA = new QName("ra");
	public QName QNAME_RC = new QName("rc");
	public QName QNAME_LR = new QName("lr");
	public QName QNAME_DE = new QName("de");
	public QName QNAME_PFR = new QName("pfr");

	// attributes for node Auth
	public QName QNAME_AC = new QName("ac");
	public QName QNAME_LK = new QName("lk");
	public QName QNAME_SA = new QName("sa");
	public QName QNAME_TID = new QName("tid");
	public QName QNAME_TXN = new QName("txn");
	public QName QNAME_UID = new QName("uid");
	// attributes for node Uses
	public QName QNAME_PI = new QName("pi");
	public QName QNAME_PA = new QName("pa");
	public QName QNAME_PFA = new QName("pfa");
	public QName QNAME_BIO = new QName("bio");
	public QName QNAME_BT = new QName("bt");
	public QName QNAME_PIN = new QName("pin");
	public QName QNAME_OTP = new QName("otp");
	// attributes for node Meta
	public QName QNAME_DPID = new QName("dpId");
	public QName QNAME_RDSID = new QName("rdsId");
	public QName QNAME_RDSVER = new QName("rdsVer");
	public QName QNAME_DC = new QName("dc");
	public QName QNAME_MI = new QName("mi");
	public QName QNAME_MC = new QName("mc");
	// attributes for node Skey
	public QName QNAME_CI = new QName("ci");

	public QName QNAME_TYPE = new QName("type");
	public QName QNAME_CH = new QName("ch");
	// attributes for node Info
	public QName QNAME_RDSRNO = new QName("rdsrno");
	public QName QNAME_APPCODE = new QName("appCode");
	public QName QNAME_SCHEMECODE = new QName("schemeCode");

	// attributes for CIDR Response eKYC response
	public QName QNAME_SAT = new QName("status");
	public QName QNAME_KO = new QName("ko");
	public QName QNAME_RET = new QName("ret");
	public QName QNAME_CODE = new QName("code");
	public QName QNAME_TS = new QName("ts");
	public QName QNAME_ERR = new QName("err");
	public QName QNAME_KYCRES = new QName("kycRes");

	// attributes for KYC Response
	public QName QNAME_TTL = new QName("ttl");
	public QName QNAME_UIDTXN = new QName("tkn");

	public QName QNAME_POIDOB = new QName("dob");
	public QName QNAME_POIGEN = new QName("gender");
	public QName QNAME_POINAME = new QName("name");

	public QName QNAME_POACO = new QName("co");
	public QName QNAME_POACON = new QName("country");
	public QName QNAME_POADIS = new QName("dist");
	public QName QNAME_POAHOU = new QName("house");
	public QName QNAME_POALM = new QName("lm");
	public QName QNAME_POALOC = new QName("loc");
	public QName QNAME_POAPC = new QName("pc");
	public QName QNAME_POASTAT = new QName("state");
	public QName QNAME_POASTR = new QName("street");
	public QName QNAME_POAVTC = new QName("vtc");

	public QName QNAME_LCO = new QName("co");
	public QName QNAME_LCON = new QName("country");
	public QName QNAME_LDIS = new QName("dist");
	public QName QNAME_LHOU = new QName("house");
	public QName QNAME_LLAN = new QName("lang");
	public QName QNAME_LLM = new QName("lm");
	public QName QNAME_LLOC = new QName("loc");
	public QName QNAME_LNAM = new QName("name");
	public QName QNAME_LPC = new QName("pc");
	public QName QNAME_LSTAT = new QName("state");
	public QName QNAME_LSTR = new QName("street");
	public QName QNAME_LVTC = new QName("vtc");

	public QName QNAME_PRNTYPE = new QName("type");
	// error constants
	/* Request XMl */
	public String ERROR1001 = "1001:Xml is not as per the GOG AUA-ASA XSD Standard";
	/* KUA Authentication */
	public String ERROR1002 = "1002:SUB-AUA Code is null or invalid";
	public String ERROR1004 = "1004:ReqType is null or invalid";

	/* KUA Validation */
	public String ERROR1010 = "1010:Txn is required";
	public String ERROR1011 = "1011:Transaction id is invalid";
	public String ERROR1012 = "1012:Ts is required";
	public String ERROR1013 = "1013:UID is required";
	public String ERROR1014 = "1014:UID/VID/UID Token is invalid";
	public String ERROR1015 = "1015:Aadhaar number type is invalid";
	public String ERROR1016 = "1016:ra value is invalid or null";
	public String ERROR1017 = "1017:Rc is null or invalid";

	/* Info */
	public String ERROR1020 = "1020:Info is required";
	public String ERROR1021 = "1021:Info.rdsrn is required";
	public String ERROR1022 = "1022:Info.appcode is required";
	public String ERROR1023 = "1023:Info.scheme code is required";
	
	public String ERROR1024 = "1024:PFR is missing or invalid";
	
	public String ERROR1025 = "1025: HSM Service is down";
	public String ERROR1026 = "1026: HSM UNABLE TO DECRYPT RESPONSE";
	public String ERROR1027 = "1027: UNABLE TO PARSE HSM RESPONSE";
	
	public String ERROR1028 = "1028: Error Signing XML";
	public String ERROR1029 = "1029: Signature Verification Failed";

	/* uses invalid value */
	public String ERROR1030 = "1030:Uses.Pi is missing or invalid";
	public String ERROR1031 = "1031:Uses.Pa is missing or invalid";
	public String ERROR1032 = "1032:Uses.pfa is missing or invalid";
	public String ERROR1033 = "1033:Uses.bio is missing or invalid";
	public String ERROR1034 = "1034:Uses.bt is required for Uses.bio=y";
	public String ERROR1035 = "1035:Uses.bt has invalid value";
	public String ERROR1036 = "1036:Uses.pin is missing or invalid";
	public String ERROR1037 = "1037:Uses.otp is missing or invalid";
	public String ERROR1038 = "1038:Uses.otp is required";
	public String ERROR1039 = "1039:Uses.bt must be blank";

	/* meta required value */
	public String ERROR1040 = "1040:Meta is required";
	public String ERROR1041 = "1041:Meta.dpId is required";
	public String ERROR1042 = "1042:Meta.rdsId is required";
	public String ERROR1043 = "1043:Meta.rdsVer is required";
	public String ERROR1044 = "1044:Meta.dc is required";
	public String ERROR1045 = "1045:Meta.mi is required";
	public String ERROR1046 = "1046:Meta.mc is required";

	/* meta attributes must be blank for request otp */
	public String ERROR1050 = "1050:Meta.dpId value must be blank";
	public String ERROR1051 = "1051:Meta.rdsId value must be blank";
	public String ERROR1052 = "1052:Meta.rdsVer value must be blank";
	public String ERROR1053 = "1053:Meta.dc value must be blank";
	public String ERROR1054 = "1054:Meta.mi value must be blank";
	public String ERROR1055 = "1055:Meta.mc value must be blank";

	// PIDS Value
	public String ERROR1060 = "1060:Skey is required";
	public String ERROR1061 = "1061:Skey.ci is required";
	public String ERROR1062 = "1062:Data is required";
	public String ERROR1063 = "1063:HMAC is required";

	/* KSA VAlidation */
	public String ERROR2001 = "2001:Ver is required";
	public String ERROR2002 = "2002:Ver is Invalid";
	public String ERROR2003 = "2003:Rad is null";
	public String ERROR2004 = "2004:KUA Code is required";

	
	public String ERROR3001 = "3001: CIDR Service is not available";// CIDR Services is not availbale
	public String ERROR3002 = "3002: CIDR Service is not available";// ASA Services is not availbale
	public String ERROR3003 = "3003: CIDR Service NULL RESPONSE";// AUA Services is not availbale
	public String ERROR3004 = "3004: CIDR Service NULL RESPONSE";

	public String de = "N";
}
