package com.utils;


import java.security.Security;
import java.security.cert.CertificateFactory;

import org.apache.commons.codec.binary.Base64;


public class privateKey {
	
	public static CertificateFactory certFactory;
	private static final char[] PASSWORD = "DSTaua!Dec2020".toCharArray();
	private static final String ALIAS = "te-97a59e32-354e-4e1a-8f47-b0caabb2c99b";
	private static final String FILEPATH_PRIVATEKEY = "C:\\UIDAI\\ekyc\\DST_GUJ_encrypt.pfx";
	private static final String FILEPATH_PUBLICKEY = "C:\\UIDAI\\ekyc\\uidai_auth_encrypt_preprod.cer";
	

	public static String decryptor(String xml) {
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		byte[] decoded = Base64.decodeBase64(xml);
		DataDecryptor dataDecryptor= new DataDecryptor(FILEPATH_PRIVATEKEY,PASSWORD, FILEPATH_PUBLICKEY);
		try {
			String encxml = new String(dataDecryptor.decrypt(decoded));
			return encxml;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}


}


