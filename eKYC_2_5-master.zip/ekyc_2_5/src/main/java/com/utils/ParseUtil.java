/**
 * 
 */
package com.utils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.models.*;
import com.enums.*;

/**
 * ParseUtil class which performed here Parse the various type of request and
 * response XML's to Object and stored value in models class.
 * <p>
 * For reference
 * {@link https://www.journaldev.com/1191/java-stax-parser-example-read-xml-file}
 * 
 * @author Jeetendra K Mishra
 * @version 2.5, 15/07/2022
 * @since 2.0
 */
public class ParseUtil {
	/**
	 * @param XML Request XML which sent by SUB-AuA, If the XML's is null and
	 *            occurred any exception to run time it self it return null value.
	 * @implNote Modified Info parameter and add new attribute like LK (SuB-AUA's
	 *           License Key).
	 * @exception Exception It's a general Exception, It's return null value and
	 *                      throw exception massage in application logs.
	 * 
	 * @return XML's to request2_5 object
	 */
	public static Request2_5 parseKuaXML(String xml) {
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		xmlInputFactory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		Request2_5 request2_5 = new Request2_5();
		StringReader reader = new StringReader(xml);
		XMLEvent xmlEvent;
		try {
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(reader);
			while (xmlEventReader.hasNext()) {
				xmlEvent = xmlEventReader.nextEvent();
				if (xmlEvent.isStartElement()) {
					StartElement startElement = xmlEvent.asStartElement();
					switch (startElement.getName().toString()) {
					case "": {// do nothing}
						break;
					}

					// ******************** 1. UIDAI Number or Virtual Token**********************
					case "UID": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							try {
								request2_5.uid = new String(
										Base64.getDecoder().decode(xmlEvent.asCharacters().getData()), "UTF-8");
							} catch (Exception e) {
								// ExceptionLogger.logAsyncAua("Error getting UID:", e);
								System.out.println("exception in uid:" + e);
							}
						}
						break;
					}
					// ******************** 2. SUB-AUA Transaction ID**********************
					case "Txn": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.txn_subAua = xmlEvent.asCharacters().getData();
						}
						break;
					}
					// ******************** 3. SUB-AUA Code**********************
					case "SubAUACode": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.sa = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 5. API Version**********************
					case "Ver": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.ver = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 6. Resident authentication type **********************
					case "ra": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.ra = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 7. Resident corner value **********************
					case "rc": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.rc = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 8. Flag indicating if AUA application require local
					// language data in addition to English **********************
					case "lr": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.lr = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 9. Print format request flag for retrieving E-Aadhaar
					// document in PDF format as part of response **********************
					case "pfr": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.pfr = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 10. Aadhaar type **********************
					case "Type": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.type = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 11. Info **********************
					case "Info": {
						request2_5.info = new Info();
						request2_5.info.rdsrno = startElement.getAttributeByName(AppConstants.QNAME_RDSRNO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSRNO).getValue();
						request2_5.info.appCode = startElement.getAttributeByName(AppConstants.QNAME_APPCODE) == null
								? ""
								: startElement.getAttributeByName(AppConstants.QNAME_APPCODE).getValue();
						request2_5.info.scheamCode = startElement
								.getAttributeByName(AppConstants.QNAME_SCHEMECODE) == null ? ""
										: startElement.getAttributeByName(AppConstants.QNAME_SCHEMECODE).getValue();
						break;
					}

					// ******************** 12. Request type **********************
					case "ReqType": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.reqType = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 13. USes **********************
					case "Uses": {
						request2_5.uses = new Uses();
						request2_5.uses.pi = startElement.getAttributeByName(AppConstants.QNAME_PI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PI).getValue();
						request2_5.uses.pa = startElement.getAttributeByName(AppConstants.QNAME_PA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PA).getValue();
						request2_5.uses.pfa = startElement.getAttributeByName(AppConstants.QNAME_PFA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PFA).getValue();
						request2_5.uses.bio = startElement.getAttributeByName(AppConstants.QNAME_BIO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_BIO).getValue();
						request2_5.uses.bt = startElement.getAttributeByName(AppConstants.QNAME_BT) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_BT).getValue();
						request2_5.uses.pin = startElement.getAttributeByName(AppConstants.QNAME_PIN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PIN).getValue();
						request2_5.uses.otp = startElement.getAttributeByName(AppConstants.QNAME_OTP) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_OTP).getValue();
						break;
					}

					// ******************** 14. Meta **********************
					case "Meta": {
						request2_5.meta = new Meta();
						request2_5.meta.dpId = startElement.getAttributeByName(AppConstants.QNAME_DPID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DPID).getValue();
						request2_5.meta.rdsId = startElement.getAttributeByName(AppConstants.QNAME_RDSID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSID).getValue();
						request2_5.meta.rdsVer = startElement.getAttributeByName(AppConstants.QNAME_RDSVER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSVER).getValue();
						request2_5.meta.dc = startElement.getAttributeByName(AppConstants.QNAME_DC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DC).getValue();
						request2_5.meta.mi = startElement.getAttributeByName(AppConstants.QNAME_MI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_MI).getValue();
						request2_5.meta.mc = startElement.getAttributeByName(AppConstants.QNAME_MC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_MC).getValue();
						break;
					}

					// ******************** 15. Skey **********************
					case "Skey": {
						request2_5.skey = new Skey();
						request2_5.skey.ci = startElement.getAttributeByName(AppConstants.QNAME_CI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CI).getValue();
						if (startElement.getAttributeByName(AppConstants.QNAME_TYPE) != null) {
							request2_5.skey.type = startElement.getAttributeByName(AppConstants.QNAME_TYPE).getValue();
						}
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.skey.Data = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 16. Hmac **********************
					case "Hmac": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.hmac = xmlEvent.asCharacters().toString().getBytes();
						}
						break;
					}

					// ******************** 17. Data **********************
					case "Data": {
						request2_5.data = new Data();
						request2_5.data.type = DataType
								.fromValue(startElement.getAttributeByName(AppConstants.QNAME_TYPE).getValue());
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.data.data = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// ******************** 18. Request XML time-stamp **********************
					case "Ts": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.ts = xmlEvent.asCharacters().getData();
						}
						break;
					}
					}
				}
			}
		} catch (Exception e) {
			ApplicationLogger.logAsyncKua("Error parsing Sub-AUA XML: " + xml, e);
			// System.out.println("Exception in parsUtil:" + e);
			return null;
		}
		return request2_5;
	}

	/**
	 * @param XML Request XML which sent by KUA, If the XML's is null and occurred
	 *            any exception to run time it self it return null value.
	 * 
	 * @exception Exception It's a general Exception, It's return null value and
	 *                      throw exception massage in application logs.
	 * 
	 * @return XML's to request2_5 object
	 */
	public static Request2_5 parseKsaXML(String xml) {
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		xmlInputFactory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		Request2_5 request2_5 = new Request2_5();
		StringReader reader = new StringReader(xml);
		XMLEvent xmlEvent;
		try {
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(reader);
			while (xmlEventReader.hasNext()) {
				xmlEvent = xmlEventReader.nextEvent();
				if (xmlEvent.isStartElement()) {
					StartElement startElement = xmlEvent.asStartElement();
					switch (startElement.getName().getLocalPart().toString()) {
					case "": {// do nothing}
						break;
					}
					case "Kyc": {
						request2_5.ver = startElement.getAttributeByName(AppConstants.QNAME_VER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_VER).getValue();
						request2_5.ra = startElement.getAttributeByName(AppConstants.QNAME_RA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RA).getValue();
						request2_5.rc = startElement.getAttributeByName(AppConstants.QNAME_RC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RC).getValue();
						request2_5.lr = startElement.getAttributeByName(AppConstants.QNAME_LR) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LR).getValue();
						request2_5.de = startElement.getAttributeByName(AppConstants.QNAME_DE) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DE).getValue();
						request2_5.pfr = startElement.getAttributeByName(AppConstants.QNAME_PFR) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PFR).getValue();

						break;
					}
					case "Rad": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.rad = xmlEvent.asCharacters().toString();
						}
						break;
					}

					}

				}
			}
		} catch (Exception e) {
			ApplicationLogger.logAsyncKsa("Error parsing KUA XML:", e);
			return null;
		}
		return request2_5;

	}
/*
	public static Request2_5 parseAsaXML(String xml) {
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		xmlInputFactory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		Request2_5 request2_5 = new Request2_5();
		StringReader reader = new StringReader(xml);
		XMLEvent xmlEvent;
		try {
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(reader);
			while (xmlEventReader.hasNext()) {
				xmlEvent = xmlEventReader.nextEvent();
				if (xmlEvent.isStartElement()) {
					StartElement startElement = xmlEvent.asStartElement();
					switch (startElement.getName().getLocalPart().toString()) {
					case "": {// do nothing}
						break;
					}
					case "Auth": {
						request2_5.ac = startElement.getAttributeByName(AppConstants.QNAME_AC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_AC).getValue();
						request2_5.lk = startElement.getAttributeByName(AppConstants.QNAME_LK) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LK).getValue();
						request2_5.rc = startElement.getAttributeByName(AppConstants.QNAME_RC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RC).getValue();
						request2_5.sa = startElement.getAttributeByName(AppConstants.QNAME_SA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_SA).getValue();
						request2_5.tid = startElement.getAttributeByName(AppConstants.QNAME_TID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TID).getValue();
						request2_5.txn = startElement.getAttributeByName(AppConstants.QNAME_TXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TXN).getValue();
						request2_5.uid = startElement.getAttributeByName(AppConstants.QNAME_UID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_UID).getValue();
						request2_5.ver = startElement.getAttributeByName(AppConstants.QNAME_VER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_VER).getValue();
						request2_5.reqType = "other";
						break;
					}
					case "Uses": {
						request2_5.uses = new Uses();
						request2_5.uses.pi = startElement.getAttributeByName(AppConstants.QNAME_PI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PI).getValue();
						request2_5.uses.pa = startElement.getAttributeByName(AppConstants.QNAME_PA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PA).getValue();
						request2_5.uses.pfa = startElement.getAttributeByName(AppConstants.QNAME_PFA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PFA).getValue();
						request2_5.uses.bio = startElement.getAttributeByName(AppConstants.QNAME_BIO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_BIO).getValue();
						request2_5.uses.bt = startElement.getAttributeByName(AppConstants.QNAME_BT) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_BT).getValue();
						request2_5.uses.pin = startElement.getAttributeByName(AppConstants.QNAME_PIN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PIN).getValue();
						request2_5.uses.otp = startElement.getAttributeByName(AppConstants.QNAME_OTP) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_OTP).getValue();
						break;
					}
					case "Meta": {
						request2_5.meta = new Meta();
						request2_5.meta.dpId = startElement.getAttributeByName(AppConstants.QNAME_DPID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DPID).getValue();
						request2_5.meta.rdsId = startElement.getAttributeByName(AppConstants.QNAME_RDSID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSID).getValue();
						request2_5.meta.rdsVer = startElement.getAttributeByName(AppConstants.QNAME_RDSVER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RDSVER).getValue();
						request2_5.meta.dc = startElement.getAttributeByName(AppConstants.QNAME_DC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_DC).getValue();
						request2_5.meta.mi = startElement.getAttributeByName(AppConstants.QNAME_MI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_MI).getValue();
						request2_5.meta.mc = startElement.getAttributeByName(AppConstants.QNAME_MC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_MC).getValue();
						break;
					}

					case "Skey": {
						request2_5.skey = new Skey();
						request2_5.skey.ci = startElement.getAttributeByName(AppConstants.QNAME_CI) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CI).getValue();
						if (startElement.getAttributeByName(AppConstants.QNAME_TYPE) != null) {
							request2_5.skey.type = startElement.getAttributeByName(AppConstants.QNAME_TYPE).getValue();
						}
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.skey.Data = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Hmac": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.hmac = xmlEvent.asCharacters().toString().getBytes();
						}
						break;
					}

					case "Data": {
						request2_5.data = new Data();
						request2_5.data.type = DataType
								.fromValue(startElement.getAttributeByName(AppConstants.QNAME_TYPE).getValue());
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							request2_5.data.data = xmlEvent.asCharacters().getData();
						}
						break;
					}
					case "Signature": {
						request2_5.isSignaturePresent = true;
						// not getting entire signature, just setting some value to check
						// Signature Element is present
						break;
					}
					case "Otp": {
						request2_5.uid = startElement.getAttributeByName(AppConstants.QNAME_UID) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_UID).getValue();

						request2_5.ac = startElement.getAttributeByName(AppConstants.QNAME_AC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_AC).getValue();
						request2_5.sa = startElement.getAttributeByName(AppConstants.QNAME_SA) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_SA).getValue();
						request2_5.ver = startElement.getAttributeByName(AppConstants.QNAME_VER) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_VER).getValue();
						request2_5.txn = startElement.getAttributeByName(AppConstants.QNAME_TXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TXN).getValue();
						request2_5.tid = startElement.getAttributeByName(AppConstants.QNAME_TS) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TS).getValue();
						request2_5.lk = startElement.getAttributeByName(AppConstants.QNAME_LK) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LK).getValue();
						request2_5.rc = startElement.getAttributeByName(AppConstants.QNAME_RC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RC).getValue();
						request2_5.reqType = "otp";
						break;
					}
					case "Opts": {
						request2_5.ch = startElement.getAttributeByName(AppConstants.QNAME_CH) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CH).getValue();
						break;
					}

					}

				}
			}
		} catch (Exception e) {
			ExceptionLogger.logAsyncAsa("Error parsing AUA XML:", e);
			return null;
		}
		return request2_5;

	}
*/
	
	/**
	 * KUA has received response XML from KSA side and this method parse the XML's
	 * node and store data in Response2_5 class.
	 * 
	 * @param XML Response XML received from KSA
	 * @exception Genral Exception, It's return null value and throw exception value
	 *                   in application logs.
	 * @return response2_5 object of Response2_5, If the XML's is null and occurred
	 *         any exception to run time it self it return null value.
	 */
	public static Response2_5 parseCIDRXML(String xml) {
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		xmlInputFactory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		Response2_5 response2_5 = new Response2_5();
		StringReader reader = new StringReader(xml);
		XMLEvent xmlEvent;
		try {
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(reader);
			while (xmlEventReader.hasNext()) {
				xmlEvent = xmlEventReader.nextEvent();
				if (xmlEvent.isStartElement()) {
					StartElement startElement = xmlEvent.asStartElement();
					switch (startElement.getName().getLocalPart().toString()) {
					case "": {// do nothing}
						break;
					}
					case "Resp": {
						response2_5.status = startElement.getAttributeByName(AppConstants.QNAME_SAT) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_SAT).getValue();
						response2_5.Ko = startElement.getAttributeByName(AppConstants.QNAME_KO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_KO).getValue();
						response2_5.ret = startElement.getAttributeByName(AppConstants.QNAME_RET) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RET).getValue();
						response2_5.code = startElement.getAttributeByName(AppConstants.QNAME_CODE) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CODE).getValue();
						response2_5.txn = startElement.getAttributeByName(AppConstants.QNAME_TXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TXN).getValue();
						response2_5.ts = startElement.getAttributeByName(AppConstants.QNAME_TS) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TS).getValue();
						response2_5.err = startElement.getAttributeByName(AppConstants.QNAME_ERR) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_ERR).getValue();
						break;
					}

					case "kycRes": {

						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							response2_5.KycRes = xmlEvent.asCharacters().getData();
						}
						break;
					}

					}
				}
			}
			return response2_5;
		} catch (Exception e) {
			ApplicationLogger.logAsyncKsa("Error parsing CIDR Response:", e);
			return null;
		}

	}

	/**
	 * KUA has received response XML after perform decryption by HSM and this method
	 * parse the XML's node and store data in Response2_5 class.
	 * 
	 * @param XML Response XML received from HSM
	 * @exception Genral Exception, It's return null value and throw exception value
	 *                   in application logs.
	 * @return response2_5 object of Response2_5, If the XML's is null and occurred
	 *         any exception to run time it self it return null value.
	 */

	public static Response2_5 parseKYC(byte[] xml) {
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		xmlInputFactory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		Response2_5 response2_5 = new Response2_5();
//		StringReader reader = new StringReader(xml);
		InputStream stream = new ByteArrayInputStream(xml);
		XMLEvent xmlEvent;
		try {
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(stream, "UTF-8");
			while (xmlEventReader.hasNext()) {
				xmlEvent = xmlEventReader.nextEvent();
				if (xmlEvent.isStartElement()) {
					StartElement startElement = xmlEvent.asStartElement();
					switch (startElement.getName().getLocalPart().toString()) {
					case "": {// do nothing
						break;
					}
					case "KycRes": {
						response2_5.ret = startElement.getAttributeByName(AppConstants.QNAME_RET) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_RET).getValue();
						response2_5.code = startElement.getAttributeByName(AppConstants.QNAME_CODE) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_CODE).getValue();
						response2_5.txn = startElement.getAttributeByName(AppConstants.QNAME_TXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TXN).getValue();
						response2_5.ts = startElement.getAttributeByName(AppConstants.QNAME_TS) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TS).getValue();
						response2_5.ttl = startElement.getAttributeByName(AppConstants.QNAME_TTL) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_TTL).getValue();
						break;
					}

					case "Rar": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							response2_5.Rar = xmlEvent.asCharacters().getData();
						}
						break;
					}

					case "UidData": {
						response2_5.uidtxn = startElement.getAttributeByName(AppConstants.QNAME_UIDTXN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_UIDTXN).getValue();
						break;
					}

					case "Poi": {
						response2_5.Poi = new Poi();
						response2_5.Poi.dob = startElement.getAttributeByName(AppConstants.QNAME_POIDOB) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POIDOB).getValue();
						response2_5.Poi.gender = startElement.getAttributeByName(AppConstants.QNAME_POIGEN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POIGEN).getValue();
						response2_5.Poi.name = startElement.getAttributeByName(AppConstants.QNAME_POINAME) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POINAME).getValue();
						break;
					}

					case "Poa": {
						response2_5.Poa = new Poa();
						response2_5.Poa.co = startElement.getAttributeByName(AppConstants.QNAME_POACO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POACO).getValue();
						response2_5.Poa.country = startElement.getAttributeByName(AppConstants.QNAME_POACON) == null
								? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POACON).getValue();
						response2_5.Poa.dist = startElement.getAttributeByName(AppConstants.QNAME_POADIS) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POADIS).getValue();
						response2_5.Poa.house = startElement.getAttributeByName(AppConstants.QNAME_POAHOU) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POAHOU).getValue();
						response2_5.Poa.lm = startElement.getAttributeByName(AppConstants.QNAME_POALM) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POALM).getValue();
						response2_5.Poa.loc = startElement.getAttributeByName(AppConstants.QNAME_POALOC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POALOC).getValue();
						response2_5.Poa.pc = startElement.getAttributeByName(AppConstants.QNAME_POAPC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POAPC).getValue();
						response2_5.Poa.state = startElement.getAttributeByName(AppConstants.QNAME_POASTAT) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POASTAT).getValue();
						response2_5.Poa.street = startElement.getAttributeByName(AppConstants.QNAME_POASTR) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POASTR).getValue();
						response2_5.Poa.vtc = startElement.getAttributeByName(AppConstants.QNAME_POAVTC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POAVTC).getValue();
						break;
					}
					case "LData": {
						response2_5.LData = new LData();
						response2_5.LData.co = startElement.getAttributeByName(AppConstants.QNAME_POACO) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_POACO).getValue();
						response2_5.LData.country = startElement.getAttributeByName(AppConstants.QNAME_LCON) == null
								? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LCON).getValue();
						response2_5.LData.dist = startElement.getAttributeByName(AppConstants.QNAME_LDIS) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LDIS).getValue();
						response2_5.LData.house = startElement.getAttributeByName(AppConstants.QNAME_LHOU) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LHOU).getValue();
						response2_5.LData.lang = startElement.getAttributeByName(AppConstants.QNAME_LLAN) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LLAN).getValue();
						response2_5.LData.lm = startElement.getAttributeByName(AppConstants.QNAME_LLM) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LLM).getValue();
						response2_5.LData.loc = startElement.getAttributeByName(AppConstants.QNAME_LLOC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LLOC).getValue();
						response2_5.LData.name = startElement.getAttributeByName(AppConstants.QNAME_LNAM) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LNAM).getValue();
						response2_5.LData.pc = startElement.getAttributeByName(AppConstants.QNAME_LPC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LPC).getValue();
						response2_5.LData.state = startElement.getAttributeByName(AppConstants.QNAME_LSTAT) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LSTAT).getValue();
						response2_5.LData.street = startElement.getAttributeByName(AppConstants.QNAME_LSTR) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LSTR).getValue();
						response2_5.LData.vtc = startElement.getAttributeByName(AppConstants.QNAME_LVTC) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_LVTC).getValue();
						break;
					}

					case "Pht": {
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							response2_5.Pht = xmlEvent.asCharacters().getData();
						}
						break;
					}

					// Aadhaar PDF Copy

					case "Prn": {
						response2_5.Doc = new Doc();
						response2_5.Doc.type = startElement.getAttributeByName(AppConstants.QNAME_PRNTYPE) == null ? ""
								: startElement.getAttributeByName(AppConstants.QNAME_PRNTYPE).getValue();
						xmlEvent = xmlEventReader.nextEvent();
						if (xmlEvent.isCharacters()) {
							response2_5.Doc.data = xmlEvent.asCharacters().getData();
						}

						break;
					}

					}
				}
			}
			return response2_5;
		} catch (Exception e) {
			ApplicationLogger.logAsyncKsa("Error parsing CIDR Response:", e);
			return null;
		}
	}

	/**
	 * This method parse error XML's node, fetch error from <Rar> node.
	 * 
	 * @param XML Error XML received from CIDR
	 * @return error as String, If error variable isn't contain only number's then
	 *         it return "NA".
	 */
	// ******************** parseAuthError Method for Finding Authentication Error Code ******************************
	public static String parseAuthError(String kycRes) {

		String pattern = "\\d+";
		Pattern replace = Pattern.compile(pattern);
		try {
			kycRes = new String(Base64.getDecoder().decode(kycRes));
			if (kycRes.contains("<Rar>") && kycRes.contains("</Rar>")) {
				String rar = kycRes.substring(kycRes.indexOf("<Rar>") + 5, kycRes.indexOf("</Rar>"));
				rar = new String(Base64.getDecoder().decode(rar));
				String error = rar.substring(rar.indexOf("err=") + 5, rar.indexOf("err=") + 8);
				Matcher m = replace.matcher(error);
				if (m.matches()) {
					return error;
				}
			}
		} catch (Exception e) {
			ApplicationLogger.logAsyncKua("Auth Error parsing Issue: ", e);
		}
		return "NA";
	}
}