/**
 * 
 */
package com.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author yash
 *
 */
public class ApplicationLogger {
	private static final Logger KuaLogger = LogManager.getLogger("kua");
	private static final Logger KsaLogger = LogManager.getLogger("ksa");
	private static final Logger DbFailLogger = LogManager.getLogger("dbFail");
	
	public static void logAsyncKua(String message, Exception e) {
		KuaLogger.error(message, e);
	}

	public static void logAsyncKsa(String message, Exception e) {
		KsaLogger.error(message, e);
	}
	
	public static void logAsyncKua(String message) {
		KuaLogger.error(message + System.lineSeparator());
	}

	public static void logAsyncKsa(String message) {
		KsaLogger.error(message + System.lineSeparator());
	}
	
	public static void logAsyncDbFail(String message) {
		DbFailLogger.error(message + System.lineSeparator());
	}
}
