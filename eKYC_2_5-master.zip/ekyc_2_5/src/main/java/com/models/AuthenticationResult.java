/**
 * 
 */
package com.models;

/**
 * AuthenticationResult class is demonstrate the value of AuthenticatonResult
 * and errorCode
 * 
 * @author Jeetendra K Mishra
 * @version 2.5, 15/07/2022
 * @since 2.0
 */
public class AuthenticationResult {
	
	/**
	 * isAuthenticated is retrieved value from Authenticator.isAuthenticated after
	 * validate entry level requested data at KUA and KSA level.
	 */
	public boolean isAuthenticated;
	
	/**
	 * ErrorCode is demonstrate value of error which accord from authentication API.
	 */
	public String ErrorCode; 

}
