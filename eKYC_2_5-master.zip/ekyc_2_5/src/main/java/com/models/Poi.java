package com.models;

public class Poi {

	/*
	 * Citizen birth date 
	 */
	public String dob;
	/*
	 * Citizen Gender 
	 */
	public String gender;
	/*
	 * Citizen Full name 
	 */
	public String name;
	
	
	
	
}
