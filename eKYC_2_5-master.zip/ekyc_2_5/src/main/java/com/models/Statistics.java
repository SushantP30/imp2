/**
 * 
 */
package com.models;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author yash
 *
 */
public class Statistics {
	public static final LocalDateTime serverStarted = LocalDateTime.now();
	static AtomicInteger totalKUARequests = new AtomicInteger(0);
//	static AtomicInteger todayAUARequests = new AtomicInteger(0);
	static AtomicInteger totalKSARequests = new AtomicInteger(0);
//	static AtomicInteger todayASARequests = new AtomicInteger(0);
	
	public static void addRequests_KUA() {
		totalKUARequests.getAndIncrement();
//		todayAUARequests.getAndIncrement();
	}
	public static void addRequests_KSA() {
		totalKSARequests.getAndIncrement();
//		todayASARequests.getAndIncrement();
	}

	public static String getStats() {
		StringBuilder sb = new StringBuilder();
		return sb.append("Server Started:").append(serverStarted).append(System.lineSeparator())
				.append("================KUA Server ====================").append(System.lineSeparator())
				.append("Total Request: ").append(totalKUARequests).append(System.lineSeparator())
//				.append("Today's Request: ").append(todayAUARequests).append(System.lineSeparator())
				.append("================KSA Server ====================").append(System.lineSeparator())
				.append("Total Request: ").append(totalKSARequests).append(System.lineSeparator())
//				.append("Today's Request: ").append(todayASARequests).append(System.lineSeparator())
				.toString();
	}

}
