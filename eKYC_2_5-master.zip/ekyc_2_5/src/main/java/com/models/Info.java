/**
 * 
 */
package com.models;

/**
 *(Mandatory): This element specifies of transaction related information.
 *
 * @author Jeetendra K Mishra
 * @version 2.5, 15/07/2022
 * @since 2.0
 */
public class Info {
	
	/**
	 * (Mandatory) this attribute use for device serial number. When using
	 * biometric/BFD authentication take the serial number from RD service and put
	 * in this attribute.
	 */
	public String rdsrno = "NA";
	
	/**
	 * (Mandatory) SUB-AUA mention specific application code where the
	 * authentication transaction has occurred.
	 */
	public String appCode = "NA";
	
	/**
	 * (Mandatory) SUB-AUA mention specific scheme code where the
	 * authentication transaction has occurred.
	 */
	public String scheamCode = "NA";

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Info [rdsrno=");
		builder.append(rdsrno);
		builder.append(", appCode=");
		builder.append(appCode);
		builder.append(", schemeCode=");
		builder.append(scheamCode);
		builder.append("]");
		return builder.toString();
	}

	public String toStringForDb() {
		StringBuilder builder = new StringBuilder();
		builder.append(rdsrno);
		builder.append(",");
		builder.append(appCode);
		builder.append(",");
		builder.append(scheamCode);
		return builder.toString();
	}


}
