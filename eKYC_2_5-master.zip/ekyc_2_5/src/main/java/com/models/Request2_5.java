/**
 * 
 */
package com.models;

import java.util.Arrays;

import com.enums.*;
/**
 * This is Model class for request's entities data for Authentication XML.
 * 
 * @author Jeetendra K Mishra
 * @implNote Remove deviceId variable
 * @version 2.5, 15/07/2022
 * @since 2.0
 * 
 */
public class Request2_5 {
	
	/**
	*(mandatory) This can be Aadhaar Number (wherever Aadhaar number is used, in future, an encrypted Aadhaar number may also be used) or Virtual ID or agency specific UID token of the person being authenticated.
	*/
	public String uid;
	
	/**
	*(mandatory) Aadhaar number holder consent to do the Aadhaar based authentication using OTP or Biometrics. Only allowed value is “Y”. Without explicit informed consent of the Aadhaar number holder KUA/Sub-AUA application should not call this API.
	*/
	public String rc;
	
	/**
	 * SUB-AUA license key which is expired in one year 
	 */
	public String subauaLk;
	
	/**
	*(mandatory) Resident authentication type. Valid values are “F”, “I”, “O”, “P” or any combination of these. Front end e-KYC application that capture the
                 resident authentication PID block, should determine value of this attribute based on what is captured. For example, if resident authentication uses fingerprints,
				 then this should be “F”, if both fingerprint and OTP are used this should be “FO”, and so on (see table below for all values). This and actual authentication factors
                 within PID block do not match, an error is returned
	*/
	public String ra;
	
	/**
	*(optional) Flag indicating if KUA application require local language data in addition to English. Valid values are “Y” and “N”. Default value is “N” (by default,
                this API does not return local Indian language data).
	*/
	public String lr;
	/**
	 * (optional) Flag indicating if KUA is delegating decryption to KSA. If this flag
	              is set to “Y”, then KSA public key will be used to encrypt e-KYC response XML
	              instead of KUA key provided KSA is allowed to do so. This facility is subject to
	              UIDAI approval.
	 */
	public String de;
	
	/**
	*(optional)Print format request flag for retrieving E-Aadhaar document in PDF format as part of response . Only valid values are "Y" and "N". If "Y" is
               passed the print format is returned in the response in addition to XML.
	*/
	public String pfr;
	
	/**
	*(mandatory) Value should be passed as “registered”. When not using biometric authentication, value of this attribute must be “”.
	*/
	public String tid;
	
	/**
	*(mandatory) A unique code for the AUA which is assigned by UIDAI during AUA registration process. This is an alpha-numeric string having maximum length 10. (A Default value “public” is available which is ONLY for testing.)
	*/
	public String ac;
	
	/**
	*(mandatory) A unique “Sub-AUA” code assigned by UIDAI. AUAs should get their Sub-AUAs registered within UIDAI system.
	o This allows auditing and business intelligence to be provided at SA level. If AUA and SA are same agency, use value of “ac” for this attribute.
	o This is an alpha-numeric string having maximum length 10.
	o AUA to intimate UIDAI of their sub-AUAs and the sub-AUA code will be assigned by UIDAI.
	*/
	public String sa;
	
	/**
	*(mandatory) version of the API. Currently only valid value is “2.5”.
	*/
	public String ver;
	
	/**
	*(mandatory) AUA specific transaction identifier. AUA can choose to pass this as part of input. This is returned as part of response as is. This is very useful for linking transactions full round trip across systems.
	o This is an alpha-numeric string of maximum length 50. Only supported characters are A-Z, a-z, 0-9, period, comma, hyphen, backward & forward slash, left & right parenthesis, and colon. No other characters are supported.
	o It is highly recommended that AUAs use this attribute for correlating requests with responses for auditing and verification.
	o In case of OTP Authentication using Request OTP API call this value of txn MUST be same as the txn value used for Request OTP API call. This is to ensure OTP cannot be intercepted and used by other applications.
	o This MUST NOT start with “U*:” where “*” can be one or more alpha-numeric characters. All namespaces starting with “U” is reserved for various APIs offered by UIDAI.
	*/
	public String txn_subAua;
	
	/**
	*(mandatory) AUA specific transaction identifier. AUA can choose to pass this as part of input. This is returned as part of response as is. This is very useful for linking transactions full round trip across systems.
	o This is an alpha-numeric string of maximum length 50. Only supported characters are A-Z, a-z, 0-9, period, comma, hyphen, backward & forward slash, left & right parenthesis, and colon. No other characters are supported.
	o It is highly recommended that AUAs use this attribute for correlating requests with responses for auditing and verification.
	o In case of OTP Authentication using Request OTP API call this value of txn MUST be same as the txn value used for Request OTP API call. This is to ensure OTP cannot be intercepted and used by other applications.
	o This MUST NOT start with “U*:” where “*” can be one or more alpha-numeric characters. All namespaces starting with “U” is reserved for various APIs offered by UIDAI.
	*/
	public String txn;
	
	/**
	*(mandatory) A valid “License Key” assigned to the AUA/Sub-AUA.
	o These license keys have expiry built into them and AUA/Sub-AUA administrator need to ensure that they generate new license keys before current ones expires through self-service portal.
	o This is an alpha-numeric string of length up to 64 characters.
	*/
	public String lk;

	/**
	*
	*/
	public String ts;
	
	/**
	*(mandatory)
	*SUB-AUA specific request identifier. AUA can forward the request to UIDAI as per received the request type.
	*Valid types are bio, demo, bfd, otpauth, otp
	*/
	public String reqType;

	/**
	*Mandatory): Type of OTP request. Possible values are:
	o “A” – uid attribute value shall contain Aadhaar number.
	o “E” – uid attribute shall contain Encrypted Aadhaar Number (future).
	o “V” – uid attribute shall contain a Virtual ID.
	o “T” – uid attribute shall contain UID Token.
	*/
	public String type="";

	/**
	*This element specifies metadata related to the device. Except for udc, all other attributes are valid only for biometric authentication.
	*/
	public Meta meta;

	/**
	*This element specifies the authentication factors used by the request. When an authentication factor is specified in this element, that specific attribute must be present in the encrypted data block. This is particularly useful in situations where the AUA does not fully control the terminal device, but wishes to maintain a certain level of control on the authentication transaction.
	*/
	public Uses uses;

	/**
	*Value of this element is base-64 encoded value of encrypted 256-bit AES session key. Session key must be dynamically generated for every transaction (session key must not be reused) and must not be stored anywhere except in memory. See next chapter for encryption details.
	*/
	public Skey skey;

	/**
	*
	*/
	public Data data;

	/**
	*(mandatory)
	 Devices which is constructing the “Pid” element must perform the following to provide the Hmac value:
	o If Pid type is “X” (XML), then:
	 After forming Pid XML, compute SHA-256 hash of Pid XML string
	 Then encrypt using session key
	 Then encode using base-64 encoding (as described earlier, encoding can be done on the AUA server when forming final Auth XML)
	o If Pid type is “P” (Protobuf), then:
	 After forming Protobuf byte array for Pid, compute SHA-256 hash of Pid protobuf bytes.
	 Then encrypt using session key
	 Then encode using base-64 encoding (as described earlier, encoding can be done on the AUA server when forming final Auth XML)
	Authentication server performs the following processing on each authentication request:
	1. Decode and Decrypt the Pid from Data element. Based on type attribute of the “Data” element, the value of Data is either interpreted as XML or Protobuf bytes.
	2. Re-compute the SHA-256 Hash of Pid.
	3. Decode and decrypt the value of Hmac element.
	4. Compare the re-computed SHA-256 hash with Hmac value received in authentication request.
	Version 2.5 Aadhaar Authentication API
	© UIDAI, 2011-2018 http://uidai.gov.in/ Page 14 of 33
	a. If both values match, then, integrity of authentication request is preserved and server will proceed with further processing of the request.
	b. If values do not match, reject the authentication request with error code representing “HMAC Validation failed”.
	*/
	public byte[] hmac;
	
	/**
	*(mandatory)
	 The request XML should be digitally signed for message integrity and non-repudiation purposes....
	*/
	public boolean isSignaturePresent =false;
	
	/**
	*
	*/
	public Info info;
	
	public String rad;
	
	/**
	 * Ch-(Optional): Valid only when using OTP against an Aadhaar number or VID Number (when using Aadhaar/VID number in “uid” attribute). Channel through which OTP should be sent. Possible values are:
	o “00” – send OTP via both SMS and Email (this is the default)
	o “01” – send OTP via SMS only
	o “02” – send OTP via Email only
	 */
	public String ch="01";

	public String IpAddress;

	public RequestTo requestTo;
	
	/*
	 * request received from Aua /SUb Aua
	 */
	public String RequestReceived;
	/*
	 * request sent to ASA /CIDR
	 */
	public String RequestSent;
	/*
	 * response received from ASA /CIDR
	 */
	public String ResponseReceived;
	/*
	 * response sent to Aua /SUb Aua
	 */
	public String ResponseSent;
	
	@Override
	public String toString() {
		return "Request2_5 [uid=" + uid + ", rc=" + rc + ", subauaLk=" + subauaLk + ", ra=" + ra + ", lr=" + lr
				+ ", pfr=" + pfr + ", tid=" + tid + ", ac=" + ac + ", sa=" + sa + ", ver=" + ver + ", txn_subAua="
				+ txn_subAua + ", txn=" + txn + ", lk=" + lk + ", ts=" + ts + ", reqType=" + reqType + ", type=" + type + ", meta=" + meta + ", uses=" + uses + ", skey=" + skey + ", data="
				+ data + ", hmac=" + Arrays.toString(hmac) + ", isSignaturePresent=" + isSignaturePresent + ", info="
				+ info + ", ch=" + ch + ", IpAddress=" + IpAddress + ", requestTo=" + requestTo + ", RequestReceived="
				+ RequestReceived + ", RequestSent=" + RequestSent + ", ResponseReceived=" + ResponseReceived
				+ ", ResponseSent=" + ResponseSent + "]";
	}
	
	

	
	
}
