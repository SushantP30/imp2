package com.models;

public class Doc {
	
	public String type;
	
	public String data;
}
