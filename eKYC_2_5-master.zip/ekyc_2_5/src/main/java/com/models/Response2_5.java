
/**
 * 
 */
package com.models;

/**
 * @author harsh
 *
 */
public class Response2_5 {
	public String ret;
	/**
	 * unique code sent by CIDR
	 */
	public String code="";
	public String txn="";
	public String txn_subAua;
	public String ttl="NA";
	public String KycRes="";
	public String uidtxn;
	public String Pht;
	public String Rar;
	
	
	public Poi Poi;
	public Poa Poa;
	public LData LData;
	public Doc Doc;
	/**
	 * Response Code
	 */
	public String err="NA";
	public String authErr="NA";
	public String ts;
	public String actn="NA";
	public String info="";
	public String uidToken="";
	public String status;
	public String Ko;
	public boolean isSignaturePresent =false;
	
	public String maskedMobile;
	public String maskedEmail;
	public boolean isOtpResponse =false;
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Response2_5 [deviceId=");
		builder.append(", ret=");
		builder.append(ret);
		builder.append(", code=");
		builder.append(code);
		builder.append(", txn=");
		builder.append(txn);
		builder.append(", txn_subAua=");
		builder.append(txn_subAua);
		builder.append(", err=");
		builder.append(err);
		builder.append(", ts=");
		builder.append(ts);
		builder.append(", actn=");
		builder.append(actn);
		builder.append(", info=");
		builder.append(info);
		builder.append(", uidToken=");
		builder.append(uidToken);
		builder.append(", bfdRanks=");
		builder.append(", isSignaturePresent=");
		builder.append(isSignaturePresent);
		builder.append(", maskedMobile=");
		builder.append(maskedMobile);
		builder.append(", maskedEmail=");
		builder.append(maskedEmail);
		builder.append(", isOtpResponse=");
		builder.append(isOtpResponse);
		builder.append("]");
		return builder.toString();
	}
}
	
