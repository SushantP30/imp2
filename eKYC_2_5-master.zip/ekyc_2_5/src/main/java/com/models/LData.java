package com.models;

public class LData {
	
	/*
	 * care of(co) person name
	 */
	public String co;
	/*
	 * citizen country name
	 */
	public String country;
	/*
	 * citizen district name
	 */
	public String dist;
	/*
	 * citizen house number
	 */
	public String house;
	/*
	 * citizen language code
	 */
	public String lang;
	/*
	 * citizen land mark
	 */
	public String lm;
	/*
	 * citizen location(loc) 
	 */
	public String loc;
	/*
	 * citizen full name 
	 */
	public String name;
	/*
	 * citizen pincode number
	 */
	public String pc;
	/*
	 * citizen state name
	 */
	public String state;
	/*
	 * citizen street name
	 */
	public String street;
	/*
	 * citizen village name
	 */
	public String vtc;
	@Override
	public String toString() {
		return "LData [co=" + co + ", country=" + country + ", dist=" + dist + ", house=" + house + ", lang=" + lang
				+ ", lm=" + lm + ", loc=" + loc + ", name=" + name + ", pc=" + pc + ", state=" + state + ", street="
				+ street + ", vtc=" + vtc + "]";
	}
	
	
	
}
