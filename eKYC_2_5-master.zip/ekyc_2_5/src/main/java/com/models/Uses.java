/**
 * 
 */
package com.models;

/**
 * @author Adit
 *
 */
public class Uses {
	/**
	 * (mandatory) Valid values are “y” or “n”. If the value is “y” then at least
	 * one attribute of element “Pi” (part of “Demo” element) should be used in
	 * authentication. If value is “n”, “Pi” element is not mandated.
	 */
	public String pi;

	/**
	 * (mandatory) Valid values are “y” or “n”. If the value is “y” then at least
	 * one attribute of element “Pa” (part of “Demo” element) should be used in
	 * authentication. If value is “n", “Pa” element is not mandated.
	 */
	public String pa;

	/**
	 * (mandatory) Valid values are “y” or “n”. If the value is “y” then element
	 * “Pfa” (part of “Demo” element) should be used in authentication. If value is
	 * “n”, “Pfa” element is not mandated.
	 */
	public String pfa;

	/**
	 * (mandatory) Valid values are “y” or “n”. If the value is “y” then at least
	 * one biometric element “Bio” (part of “Bios” element) should be used in
	 * authentication. If value is “n”, “Bio” element is not mandated.
	 */
	public String bio;

	/**
	 * (mandatory only if “bio” attribute has value “y”) provide a comma separated
	 * list of biometrics used. Valid values that can be used in this comma
	 * separated list are “FMR”, “FIR”, “IIR” and “FID”. If “FMR” is part of the
	 * list, then at least one “Bio” element with type FMR should be used.
	 * Similarly, if “FIR” or “IIR” or “FID” are part of the list, then at least one
	 * “Bio” element with those types must be used.
	 */
	public String bt;

	/**
	 * (mandatory) Valid values are “y” or “n”. If the value is “y” then PIN should
	 * be used in authentication. Otherwise, “pin” is not mandated.
	 */
	public String pin;

	/**
	 * (mandatory) Valid values are “y” or “n”. If the value is “y” then OTP should
	 * be used in authentication. Otherwise, “otp” is not mandated.
	 */
	public String otp;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Uses [pi=");
		builder.append(pi);
		builder.append(", pa=");
		builder.append(pa);
		builder.append(", pfa=");
		builder.append(pfa);
		builder.append(", bio=");
		builder.append(bio);
		builder.append(", bt=");
		builder.append(bt);
		builder.append(", pin=");
		builder.append(pin);
		builder.append(", otp=");
		builder.append(otp);
		builder.append("]");
		return builder.toString();
	}
}
