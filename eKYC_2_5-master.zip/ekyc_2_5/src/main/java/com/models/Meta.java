/**
 * 
 */
package com.models;

/**
 * This element specifies information related to the device. Except for udc, all
 * other attributes are valid only for biometric authentication.
 * 
 * @author Jeetendra K Mishra
 * @version 2.5, 15/07/2022
 * @since 2.0
 * 
 */
public class Meta {
	/**
	 * (mandatory for bio auth) Unique code assigned to registered device provider.
	 * Returned by RD Service when using biometric authentication.
	 */
	public String dpId ;
	/**
	 * (mandatory for bio auth) Unique ID of the certified registered device
	 * service. Returned by RD Service when using biometric authentication.
	 */
	public String rdsId ;

	/**
	 * (mandatory for bio auth) Registered devices service version. Returned by RD
	 * Service when using biometric authentication.
	 */
	public String rdsVer ;

	/**
	 * (mandatory for bio auth) Unique Registered Device Code. Returned by RD
	 * Service when using biometric authentication.
	 */
	public String dc ;

	/**
	 * (mandatory for bio auth) Registered device model ID. Returned by RD Service
	 * when using biometric authentication.
	 */
	public String mi ;

	/**
	 * (mandatory for bio auth) This attribute holds registered device public key
	 * certificate. This is signed with device provider key. Returned by RD Service
	 * when using biometric authentication.
	 */
	public String mc ;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Meta [dpId=");
		builder.append(dpId);
		builder.append(", rdsId=");
		builder.append(rdsId);
		builder.append(", rdsVer=");
		builder.append(rdsVer);
		builder.append(", dc=");
		builder.append(dc);
		builder.append(", mi=");
		builder.append(mi);
		builder.append(", mc=");
		builder.append(mc);
		builder.append("]");
		return builder.toString();
	}
}
