package com.models;

public class Poa {

	/*
	 * care of(co) person name
	 */
	public String co;
	/*
	 * citizen country name
	 */
	public String country;
	/*
	 * citizen district name
	 */
	public String dist;
	/*
	 * citizen house number
	 */
	public String house;
	/*
	 * citizen land mark
	 */
	public String lm;
	/*
	 * citizen location(loc) 
	 */
	public String loc;
	/*
	 * citizen pincode number
	 */
	public String pc;
	/*
	 * citizen state name
	 */
	public String state;
	/*
	 * citizen street name
	 */
	public String street;
	/*
	 * citizen village name
	 */
	public String vtc;
	
	
	
}
