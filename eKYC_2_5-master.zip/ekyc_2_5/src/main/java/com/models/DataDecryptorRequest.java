package com.models;

/**
 * DataDecryptorRequest class is a model class for create request to decrypt
 * CIDR response by HSM.
 * 
 * @author Jeetendra K Mishra
 * @version 2.5, 15/07/2022
 * @since 2.0
 * 
 */
public class DataDecryptorRequest {

	/**
	 * (Mandatory) Decryption algorithm
	 */
	public String algorithm = "RSA/ECB/NoPadding";

	/**
	 * (Mandatory) Base 64 encoded Ekyc Response XML String which needs to be
	 * decrypted
	 */
	public String enc_val;

	/**
	 * (Mandatory) Decryption Key Label
	 */
	public String keylabel = "Gil9058C";

	/**
	 * (Mandatory) Transaction Id for reference. It's a Authentication TXN ID.
	 */

	public String txn;

	@Override
	public String toString() {
		return "DataDecryptorRequest [algorithm=" + algorithm + ", enc_val=" + enc_val + ", keylabel=" + keylabel
				+ ", txn=" + txn + "]";
	}

}
