/**
 * 
 */
package com.models;
import com.enums.*;
/**
 * XMLBuilder class is build several XMLs i.e Authentication Request XML, OTP
 * Generation XML, Response XML, Error XML, OTP Response XML.
 * 
 * @author Jeetendra K Mishra
 * @version 2.5, 15/07/2022
 * @since 2.0
 */
public class BfdRank {
	/**
	 * Finger position for which matching rank is provided. Possible values are same
	 * as that of “pos” attribute within “Bio” element of Authentication PID XML.
	 */
	public FingerPosition pos;
	
	/**
	 * This attribute indicates a value between 1 and 10. This attribute indicates
	 * the order of preference in which resident should use his/her fingers for
	 * authentication. Value 1 indicates first choice and 10 indicates last choice.
	 */
	public int value;
}
