package com.models;

/**
 * DataDecryptorResponse class is a model class for receiving response after
 * performing decryption by HSM.
 * 
 * @author Jeetendra K Mishra
 * @version 2.5, 15/07/2022
 * @since 2.0
 * 
 */
public class DataDecryptorResponse {

	/**
	 * Error message with cause
	 */
	public String errMsg;

	/**
	 * Base 64 encoded decrypted Ekyc Response XML String
	 */
	public String ret_val;

	/**
	 * Positive Value represents success Negative Value represents failure
	 */
	public int status;

	/**
	 * Positive Value represents success Negative Value represents failure
	 */
	public String txn;

	@Override
	public String toString() {
		return "DataDecryptorResponse [errMsg=" + errMsg + ", ret_val=" + ret_val + ", status=" + status + ", txn="
				+ txn + "]";
	}

}
