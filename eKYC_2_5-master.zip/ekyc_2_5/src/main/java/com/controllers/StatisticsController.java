/**
 * 
 */
package com.controllers;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.models.Statistics;;
/**
 * @author yash
 *
 */
@SpringBootApplication
@RestController
public class StatisticsController {
	@GetMapping(value="/stats" )
	public  String getStatistics() {
		return "<html><head><title>Statistics of the Server</title></head><body><pre>"+ Statistics.getStats()+"</pre></body></html>";
	}
}
