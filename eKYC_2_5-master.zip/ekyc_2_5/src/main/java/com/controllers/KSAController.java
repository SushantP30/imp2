/**
 * 
 */
package com.controllers;

import static java.time.temporal.ChronoUnit.MILLIS;

import java.time.LocalTime;

import javax.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enums.RequestTo;
import com.models.Request2_5;
import com.models.Response2_5;
import com.models.Statistics;
import com.utils.AppConstants;
import com.utils.ApplicationLogger;
import com.utils.AuditUtil;
import com.utils.DateTimeUtil;
import com.utils.HttpClientUtil;
import com.utils.ParseUtil;
import com.utils.Validator;
import com.utils.XMLBuilder;

/**
 * @author harsh
 *
 */
@SpringBootApplication
@RestController
@RequestMapping("/KSA2_5/rest")
public class KSAController {

	@GetMapping(value = "/checkksastatus25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String checkASAStatus() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><status>ASA of GOG Up &amp; Runing</status>";
	}

	@PostMapping(value = "/authreqv25/{uid}/{txn}/{ac}", produces = { "application/xml" })
	public String acceptRequest25(@RequestBody String requestXML, @PathVariable("uid") String uid,
			@PathVariable("txn") String txn, @PathVariable("ac") String ac, HttpServletRequest httpRequest) {
		return processAndBuildResponse(requestXML, uid, txn, ac, httpRequest);
	}

	private String processAndBuildResponse(String requestXML, String uid, String txn, String ac,
			HttpServletRequest httpRequest) {
		Statistics.addRequests_KSA();
		LocalTime refTime = LocalTime.now();
		print("Entered KSA :", refTime);
		Response2_5 errorResponse = new Response2_5();
		// ******************** 1. Parse the XML to Object**********************
		Request2_5 request = ParseUtil.parseKsaXML(requestXML);
		if (request == null) {
			errorResponse.err = AppConstants.ERROR1001;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			ApplicationLogger.logAsyncKsa("Parse Error : "+errorResponse.toString());
			return XMLBuilder.buildKSARespForError(errorResponse);
		}
		print("Parse Complete:", refTime);

		// ******************** 2. Validate ***********************************
		request.txn = txn;
		request.ac = ac;
		request.uid = uid;
		request.RequestReceived = DateTimeUtil.getCurrentDateSQLFormat();
		request.IpAddress = httpRequest.getRemoteAddr();
		request.requestTo = RequestTo.KSA;
		errorResponse.txn = request.txn;
		String validationError = Validator.Validate(request);
		if (!validationError.equals("")) {
			errorResponse.err = validationError;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKsaAsync(request, errorResponse);
			ApplicationLogger.logAsyncKsa("Validation Error : "+errorResponse.toString());
			return XMLBuilder.buildKSARespForError(errorResponse);
		}
		print("Validation Complete:", refTime);
		// ******************** 3. Send to CIDR and return Response ************

		request.RequestSent = DateTimeUtil.getCurrentDateSQLFormat();
		try {
			String cidrResponse = HttpClientUtil.postToCIDRAsync(requestXML, uid).join();
			request.ResponseReceived = DateTimeUtil.getCurrentDateSQLFormat();
			print("Response Received from CIDR :", refTime);
			Response2_5 response = ParseUtil.parseCIDRXML(cidrResponse);
			if (cidrResponse.contains("<html>") || cidrResponse == null || cidrResponse.equals("") || response == null) {
				errorResponse.err = AppConstants.ERROR3003;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				ApplicationLogger.logAsyncKsa(request.txn+" CIDR NULL Rsponse XML : "+cidrResponse);
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveKsaAsync(request, errorResponse);
				return XMLBuilder.buildKSARespForError(errorResponse);
			}
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKsaAsync(request, response);
			print("Response send to KUA :", refTime);
			return cidrResponse;
		} catch (Exception e) {
			errorResponse.err = AppConstants.ERROR3001;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			ApplicationLogger.logAsyncKsa(request.txn+" CIDR Connection Timeout:", e);
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKsaAsync(request, errorResponse);
			return XMLBuilder.buildKSARespForError(errorResponse);
		}
	}
	
	private void print(String message, LocalTime refTime) {
		System.out.println(message + (refTime.until(LocalTime.now(), MILLIS)));
	}
}
