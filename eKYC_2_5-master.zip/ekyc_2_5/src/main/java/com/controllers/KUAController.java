/**
 * 
 */
package com.controllers;

import java.time.LocalTime;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.utils.*;
import com.models.*;
import com.enums.*;
import org.springframework.web.bind.annotation.RestController;
import static java.time.temporal.ChronoUnit.MILLIS;

/**
 * Traditionally all “Know Your Customer (KYC)” processes and verification of
 * PoI and PoA are done using copies of PoI/PoA documents. It is commonplace to
 * provide self-attested photocopies of these documents every time a bank
 * account is opened, SIM card issued, insurance is purchased, etc. KUA
 * application captures Aadhaar number (or Virtual ID or UID Token or Encrypted
 * Aadhaar Number in future) + biometric/OTP of resident and forms the encrypted
 * PID block
 * <p>
 * Department of Science and Technology, Government of Gujarat registered as KUA
 * in India, that uses Aadhaar authentication services of UIDAI and sends
 * authentication requests to enable its services / business functions.
 * 
 * @author Harsh H. Barot
 * @version 2.5.1, 06/01/2022
 * @since 2.5
 */

@SpringBootApplication
@RestController
@RequestMapping("/kua/rest")
public class KUAController {

	/**
	 * User can check the API status, It's running or not.
	 * 
	 * @return Application status XML.
	 */
	@GetMapping(value = "/checkauastatus25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String checkAUAStatus() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><status>KUA of GOG Up &amp; Runing</status>";
	}

	/**
	 * @param requestXML  EKYC request XML,which is requested by SuB-AUA's portal
	 *                    for Aadhaar e-KYC.
	 * @param httpRequest Extends the {@link javax.servlet.ServletRequest} interface
	 *                    to provide request
	 * @return XML Aadhaar e-KYC response XML.
	 */
	@PostMapping(value = "/authreqv25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String acceptRequest25(@RequestBody(required = false) String requestXML, HttpServletRequest httpRequest) {
		return processAndBuildResponse(requestXML, httpRequest);
	}

	private String processAndBuildResponse(String requestXML, HttpServletRequest httpRequest) {

		LocalTime refTime = LocalTime.now();
		print(System.lineSeparator() + "Entered KUA :", refTime);
		Statistics.addRequests_KUA();
		Response2_5 errorResponse = new Response2_5();
		errorResponse.ret = "n";
		errorResponse.actn = "NA";

		// ******************** 1. Parse the XML to Object**********************

		Request2_5 request = ParseUtil.parseKuaXML(requestXML);
		if (request == null) {
			errorResponse.err = AppConstants.ERROR1001;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			ApplicationLogger.logAsyncKua("Parse Error : " + errorResponse.toString());
			return XMLBuilder.buildKUAResp(errorResponse);
		}
		print("Parse Complete:", refTime);

		// ******************** 2. Authenticate ********************************
		request.RequestReceived = DateTimeUtil.getCurrentDateSQLFormat();
		request.IpAddress = httpRequest.getRemoteAddr();
		request.requestTo = RequestTo.KUA;
		errorResponse.txn_subAua = (request.txn_subAua == null || request.txn_subAua.equals("")) ? "NA"
				: request.txn_subAua;
		AuthenticationResult result = Authenticator.isAuthenticated(request);
		if (!result.isAuthenticated) {
			errorResponse.err = result.ErrorCode;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKuaAsync(request, errorResponse);
			ApplicationLogger.logAsyncKua("Authentication Error : " + errorResponse.toString());
			return XMLBuilder.buildKUAResp(errorResponse);
		}
		print("Authentication Complete:", refTime);

		// ******************** 3. Validate *************************************

		String validationError = Validator.Validate(request);
		if (!validationError.equals("")) {
			errorResponse.err = validationError;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKuaAsync(request, errorResponse);
			ApplicationLogger.logAsyncKua("Validation Error : " + errorResponse.toString());
			return XMLBuilder.buildKUAResp(errorResponse);

		}
		print("Validation Complete:", refTime);

		// ******************** 4. Generate Auth XML for resident ****************
		switch (request.reqType) {
		case "bio":
			request.tid = PropertiesUtil.getTerminalId();
			break;
		case "otp":
			request.tid = PropertiesUtil.getTerminalIdOtpAuth();
			break;
		default:
			break;
		}
		request.ac = PropertiesUtil.getAauaCode();
		request.lk = PropertiesUtil.getKuaLicenseKey();
		request.txn = TransactionNoUtil.generateTxnNo(request.uid, request); // AUA txn id generate
		String xml = XMLBuilder.buildASARequest(request);
		// ******************** 5. Sign XML ***************************************
		String signedXML = SignatureUtil.signXML(xml);
		if (signedXML.equals("")) {
			errorResponse.err = AppConstants.ERROR1028;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKuaAsync(request, errorResponse);
			ApplicationLogger.logAsyncKua("Signature Error : " + errorResponse.toString());
			return XMLBuilder.buildKUAResp(errorResponse);
		}
		print("Sign XML Complete :", refTime);

		// ******************** 6. base64 encoded fully valid Auth XML ************
		String encodedXML = Base64.getEncoder().encodeToString(signedXML.getBytes());

		// ******************** 7. Generate Request XML for eKYC ******************
		String ekyXML = XMLBuilder.bulideKYCRequestxml(request, encodedXML);

		// ******************** 8. Send to KSA **********************************
		String strAsaResponse;
		request.RequestSent = DateTimeUtil.getCurrentDateSQLFormat();
		try {
			strAsaResponse = HttpClientUtil.postToKsaAsync(ekyXML, request.uid, request.txn, request.ac).join();
			request.ResponseReceived = DateTimeUtil.getCurrentDateSQLFormat();
			print("Response Received from KSA :", refTime);

		} catch (Exception e) {
			errorResponse.err = AppConstants.ERROR3002;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			ApplicationLogger.logAsyncKua("Connection TimeOut at KUA Level: " + errorResponse.toString(), e);
			AuditUtil.saveKuaAsync(request, errorResponse);
			return XMLBuilder.buildKUAResp(errorResponse);
		}

		// ******************** 8. parse response ********************************
		Response2_5 response2_5One = ParseUtil.parseCIDRXML(strAsaResponse);
		if (response2_5One == null) {
			errorResponse.err = AppConstants.ERROR3004;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKuaAsync(request, errorResponse);
			ApplicationLogger.logAsyncKua(strAsaResponse);
			ApplicationLogger.logAsyncKua("Parse CIDR response Error: " + errorResponse.toString());
			return XMLBuilder.buildKUAResp(errorResponse);
		}

		// ******************** 8. Decrypt eKYC XML ********************************

		if (response2_5One.status.equals("0")) {

			// ******************** 8.1 Data decrypt from HSM ***************************

			String encodedResponseXML = Base64.getEncoder().encodeToString(strAsaResponse.getBytes());
//			ApplicationLogger.logAsyncKua("Encrypted data with Base64 encoded " + encodedResponseXML);
			DataDecryptorRequest datadecryptor = new DataDecryptorRequest();
			datadecryptor.enc_val = encodedResponseXML;
			datadecryptor.txn = request.txn;

			DataDecryptorResponse decryaptedresponse;
			try {
				decryaptedresponse = HttpClientUtil.postToDecryptResponse(datadecryptor);
				print("Decryption Complete :", refTime);
			} catch (Exception e) {
				errorResponse.err = AppConstants.ERROR1025;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				ApplicationLogger.logAsyncKua("Connection TimeOut at HSM Level:" + errorResponse.toString(), e);
				AuditUtil.saveKuaAsync(request, errorResponse);
				return XMLBuilder.buildKUAResp(errorResponse);
			}

			// ********* 8.1 Negative Response FROM HSM SIDE *****************28/02/2022
			if (decryaptedresponse.status != 1) {
				errorResponse.err = AppConstants.ERROR1026;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveKuaAsync(request, errorResponse);
				ApplicationLogger.logAsyncKua(
						"Unable to Decrypt by HSM: " + errorResponse.toString() + " => " + decryaptedresponse);
				return XMLBuilder.buildKUAResp(errorResponse);
			}
			// ******************************************************************************
			byte[] decrptedxml = Base64.getDecoder().decode(decryaptedresponse.ret_val);
			Response2_5 response2_5 = ParseUtil.parseKYC(decrptedxml);
			if (response2_5 == null) {
				errorResponse.err = AppConstants.ERROR1027;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveKuaAsync(request, errorResponse);
				ApplicationLogger.logAsyncKua("Parse HSM response Error: " + errorResponse.toString());
				return XMLBuilder.buildKUAResp(errorResponse);
			}
			if (!SignatureUtil.isVerified(new String(Base64.getDecoder().decode(response2_5.Rar)))) {
				errorResponse.err = AppConstants.ERROR1029;
				errorResponse.ts = DateTimeUtil.getCurrentDate();
				request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
				AuditUtil.saveKuaAsync(request, errorResponse);
				ApplicationLogger.logAsyncKua("Signature Verification Error: " + errorResponse.toString());
				return XMLBuilder.buildKUAResp(errorResponse);
			}

			print("Signature Verified:", refTime);
			// ******************** 9. Return response ******************************
			response2_5.txn_subAua = request.txn_subAua;
			response2_5.Ko = response2_5One.Ko;
			response2_5.status = response2_5One.status;
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKuaAsync(request, response2_5);
			print("Success Response: ", refTime);
			ApplicationLogger.logAsyncDbFail(request.txn_subAua + " - Success Response");
			return XMLBuilder.buildKUAResp(response2_5);
		}

		// ********** 10. Parse Error Response for Specific Error Code **************
		if (response2_5One.KycRes != null) {

			response2_5One.authErr = ParseUtil.parseAuthError(response2_5One.KycRes);
		}
		response2_5One.txn_subAua = request.txn_subAua;
		request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
		AuditUtil.saveKuaAsync(request, response2_5One);
		ApplicationLogger.logAsyncDbFail(request.txn_subAua + " - Error Response");
		return XMLBuilder.buildKUAResp(response2_5One);

	}

	private void print(String message, LocalTime refTime) {
		System.out.println(message + (refTime.until(LocalTime.now(), MILLIS)));
	}
}
