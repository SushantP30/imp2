package com.controllers;

import static java.time.temporal.ChronoUnit.MILLIS;

import java.time.LocalTime;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enums.RequestTo;
import com.models.AuthenticationResult;
import com.models.Request2_5;
import com.models.Response2_5;
import com.models.Statistics;
import com.utils.AppConstants;
import com.utils.AuditUtil;
import com.utils.Authenticator;
import com.utils.DateTimeUtil;
import com.utils.ParseUtil;
import com.utils.Validator;
import com.utils.XMLBuilder;

/**
 * @author Harsh
 *
 */
@SpringBootApplication
@RestController
@RequestMapping("/kua/rest/otp")
public class OTPGenController {

	@PostMapping(value = "/genOtp25", produces = { MediaType.APPLICATION_XML_VALUE })
	public String acceptRequest25(@RequestBody(required = false) String requestXML, HttpServletRequest httpRequest) {
		return processAndBuildResponse(requestXML, httpRequest);
	}

	private String processAndBuildResponse(String requestXML, HttpServletRequest httpRequest) {
		// TODO Auto-generated method stub

		LocalTime refTime = LocalTime.now();
		print(System.lineSeparator() + "Entered KUA :", refTime);
		Statistics.addRequests_KUA();
		Response2_5 errorResponse = new Response2_5();
		errorResponse.ret = "n";
		errorResponse.actn = "NA";

		// ******************** 1. Parse the XML to Object**********************

		Request2_5 request = ParseUtil.parseKuaXML(requestXML);
		if (request == null) {
			errorResponse.err = AppConstants.ERROR1001;
			System.out.println(errorResponse.err);
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			return XMLBuilder.buildKUAResp(errorResponse);
		}
		print("Parse Complete:", refTime);

		// ******************** 2. Authenticate ********************************
		request.RequestReceived = DateTimeUtil.getCurrentDateSQLFormat();
		request.IpAddress = httpRequest.getRemoteAddr();
		request.requestTo = RequestTo.KUA;
		errorResponse.txn = request.txn_subAua;
		AuthenticationResult result = Authenticator.isAuthenticated(request);
		if (!result.isAuthenticated) {
			errorResponse.err = result.ErrorCode;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKuaAsync(request, errorResponse);
			return XMLBuilder.buildKUAResp(errorResponse);

		}

		// ******************** 3. Validate ***********************************

		String validationError = Validator.Validate(request);
		if (!validationError.equals("")) {
			errorResponse.err = validationError;
			errorResponse.ts = DateTimeUtil.getCurrentDate();
			request.ResponseSent = DateTimeUtil.getCurrentDateSQLFormat();
			AuditUtil.saveKuaAsync(request, errorResponse);
			return XMLBuilder.buildKUAResp(errorResponse);
		}
		print("Validation Complete:", refTime);
		return null;
	}

	private void print(String message, LocalTime refTime) {
		// TODO: remove after testing is done
		System.out.println(message + (refTime.until(LocalTime.now(), MILLIS)));
	}

}
