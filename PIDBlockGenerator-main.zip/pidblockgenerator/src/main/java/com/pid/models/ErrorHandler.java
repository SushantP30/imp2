package com.pid.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorHandler {

	private String txn;
	private String otp;
	private String error;
}
