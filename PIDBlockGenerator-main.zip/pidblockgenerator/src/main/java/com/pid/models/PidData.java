package com.pid.models;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Getter;
import lombok.Setter;

/**
 *  “PIDData" for get otp and transaction value from requesting entity.
 */
@Getter
@Setter
@JacksonXmlRootElement(localName = "PIDData")
public class PidData {

	@JacksonXmlProperty(localName = "Otp", isAttribute = true)
	private String otp;
	
	@JacksonXmlProperty(localName = "Txn", isAttribute = true)
	private String txn;
}
