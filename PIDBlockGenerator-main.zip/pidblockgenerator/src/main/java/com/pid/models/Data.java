package com.pid.models;

import com.pid.enums.*;

import lombok.Getter;
import lombok.Setter;

/**
 * (mandatory) “Data” element of Response PIDData.
 */
@Setter
@Getter
public class Data {

	// Type of the PID block format. It can have two values – “X” for XML
	private  DataType type = DataType.X;

	// Data – PID block data should be encrypted with a dynamic session key using
	private String data;

}
