package com.pid.models;

import lombok.Getter;
import lombok.Setter;

/**
 * HelperData class object have sessionkey and pid xml
 */
@Setter
@Getter
public class HelperData {

	private byte[] sessionKey;
	private byte[] pidInputData;

}
