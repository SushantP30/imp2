package com.pid.models;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 *  Generate private value element Pv (otp=******).
 */
@Setter
@Getter
@JacksonXmlRootElement(localName = "PIDData")
@ToString
public class Pv {

	@JacksonXmlProperty(localName = "Otp", isAttribute = true)
	private String otp;
	
}
