package com.pid.models;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * (mandatory) “Pid” class for generate Pid block
 */
@Setter
@Getter
@ToString
public class Pid {

	/** Time Stamp */
	private String ts;

	/**
	 * (mandatory) version of the “Pid” element. Currently only valid value is “2.0”.
	 * Notice that this is NOT same as Authentication API version.
	 */
	private String ver;

	private Pv pv = new Pv();
}
