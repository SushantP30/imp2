package com.pid.utils;

import java.io.FileInputStream;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Date;

import javax.crypto.Cipher;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EncrypterSkey {
	
	@Autowired
	private PropertiesUtil propertiesUtil;
	
	/**provide a new provider at runtime
	 * @return the preference position in which the provider was added, or -1 if the provider was not added.
	 */
	public void securityProvider() {
		Security.addProvider(new BouncyCastleProvider());
	}

	/**
	 * @return provides a standard way to access all the attributes of an X.509 certificate.  
	 * @throws Exception
	 */
	public X509Certificate fileInput() {
		this.securityProvider();
			final String CERTIFICATE_TYPE = "X.509";
			final String JCE_PROVIDER = "BC";
			final String FILE_PATH=propertiesUtil.getCerPath();
			X509Certificate cert = null;
			try {
				CertificateFactory certFactory= CertificateFactory.getInstance(CERTIFICATE_TYPE, JCE_PROVIDER);
				FileInputStream fileIp = new FileInputStream(FILE_PATH);
				cert = (X509Certificate) certFactory.generateCertificate(fileIp);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			return cert;
	}
	
	/**
	 * @return PublicKey of certificate
	 * @throws Exception
	 */
	public PublicKey publicKey() {
		if(this.fileInput()== null) {
			return null;
		}
		X509Certificate cert= this.fileInput();
		return cert.getPublicKey();
	}
	
	/**
	 * @return Expired date of certificate
	 * @throws Exception
	 */
	public Date certExpiryDate()  {
		if(this.fileInput()== null) {
			return null;
		}
		X509Certificate cert = this.fileInput();
		return cert.getNotAfter();
	}

	/**
	 * Generate Encrypt SessionKey By the specified algorithm, size and public key of certificate
	 * @param sessionKey encoded session key
	 * @return Encrypted SessionKey
	 * @throws Exception
	 */
	public byte[] encryptUsingPublicKey(byte[] sessionKey) throws Exception {
		final String  ASYMMETRIC_ALGO = "RSA/ECB/PKCS1Padding";
		final String JCE_PROVIDER = "BC";
		Cipher pkCipher = Cipher.getInstance(ASYMMETRIC_ALGO, JCE_PROVIDER);
		if(this.publicKey() == null) {
			System.out.println( "Certificate key not found" );
			return null; 
		}
	    pkCipher.init(1, this.publicKey() );
	    byte[] encSessionKey = pkCipher.doFinal(sessionKey);
	    return encSessionKey;
	}

}
