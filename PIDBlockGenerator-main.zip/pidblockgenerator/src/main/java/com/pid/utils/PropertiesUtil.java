package com.pid.utils;

import java.util.ResourceBundle;

import org.springframework.stereotype.Service;

@Service
public class PropertiesUtil {
	private ResourceBundle messageBundle = ResourceBundle.getBundle("aadhar");

	private String getValue(String key) {
		return messageBundle.getString(key).trim();
	}
	
	public String getApiVersion() {
		return getValue("apiVersion");
	}
	
	public String getCerPath() {
		return getValue("cerPath");
	}
}