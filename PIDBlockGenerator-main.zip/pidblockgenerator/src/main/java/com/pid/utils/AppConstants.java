package com.pid.utils;

/**
 * AppConstants provide error description.
 * 
 * @author Administrator
 * 
 */
public class AppConstants {

	// ********************1. Application's Status ************************
	public static final String AAPSTATUSPID = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><status>PID Generate XML of GOG Up &amp; Runing.........</status>";

	// Required messages
	public static final String ERROR_REQ_TXN = "Transaction id should required";
	public static final String ERROR_REQ_OTP = "OTP should required";
	public static final String ERROR_REQ_FILE = "Certificate not found";

}
