package com.pid.utils;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.pid.models.PidData;
import com.pid.models.Pid;
import com.pid.models.Pv;

@Service
public class PidUtil {
	
	@Autowired
	DateTimeUtil dateTimeUtil;
	
	/**
	 * @param pidData
	 * @return
	 */
	public String pidValidation(PidData pidData ){
		String status = "";

		if (pidData.getTxn() == null || pidData.getTxn().trim().equals("")) {
			status= AppConstants.ERROR_REQ_TXN;
		}
		
		if (pidData.getOtp() == null || pidData.getOtp().trim().equals("")) {
			status= AppConstants.ERROR_REQ_OTP;
		}
		return status;
	}
	
	/** 
	 * Value store in Pid object
	 * @param pv provide OTP of requesting entity.
	 * @return Pid block
	 */
	public Pid pidValues(Pv pv) {
		Pid pid= new Pid();
		pid.setPv(pv); 
		pid.setTs(dateTimeUtil.getCurrentISOTimeInUTF8());
		pid.setVer("2.0");
		return pid;
	} 
	
	// get timestamp from demo pid block
	public String getTsFromPidDemo(String pidDemo) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new InputSource(new StringReader(pidDemo)));
		document.getDocumentElement().normalize();
		return document.getDocumentElement().getAttribute("ts");

	}
}
