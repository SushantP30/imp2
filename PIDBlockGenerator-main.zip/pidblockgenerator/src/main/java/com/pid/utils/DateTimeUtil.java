package com.pid.utils;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.stereotype.Service;

/**
 * DateTimeUtil class provide time formate
 * @author Administrator
 *
 */
@Service
public class DateTimeUtil {
	/**
	 * @return returns Date Time stamp in format YYYY-MM-DDThh:mm:sss+5:30
	 */
	public String getCurrentDate() {
		return LocalDateTime.now().toString().substring(0, 23) + "+5:30";
	}
	
	/**
	 * @return returns Date Time stamp in format YYYY-MM-DD Thh:mm:ss 
	 */
	public String getCurrentISOTimeInUTF8() {
		SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd'T'hh:mm:ss");
		return df.format(new Date());
	}

}
