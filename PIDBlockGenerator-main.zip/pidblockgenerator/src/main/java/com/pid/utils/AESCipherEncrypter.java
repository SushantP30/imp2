package com.pid.utils;

import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import java.util.Arrays;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.AESEngine;
import org.bouncycastle.crypto.modes.GCMBlockCipher;
import org.bouncycastle.crypto.params.AEADParameters;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.stereotype.Service;

/**
 * Advanced Encryption Standard 
 * @author Administrator
 *
 */
@Service	
public class AESCipherEncrypter {

	/**provide a new provider at runtime
	 * @return the preference position in which the provider was added, or -1 if the provider was not added.
	 */
	public void securityProvider() {
		Security.addProvider((Provider) new BouncyCastleProvider());
	}

	/**
	 * @param cipherOperation always true
	 * @param skey encoded sessionkey
	 * @param iv initialization vector
	 * @param aad Additional authenticated data
	 * @param data pid xml
	 * @return encrypted hash pid xml.
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 */
	public byte[] encryptDecryptUsingSessionKey(boolean cipherOperation, byte[] skey, byte[] iv, byte[] aad,
			byte[] pidData) throws IllegalStateException, InvalidCipherTextException {
		AEADParameters aeadParam = new AEADParameters(new KeyParameter(skey), 128, iv, aad);
		GCMBlockCipher gcmb = new GCMBlockCipher((BlockCipher) new AESEngine());
		gcmb.init(cipherOperation, (CipherParameters) aeadParam);
		int outputSize = gcmb.getOutputSize(pidData.length);
		byte[] result = new byte[outputSize];
		int processLen = gcmb.processBytes(pidData, 0, pidData.length, result, 0);
		gcmb.doFinal(result, processLen);
		return result;
	}

	/**
	 * @param inputData
	 * @return encrypted Hash pid data transformed from pid xml in byte[] using an Hashing algorithm
	 * @throws Exception
	 */
	public byte[] generateHash(byte[] inputData) throws Exception {
		byte[] hash = null;
		final String ALGOTITHM = "SHA-256";
		final int HMACSIZE = 32;
		try {
			MessageDigest digest = MessageDigest.getInstance(ALGOTITHM, "BC");
			digest.reset();
			if (HMACSIZE != digest.getDigestLength()) {
				throw new Exception("SHA-256 Hashing algorithm failed");
			}
			hash = digest.digest(inputData);
		} catch (GeneralSecurityException e) {
			throw new Exception("SHA-256 Hashing algorithm not available");
		}
		return hash;
	}

	/**
	 * 
	 * @param inputData pidXmlblock 
	 * @param sessionKey encoded
	 * @param ts TimeStamp
	 * @return encrypted pid data transformed from plaintext using an encryption algorithm
	 * @throws IllegalStateException
	 * @throws InvalidCipherTextException
	 * @throws Exception
	 */
	public byte[] encrypt(byte[] inputData, byte[] sessionKey, String ts)
			throws Exception {
		byte[] iv = generateIv(ts);
		byte[] aad = generateAad(ts);
		byte[] cipherText = encryptDecryptUsingSessionKey(true, sessionKey, iv, aad, inputData);
		byte[] tsInBytes = ts.getBytes("UTF-8");
		byte[] packedCipherData = new byte[cipherText.length + tsInBytes.length];
		System.arraycopy(tsInBytes, 0, packedCipherData, 0, tsInBytes.length);
		System.arraycopy(cipherText, 0, packedCipherData, tsInBytes.length, cipherText.length);
		return packedCipherData;
	}   

	/**
	 * @param ts Time stamp from Pid block.
	 * @return initialization vector. An initialization vector (or IV) are used to ensure that 
	 * 								the same value encrypted multiple times, even with the same secret key, 
	 * 								will not always result in the same encrypted value. This is an added security layer
	 * @throws UnsupportedEncodingException
	 */
	public byte[] generateIv(String ts) throws UnsupportedEncodingException {
		return getLastBits(ts, 12);
	}

	/**
	 * @param ts Time stamp from Pid block.
	 * @return Additional authenticated data. AAD is used as an integrity check and can help
	 * 										  protect your data from a confused deputy attack.
	 * @throws UnsupportedEncodingException
	 */
	public byte[] generateAad(String ts) throws UnsupportedEncodingException {
		return getLastBits(ts, 16);
	}

	/**
	 * @param ts Time stamp from Pid block.
	 * @param bits 
	 * @return specified elements range of the original array.
	 * @throws UnsupportedEncodingException
	 */
	public byte[] getLastBits(String ts, int bits) throws UnsupportedEncodingException  {
		byte[] tsInBytes = ts.getBytes("UTF-8");
		return Arrays.copyOfRange(tsInBytes, tsInBytes.length - bits, tsInBytes.length);
	}

	/** generate SessionKey By the specified algorithm and size. 
	 * @param AES algorithm Type 
	 * @param BC Provider Type (provider implements some or all parts of Java Security)
	 * @return Session key in encoded form
	 * @throws NoSuchAlgorithmException,NoSuchProviderException
	 */
	public byte[] generateSessionKey() throws NoSuchAlgorithmException, NoSuchProviderException {
		this.securityProvider();
		KeyGenerator kgen = KeyGenerator.getInstance("AES", "BC");
		kgen.init(256);
		SecretKey key = kgen.generateKey();
		return key.getEncoded();
	}

	// use only when you print data
	public String byteArrayToHexString(byte[] bytes) {
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < bytes.length; i++)
			result.append(Integer.toString((bytes[i] & 0xFF) + 256, 16).substring(1));
		return result.toString();
	}
}
