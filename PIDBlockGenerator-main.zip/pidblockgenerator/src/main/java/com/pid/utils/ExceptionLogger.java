/**
 * 
 */
package com.pid.utils;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@Service
public class ExceptionLogger extends ResponseEntityExceptionHandler {
	private static final Logger PIDFailLogger = Logger.getLogger("pidFail");

	public static void logAsyncPID(String message, Exception e) {
		PIDFailLogger.error(message, e);
	}

	public static void logAsyncPID(String message) {
		PIDFailLogger.error(message);
	}

}
