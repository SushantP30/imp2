/**
 * 
 */
package com.pid.enums;

/**
 * (mandatory) DataType of the “Data” element. Currently only valid value is “X”.
 */
public enum DataType {
	X, P;

	public String value() {
		return name();
	}

	public static DataType fromValue(String v) {
		return valueOf(v);
	}
}
