package com.pid.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pid.models.ErrorHandler;
import com.pid.models.Pid;
import com.pid.models.PidData;
import com.pid.models.Pv;
import com.pid.service.PIDBuilder;
import com.pid.utils.AppConstants;
import com.pid.utils.ExceptionLogger;
import com.pid.utils.PidUtil;

@RestController
@RequestMapping("/authenticate/rest")
public class PIDController {

	@Autowired
	public PIDBuilder pidBuilder;
	@Autowired
	public PidUtil pidUtil;

	/**
	 * Checking Status Of PID Service
	 * @return Application status XML.
	 */
	@GetMapping(value = "/checkstatuspid", produces = { MediaType.APPLICATION_XML_VALUE })
	public String checkAUAStatus() {
		return AppConstants.AAPSTATUSPID;
	}

	/**
	 * Generate PIDData Response Xml , which generate PID,Skey,Hmac and Data attribute
	 * 
	 * @param pidData Requesting User store OTP and Transaction id in PIDData Class.
	 * @throws Exception 
	 */
	@PostMapping(value = "/pid", consumes = { MediaType.APPLICATION_XML_VALUE }, produces = {MediaType.APPLICATION_XML_VALUE })
	public String acceptRequestpid(@RequestBody PidData pidData) throws Exception {

		String InvalidPid = pidUtil.pidValidation(pidData);
		if (InvalidPid != "") {
			ErrorHandler handler = new ErrorHandler();
			handler.setError(InvalidPid);
			handler.setTxn(pidData.getTxn() == null ? "" : pidData.getTxn());
			handler.setOtp(pidData.getOtp() == null ? "" : pidData.getOtp());
			ExceptionLogger.logAsyncPID("Transaction ID: " + handler.getTxn()+" "+handler.getError() );
			return pidBuilder.buildErrorXml(handler );
		}
		// ************************* 1. pid value store in pid Object************************
		Pv pv = new Pv();
		pv.setOtp(pidData.getOtp());
		Pid pid = pidUtil.pidValues(pv);

		// ************************* 2. Generate PID XML block ************************
		String pidXml = pidBuilder.buildPIDxmlFile(pid);

		// ************************* 3. Generate PIDData Response Xml Block************************
		return pidBuilder.buildResponseXML(pidXml, pid.getTs());

	}
	

	@PostMapping(value = "/piddemo", produces = {MediaType.APPLICATION_XML_VALUE })
	public String requestPidDemo(@RequestBody String requestXML) throws Exception {
		String pidts = pidUtil.getTsFromPidDemo(requestXML);
		return pidBuilder.buildResponseXML(requestXML, pidts);
	}
}