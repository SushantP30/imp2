package com.pid.service;

import java.io.StringWriter;
import java.util.Base64;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pid.models.ErrorHandler;
import com.pid.models.HelperData;
import com.pid.models.Pid;
import com.pid.models.PidData;
import com.pid.utils.ExceptionLogger;
import com.pid.utils.AESCipherEncrypter;
import com.pid.utils.DateTimeUtil;

/**
 * Build Pid XML and PIDdata response XMl
 * @author Hardik
 *
 */
@Service
public class PIDBuilder {

	@Autowired
	private EncryptionUtil encryptionUtil;
	@Autowired
	private DateTimeUtil dateTimeUtil;
	@Autowired
	private AESCipherEncrypter aesCipher;

	/**
	 * @param PIDXml pidData in XML form
	 * @param Pid for get time stamp
	 * @param Txn user transaction number
	 * @return Generate response PIDData XML
	 * @throws Exception
	 */
	public String buildResponseXML(String pidXml, String pidTs) throws Exception {

		String requestDataTye = "X";
		HelperData helperData = new HelperData();
		helperData.setSessionKey(aesCipher.generateSessionKey());
		helperData.setPidInputData(pidXml.getBytes());
		try {

			// ******** encrypted Piddata convert into base64 encode *************
			String dataValue = Base64.getMimeEncoder().encodeToString(encryptionUtil.cipherTextWithTS(pidTs, helperData));

			// ******** get certificate expire data *************
			String certificateDate = encryptionUtil.certificateIdentifier();
//			if (certificateDate.length() > 8) {
//				ErrorHandler handler = new ErrorHandler();
//				handler.setError(certificateDate);
//				handler.setTxn(pidData.getTxn());
//				handler.setOtp(pidData.getOtp());
//				ExceptionLogger.logAsyncPID( "Transaction ID:" + handler.getTxn() + " Error build at ResponseXML "+" certificate not found " );
//				return this.buildErrorXml(handler);
//			}
			String certificateIdentifier = certificateDate;

			// ******** Encrypted SessionKey convert into base64 encode*************
			byte[] encryptSessionKey = encryptionUtil.encryptedSessionKey(helperData);
			String str = new String(encryptSessionKey);
//			if (str.length() < 30) {
//				ErrorHandler handler = new ErrorHandler();
//				handler.setError(str);
//				handler.setTxn(pidData.getTxn());
//				handler.setOtp(pidData.getOtp());
//				ExceptionLogger.logAsyncPID( "Transaction ID:" + handler.getTxn() + " Error build at ResponseXML "+" certificate not found " );
//				return this.buildErrorXml(handler);
//			}
			String dynamicSkey = Base64.getMimeEncoder().encodeToString(encryptSessionKey);

			StringWriter stringWriter = new StringWriter();
			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			xMLStreamWriter.writeStartDocument("UTF-8", "1.0");

			xMLStreamWriter.writeStartElement("PIDData");

//			xMLStreamWriter.writeStartElement("Txn");
//			xMLStreamWriter.writeCharacters(pidData.getTxn());
//			xMLStreamWriter.writeEndElement();// End Ts

			xMLStreamWriter.writeStartElement("Skey");
			xMLStreamWriter.writeAttribute("ci", certificateIdentifier);
			xMLStreamWriter.writeCharacters(dynamicSkey);
			xMLStreamWriter.writeEndElement(); // End Skey

			// ******** Generate Hmac tag and where hmac is Encrypted hash pid xml convert into base64 encode *************
			xMLStreamWriter.writeStartElement("Hmac");
			String hMac = Base64.getMimeEncoder().encodeToString(encryptionUtil.encSrcHash(pidTs, helperData));
			xMLStreamWriter.writeCharacters(hMac);
			xMLStreamWriter.writeEndElement(); // End Hmac

			xMLStreamWriter.writeStartElement("Data");
			xMLStreamWriter.writeAttribute("type", requestDataTye);
//			if (dataValue == null) {
//				ExceptionLogger .logAsyncPID("Error building PID response: " + "Transaction ID:" + pidData.getTxn() + ":");
//				return null;
//			}
			xMLStreamWriter.writeCharacters(dataValue);
			xMLStreamWriter.writeEndElement();// End Data

			xMLStreamWriter.writeStartElement("Ts");
			xMLStreamWriter.writeCharacters(dateTimeUtil.getCurrentDate());
			xMLStreamWriter.writeEndElement();// End Ts

			xMLStreamWriter.writeEndElement();// End KUAData
			xMLStreamWriter.writeEndDocument();// End PIDData
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			String xmlString = stringWriter.getBuffer().toString();
			xmlString = xmlString.replace("?>", " standalone=\"yes\"?>");
			stringWriter.close();
			return xmlString;
		} catch (Exception e) {
			e.printStackTrace();
//			ExceptionLogger.logAsyncPID("Error building build ResponseXML: " + "Transaction ID:"+ pidData.getTxn() + ":", e);
			ExceptionLogger.logAsyncPID("Error building build ResponseXML: " + "Transaction ID:"+ e);
			return null;
		}
	}

	/**
	 * generate PID block
	 * 
	 * @param pid object of Pid class
	 * @return PidXml
	 */
	public String buildPIDxmlFile(Pid pid) {
		try {
			StringWriter stringWriter = new StringWriter();
			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);

			xMLStreamWriter.writeStartElement("Pid");
			xMLStreamWriter.writeAttribute("ts", pid.getTs());
			xMLStreamWriter.writeAttribute("ver", pid.getVer());

			xMLStreamWriter.writeStartElement("Pv");
			xMLStreamWriter.writeAttribute("otp", pid.getPv().getOtp());
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.writeEndDocument();
			xMLStreamWriter.flush();
			xMLStreamWriter.close();

			return  stringWriter.getBuffer().toString();
		} catch (Exception e) {
			ExceptionLogger.logAsyncPID("Error building PID Block Request:", e);
			return null;
		}
	}

	public String buildErrorXml(ErrorHandler handler) {
		try {
			StringWriter stringWriter = new StringWriter();
			XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(stringWriter);
			
			xMLStreamWriter.writeStartElement("PIDData");
			xMLStreamWriter.writeAttribute("Txn", handler.getTxn());
			xMLStreamWriter.writeAttribute("OTP", handler.getOtp());
			xMLStreamWriter.writeAttribute("Error", handler.getError());
			xMLStreamWriter.writeEndDocument();
			
			xMLStreamWriter.flush();
			xMLStreamWriter.close();
			return stringWriter.getBuffer().toString();
		} catch (XMLStreamException e) {
			ExceptionLogger.logAsyncPID("Error building PID Block Request:", e);
			return null;
		}
	}

}
