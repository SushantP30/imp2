package com.pid.service;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pid.models.HelperData;
import com.pid.utils.AESCipherEncrypter;
import com.pid.utils.AppConstants;
import com.pid.utils.EncrypterSkey;

/**
 * EncryptionUtil class provide functions which is use in PIDBuilder class.
 * @author Hardik
 */
@Service
public class EncryptionUtil {

	@Autowired
	private EncrypterSkey encrypter;
	@Autowired
	private AESCipherEncrypter aesCipher;

	/**
	 * @param ts Time stamp from Pid block.
	 * @param helperData have PidXml in byte[] and encoded session key in byte[]
	 * @return encrypted Pid data with timeStamp, Session key and PidXml
	 * @throws Exception  
	 */
	public byte[] cipherTextWithTS(String ts, HelperData helperData) throws Exception {
			return aesCipher.encrypt(helperData.getPidInputData(), helperData.getSessionKey(), ts);
	}

	/**
	 * @return expire date of certificate
	 * @throws Exception
	 */
	public String certificateIdentifier() {
		SimpleDateFormat df2 = new SimpleDateFormat("yyyyMMdd");
		if(encrypter.certExpiryDate()== null) {
			return AppConstants.ERROR_REQ_FILE;
			
		}
		return df2.format(encrypter.certExpiryDate());
	}

	/**
	 * @param helperData provide encoded session key
	 * @return Encrypted SessionKey using certificate public key and specified algorithm, 
	 * @throws Exception
	 */
	public byte[] encryptedSessionKey(HelperData helperData) throws Exception {
		byte[] encryptSessionKey = encrypter.encryptUsingPublicKey(helperData.getSessionKey()); 
		if (encryptSessionKey == null) {
			String error=  AppConstants.ERROR_REQ_FILE; 
			return error.getBytes();
		}
		return encryptSessionKey; 
	}

	/**
	 * @param ts Time stamp from Pid block.
	 * @param helperData provide encoded session key, pidxml in byte[]
	 * @return encrypted hash pid xml using session key, iv, aad and hash pid.
	 * @throws Exception
	 */
	public byte[] encSrcHash(String ts, HelperData helperData) throws Exception {
		return aesCipher.encryptDecryptUsingSessionKey(true, helperData.getSessionKey(), this.aesCipherIv(ts),
				this.aesCipherAad(ts), this.srcHash(helperData.getPidInputData()));
		
	}
	
	/**
	 * @param inputData is pidxml in byte[]
	 * @return hash pid xml using an Hashing algorithm
	 * @throws Exception
	 */
	public byte[] srcHash(byte[] inputData) throws Exception {
		return aesCipher.generateHash(inputData);
	}

	/**
	 * @param ts Time stamp from Pid block.
	 * @return specified range of the original elements array by Additional authenticated data method
	 * @throws UnsupportedEncodingException 
	 * @throws Exception
	 */
	public byte[] aesCipherAad(String ts) throws UnsupportedEncodingException  {
		return aesCipher.generateAad(ts);
	}

	/**
	 * @param ts Time stamp from Pid block.
	 * @return specified range of the original elements array by initialization vector method
	 * @throws UnsupportedEncodingException 
	 * @throws Exception
	 */
	public byte[] aesCipherIv(String ts) throws UnsupportedEncodingException  {
		return aesCipher.generateIv(ts);
	}

}
